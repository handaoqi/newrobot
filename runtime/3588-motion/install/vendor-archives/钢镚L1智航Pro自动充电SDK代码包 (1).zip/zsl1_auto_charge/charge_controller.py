"""
钢镚L1智航Pro - 自动充电控制器
核心模块：触发自主回充导航、轮询充电状态、出桩控制、异常重试。
对齐说明书五大功能：定位→自主导航→避障→自主回充→充电闭环。
"""

import time
import logging
from enum import Enum
from typing import Optional, Callable
from sdk_client import ZSL1SDKClient, SDKError
from map_manager import MapManager, ChargeStation
from config import (
    MAX_DOCK_RETRY, RETRY_INTERVAL_SEC, STATUS_POLL_INTERVAL,
    NAV_TIMEOUT_SEC, DOCK_SAFE_ZONE_M, DOCK_APPROACH_SPEED,
)

logger = logging.getLogger(__name__)


class ChargeStatus(Enum):
    """充电状态枚举（对齐SDK返回状态）"""
    IDLE = "IDLE"                    # 空闲，未充电
    NAV_TO_CHARGE = "NAV_TO_CHARGE"  # 导航前往充电桩途中
    DOCKING = "DOCKING"              # 到达点位，执行精准对接
    CHARGING = "CHARGING"            # 对接成功，正在充电（运动控制锁定）
    DOCK_FAIL = "DOCK_FAIL"          # 对接失败
    UNDOCK_READY = "UNDOCK_READY"    # 充电完成，可出桩
    UNDOCKING = "UNDOCKING"          # 正在出桩
    ERROR = "ERROR"                  # 异常状态


class ChargeController:
    """自动充电控制器"""

    def __init__(self, client: ZSL1SDKClient, map_mgr: MapManager):
        self.client = client
        self.map_mgr = map_mgr
        self._current_status = ChargeStatus.IDLE
        self._status_callback: Optional[Callable[[ChargeStatus], None]] = None

    # ---------- 状态查询 ----------
    def get_status(self) -> ChargeStatus:
        """获取当前充电状态"""
        try:
            data = self.client._check(
                self.client._get("/charge/status"),
                "查询充电状态"
            )
            status_str = data.get("status", "IDLE").upper()
            self._current_status = ChargeStatus(status_str)
        except (SDKError, ValueError) as e:
            logger.error("状态查询异常: %s", e)
            self._current_status = ChargeStatus.ERROR
        return self._current_status

    def get_battery(self) -> dict:
        """获取电池信息"""
        data = self.client._check(self.client._get("/power/battery"), "获取电池信息")
        return {
            "percent": data.get("percent", 0),
            "voltage": data.get("voltage", 0),
            "current": data.get("current", 0),
            "charging": data.get("charging", False),
        }

    def on_status_change(self, callback: Callable[[ChargeStatus], None]):
        """注册状态变化回调"""
        self._status_callback = callback

    def _notify(self, status: ChargeStatus):
        if self._status_callback:
            try:
                self._status_callback(status)
            except Exception as e:
                logger.error("状态回调异常: %s", e)

    # ---------- 前置检查 ----------
    def pre_check(self) -> bool:
        """
        回充前置检查（对齐说明书硬性要求）：
        1. 地图已加载且充电桩已标记
        2. 定位健康
        3. 充电桩前方1.5m无障碍物
        4. 电池非满电
        """
        logger.info("=== 回充前置检查 ===")

        # 1. 充电桩标记检查
        station = self.map_mgr.get_charge_station()
        if not station or not station.marked:
            logger.error("当前地图未标记充电桩，请先调用 mark_charge_station()")
            return False

        # 2. 定位健康检查
        health = self.map_mgr.check_localization_health()
        if not health["ready"]:
            logger.error("定位不满足回充条件: %s", health)
            return False

        # 3. 充电桩前方安全区障碍物检测
        if not self._check_dock_safe_zone(station):
            logger.error("充电桩前方%.1fm安全区内存在障碍物", DOCK_SAFE_ZONE_M)
            return False

        # 4. 电池状态
        bat = self.get_battery()
        if bat["charging"]:
            logger.info("设备已在充电中")
            return True
        if bat["percent"] >= 100:
            logger.info("电池已满，无需充电")
            return False

        logger.info("前置检查通过，可执行自动回充")
        return True

    def _check_dock_safe_zone(self, station: ChargeStation) -> bool:
        """检测充电桩前方安全区是否有障碍物（激光雷达点云）"""
        try:
            data = self.client._check(
                self.client._post("/navigation/check_obstacle", {
                    "center": station.dock_pose.to_dict(),
                    "radius": DOCK_SAFE_ZONE_M,
                }),
                "充电桩安全区检测"
            )
            return not data.get("has_obstacle", False)
        except SDKError:
            logger.warning("安全区检测接口不可用，跳过（需人工确认现场）")
            return True

    # ---------- 核心：自动回充 ----------
    def auto_charge(self, block: bool = True, timeout: float = NAV_TIMEOUT_SEC) -> ChargeStatus:
        """
        触发自动回充。
        - block=True: 阻塞等待，直到进入充电状态或失败/超时
        - block=False: 异步下发，立即返回，需自行轮询 get_status()
        返回最终状态。
        """
        if not self.pre_check():
            self._current_status = ChargeStatus.ERROR
            return self._current_status

        # 下发回充导航指令
        logger.info("下发自动回充指令...")
        self.client._check(
            self.client._post("/navigation/auto_charge", {
                "map_id": self.map_mgr.current_map_id,
                "approach_speed": DOCK_APPROACH_SPEED,
            }),
            "触发自动回充"
        )
        self._current_status = ChargeStatus.NAV_TO_CHARGE
        self._notify(self._current_status)

        if not block:
            logger.info("异步回充指令已下发")
            return self._current_status

        # 阻塞等待状态流转
        return self._wait_for_charge(timeout)

    def _wait_for_charge(self, timeout: float) -> ChargeStatus:
        """等待回充完成，支持自动重试"""
        start = time.time()
        retry_count = 0
        last_status = ChargeStatus.NAV_TO_CHARGE

        while time.time() - start < timeout:
            status = self.get_status()

            # 状态变化通知
            if status != last_status:
                logger.info("充电状态变更: %s -> %s", last_status.value, status.value)
                self._notify(status)
                last_status = status

            # 成功进入充电
            if status == ChargeStatus.CHARGING:
                logger.info("=== 自动充电成功，设备正在充电 ===")
                bat = self.get_battery()
                logger.info("当前电量: %d%%", bat["percent"])
                return status

            # 对接失败，自动重试
            if status == ChargeStatus.DOCK_FAIL:
                retry_count += 1
                logger.warning("对接失败（第%d/%d次）", retry_count, MAX_DOCK_RETRY)
                if retry_count >= MAX_DOCK_RETRY:
                    logger.error("达到最大重试次数，回充终止")
                    self.client.emergency_stop()
                    return status
                # 退避后重试
                time.sleep(RETRY_INTERVAL_SEC)
                try:
                    self.client._check(
                        self.client._post("/navigation/auto_charge", {"retry": True}),
                        "重试回充"
                    )
                except SDKError as e:
                    logger.error("重试下发失败: %s", e)
                continue

            # 异常状态
            if status == ChargeStatus.ERROR:
                logger.error("回充过程异常")
                return status

            time.sleep(STATUS_POLL_INTERVAL)

        logger.error("回充导航超时(%.0fs)，终止", timeout)
        self.client.emergency_stop()
        return ChargeStatus.ERROR

    # ---------- 无图近距离直充 ----------
    def dock_without_map(self) -> ChargeStatus:
        """
        无图近距离直充（等价APP遥控页一键回充）。
        限制：机器狗必须已在充电桩正前方≤1.1m，无需地图标记。
        """
        logger.info("执行无图近距离对接...")
        self.client._check(
            self.client._post("/charge/dock_direct"),
            "无图对接"
        )
        return self._wait_for_charge(timeout=60.0)

    # ---------- 出桩控制 ----------
    def auto_undock(self) -> bool:
        """
        自动出桩，脱离充电桩，恢复运动控制权限。
        充电中(CHARGING)调用会被拒绝。
        """
        status = self.get_status()
        if status == ChargeStatus.CHARGING:
            logger.error("设备正在充电中，无法出桩，请先停止充电或等待充满")
            return False

        logger.info("执行自动出桩...")
        self._current_status = ChargeStatus.UNDOCKING
        self._notify(self._current_status)

        self.client._check(
            self.client._post("/charge/undock"),
            "自动出桩"
        )

        # 等待出桩完成
        for _ in range(30):
            time.sleep(STATUS_POLL_INTERVAL)
            if self.get_status() == ChargeStatus.IDLE:
                logger.info("出桩成功，运动控制已恢复")
                self._notify(ChargeStatus.IDLE)
                return True
        logger.error("出桩超时")
        return False

    # ---------- 故障排查 ----------
    def diagnose_dock_failure(self) -> dict:
        """对接失败综合诊断（对齐说明书故障排查方案）"""
        report = {"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"), "issues": []}

        # 1. 定位检查
        try:
            health = self.map_mgr.check_localization_health()
            if not health["ready"]:
                report["issues"].append(f"定位异常: {health}")
        except SDKError as e:
            report["issues"].append(f"定位查询失败: {e}")

        # 2. 充电桩标记检查
        station = self.map_mgr.get_charge_station()
        if not station or not station.marked:
            report["issues"].append("充电桩未标记或标记丢失")

        # 3. 雷达遮挡检查
        try:
            data = self.client._check(self.client._get("/sensor/lidar_status"), "雷达状态")
            if data.get("occluded"):
                report["issues"].append("激光雷达被遮挡")
        except SDKError:
            pass

        # 4. 电池/充电通信
        try:
            bat = self.get_battery()
            report["battery"] = bat
        except SDKError as e:
            report["issues"].append(f"电池通信异常: {e}")

        report["suggestion"] = self._build_suggestion(report["issues"])
        logger.info("故障诊断报告: %s", report)
        return report

    @staticmethod
    def _build_suggestion(issues: list) -> str:
        if not issues:
            return "未检测到明显异常，建议人工检查充电桩电源及物理连接"
        tips = []
        for issue in issues:
            if "定位" in issue:
                tips.append("将机器狗移至建图起点，调用 reset_localization() 重置定位")
            if "充电桩" in issue:
                tips.append("重新标记充电桩：遥控至正前方110cm后调用 mark_charge_station()")
            if "雷达" in issue:
                tips.append("清理雷达视场遮挡物")
            if "电池" in issue:
                tips.append("检查充电桩电源及通信配对")
        tips.append("若以上无效，调用 restart_nx() 重启Orin NX算力板")
        return "；".join(tips)
