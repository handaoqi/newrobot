"""
钢镚L1智航Pro - SDK通信客户端基类
负责与Jetson Orin NX算力板建立TCP/HTTP通信，封装通用请求接口。

说明：官方SDK需联系智身科技技术支持获取。本文件为标准化通信封装，
实际接口路径、鉴权方式以官方API文档为准，可在此基础上替换底层实现。
"""

import json
import time
import logging
import requests
from typing import Any, Dict, Optional
from config import ROBOT_IP, ROBOT_PORT, COMM_TIMEOUT, HEARTBEAT_INTERVAL

logger = logging.getLogger(__name__)


class SDKError(Exception):
    """SDK通用异常"""
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[SDK Error {code}] {message}")


class ZSL1SDKClient:
    """机器狗SDK通信客户端"""

    def __init__(self, ip: str = ROBOT_IP, port: int = ROBOT_PORT):
        self.base_url = f"http://{ip}:{port}/api/v1"
        self.session = requests.Session()
        self.session.timeout = COMM_TIMEOUT
        self._connected = False
        self._last_heartbeat = 0.0

    # ---------- 连接管理 ----------
    def connect(self) -> bool:
        """建立连接并鉴权"""
        try:
            resp = self._get("/system/info")
            if resp.get("code") == 0:
                self._connected = True
                logger.info("SDK连接成功: %s", resp.get("data", {}).get("model", "unknown"))
                return True
            raise SDKError(resp.get("code", -1), resp.get("msg", "连接失败"))
        except requests.RequestException as e:
            logger.error("SDK连接失败: %s", e)
            raise SDKError(-1, f"网络连接失败: {e}")

    def disconnect(self):
        """断开连接"""
        self._connected = False
        self.session.close()
        logger.info("SDK连接已断开")

    def heartbeat(self) -> bool:
        """心跳保活"""
        if time.time() - self._last_heartbeat < HEARTBEAT_INTERVAL:
            return True
        try:
            resp = self._get("/system/heartbeat")
            self._last_heartbeat = time.time()
            return resp.get("code") == 0
        except Exception:
            self._connected = False
            return False

    @property
    def is_connected(self) -> bool:
        return self._connected

    # ---------- 通用请求封装 ----------
    def _get(self, path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        resp = self.session.get(url, params=params, timeout=COMM_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def _post(self, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        resp = self.session.post(url, json=data or {}, timeout=COMM_TIMEOUT)
        resp.raise_for_status()
        return resp.json()

    def _check(self, resp: Dict[str, Any], action: str = "操作"):
        """统一检查返回码，非0抛出异常"""
        code = resp.get("code", -1)
        if code != 0:
            raise SDKError(code, f"{action}失败: {resp.get('msg', '未知错误')}")
        return resp.get("data", {})

    # ---------- 系统控制 ----------
    def get_system_info(self) -> Dict:
        """获取设备系统信息"""
        return self._check(self._get("/system/info"), "获取系统信息")

    def restart_nx(self) -> bool:
        """重启Jetson Orin NX算力板（说明书故障排查方案）"""
        logger.warning("正在重启Orin NX算力板...")
        self._check(self._post("/system/restart_nx"), "重启算力板")
        time.sleep(15)  # 等待重启
        return self.connect()

    def emergency_stop(self) -> bool:
        """紧急停止（全模块急停）"""
        logger.warning("触发紧急停止")
        return self._check(self._post("/control/estop"), "紧急停止").get("success", False)
