"""
钢镚L1智航Pro - 地图管理模块
负责地图加载、充电桩坐标标记、定位状态查询。
对齐说明书：单台最多5张地图，每张地图需独立标记充电桩。
"""

import logging
from dataclasses import dataclass
from typing import List, Optional, Dict
from sdk_client import ZSL1SDKClient, SDKError
from config import DOCK_DISTANCE_M, LOCALIZATION_TOLERANCE_M, HEADING_TOLERANCE_DEG

logger = logging.getLogger(__name__)


@dataclass
class Pose2D:
    """2D位姿：平面坐标+朝向角"""
    x: float          # 地图坐标系X(m)
    y: float          # 地图坐标系Y(m)
    yaw: float        # 朝向角(度)，0°为建图初始方向

    def to_dict(self) -> Dict:
        return {"x": self.x, "y": self.y, "yaw": self.yaw}


@dataclass
class ChargeStation:
    """充电桩信息"""
    map_id: str
    pose: Pose2D              # 充电桩正前方110cm标记点位姿
    dock_pose: Pose2D         # 充电桩本体坐标（自动计算）
    marked: bool = False

    def to_dict(self) -> Dict:
        return {
            "map_id": self.map_id,
            "mark_pose": self.pose.to_dict(),
            "dock_pose": self.dock_pose.to_dict(),
            "marked": self.marked,
        }


class MapManager:
    """地图与充电桩管理器"""

    MAX_MAPS = 5  # 说明书限制：单台最多5张地图

    def __init__(self, client: ZSL1SDKClient):
        self.client = client
        self.current_map_id: Optional[str] = None
        self.charge_stations: Dict[str, ChargeStation] = {}  # map_id -> station

    # ---------- 地图管理 ----------
    def list_maps(self) -> List[Dict]:
        """列出所有已保存地图"""
        data = self.client._check(self.client._get("/map/list"), "获取地图列表")
        maps = data.get("maps", [])
        logger.info("当前共 %d 张地图（上限%d）", len(maps), self.MAX_MAPS)
        return maps

    def load_map(self, map_id: str) -> bool:
        """加载指定地图"""
        data = self.client._check(
            self.client._post("/map/load", {"map_id": map_id}),
            f"加载地图[{map_id}]"
        )
        self.current_map_id = map_id
        logger.info("地图加载成功: %s", map_id)
        # 尝试读取已标记的充电桩
        self._load_charge_station(map_id)
        return True

    def save_edits(self, map_id: Optional[str] = None) -> bool:
        """保存地图编辑（充电桩标记等）"""
        mid = map_id or self.current_map_id
        if not mid:
            raise SDKError(-2, "未加载地图，无法保存")
        self.client._check(
            self.client._post("/map/save", {"map_id": mid}),
            f"保存地图[{mid}]"
        )
        logger.info("地图编辑已保存: %s", mid)
        return True

    # ---------- 定位状态 ----------
    def get_current_pose(self) -> Pose2D:
        """获取机器狗当前定位位姿"""
        data = self.client._check(self.client._get("/localization/pose"), "获取当前位姿")
        return Pose2D(x=data["x"], y=data["y"], yaw=data["yaw"])

    def check_localization_health(self) -> Dict:
        """
        定位健康检查（对齐说明书定位要求）：
        - 起点在建图轨迹2m内
        - 航向偏差<±15°
        - 15m内特征点数量
        """
        data = self.client._check(
            self.client._get("/localization/health"),
            "定位健康检查"
        )
        health = {
            "in_track": data.get("distance_to_track", 999) <= LOCALIZATION_TOLERANCE_M,
            "heading_ok": abs(data.get("heading_error", 999)) <= HEADING_TOLERANCE_DEG,
            "feature_count": data.get("feature_count", 0),
            "corner_count": data.get("corner_count", 0),
            "lidar_occluded": data.get("lidar_occluded", False),
        }
        health["ready"] = (
            health["in_track"]
            and health["heading_ok"]
            and health["feature_count"] >= 1000
            and health["corner_count"] >= 500
            and not health["lidar_occluded"]
        )
        logger.info("定位健康: %s", health)
        return health

    def reset_localization(self) -> bool:
        """重置定位（故障排查：定位漂移时调用）"""
        logger.warning("重置定位初始化...")
        self.client._check(self.client._post("/localization/reset"), "重置定位")
        return True

    # ---------- 充电桩标记 ----------
    def mark_charge_station(self, map_id: Optional[str] = None) -> ChargeStation:
        """
        标记充电桩（核心前置步骤）。
        调用前必须：手动遥控机器狗至充电桩正前方110cm，正对充电桩。
        系统自动采集当前位姿作为标记点，计算充电桩本体坐标并写入地图。
        """
        mid = map_id or self.current_map_id
        if not mid:
            raise SDKError(-2, "请先加载地图再标记充电桩")

        # 1. 采集当前位姿（机器狗应停在充电桩正前方110cm）
        mark_pose = self.get_current_pose()
        logger.info("采集充电桩标记点位姿: x=%.3f y=%.3f yaw=%.1f°",
                    mark_pose.x, mark_pose.y, mark_pose.yaw)

        # 2. 计算充电桩本体坐标（沿当前朝向反方向推进1.1m）
        import math
        rad = math.radians(mark_pose.yaw)
        dock_x = mark_pose.x - DOCK_DISTANCE_M * math.cos(rad)
        dock_y = mark_pose.y - DOCK_DISTANCE_M * math.sin(rad)
        dock_pose = Pose2D(x=dock_x, y=dock_y, yaw=mark_pose.yaw)

        # 3. 写入地图
        station = ChargeStation(
            map_id=mid,
            pose=mark_pose,
            dock_pose=dock_pose,
            marked=True,
        )
        self.client._check(
            self.client._post("/map/set_charge_station", {
                "map_id": mid,
                "mark_pose": mark_pose.to_dict(),
                "dock_pose": dock_pose.to_dict(),
                "safe_distance": DOCK_DISTANCE_M,
            }),
            "标记充电桩"
        )
        self.charge_stations[mid] = station
        self.save_edits(mid)
        logger.info("充电桩标记成功并已持久化: map=%s", mid)
        return station

    def get_charge_station(self, map_id: Optional[str] = None) -> Optional[ChargeStation]:
        """获取当前地图已标记的充电桩"""
        mid = map_id or self.current_map_id
        return self.charge_stations.get(mid)

    def _load_charge_station(self, map_id: str):
        """从地图读取已保存的充电桩标记"""
        try:
            data = self.client._check(
                self.client._get("/map/get_charge_station", {"map_id": map_id}),
                "读取充电桩标记"
            )
            if data and data.get("marked"):
                station = ChargeStation(
                    map_id=map_id,
                    pose=Pose2D(**data["mark_pose"]),
                    dock_pose=Pose2D(**data["dock_pose"]),
                    marked=True,
                )
                self.charge_stations[map_id] = station
                logger.info("已加载充电桩标记: map=%s", map_id)
        except SDKError as e:
            logger.warning("地图[%s]暂无充电桩标记: %s", map_id, e)
