# 钢镚L1智航Pro 自动充电SDK代码

> 对应硬件：ZSL-1 Roamer X Pro / Jetson Orin NX 16G / Mid 360激光雷达
> 对齐说明书：《钢镚L1智航Pro软件使用说明书V0.5》自主回充章节

## 文件结构

```
zsl1_auto_charge/
├── config.py                  # 配置文件（IP、距离、超时、重试参数）
├── sdk_client.py              # SDK通信客户端基类（TCP/HTTP封装）
├── map_manager.py             # 地图管理 + 充电桩标记 + 定位健康检查
├── charge_controller.py       # 核心：自动回充/状态轮询/出桩/故障诊断
├── example_auto_charge.py     # 完整示例（4种场景，推荐参考）
├── simple_auto_charge.py      # 极简单文件版（快速集成到现有项目）
├── ros2_auto_charge_node.py   # ROS2节点示例（Orin NX原生环境）
└── README.md                  # 本文档
```

## 快速开始

### 1. 环境准备

```bash
# Python 3.8+
pip install requests

# 修改配置
vim config.py
#   ROBOT_IP = "192.168.1.100"   # 改为机器狗实际IP
#   ROBOT_PORT = 8080             # 改为官方SDK实际端口
```

### 2. 首次部署：标记充电桩（一次性操作）

```bash
# 步骤：
# 1. 用原厂APP遥控机器狗到充电桩【正前方110cm】，正对充电桩
# 2. 运行标记脚本
python example_auto_charge.py setup
# 3. 按回车确认，系统自动采集位姿并写入地图
```

### 3. 触发自动回充

```bash
python example_auto_charge.py charge
```

### 4. 充电完成出桩

```bash
python example_auto_charge.py undock
```

### 5. 全自动闭环（回充→充满→出桩）

```bash
python example_auto_charge.py cycle
```

## 核心API对照表

| 功能 | 方法 | 对应APP操作 | 说明 |
|------|------|------------|------|
| 连接设备 | `client.connect()` | APP连接WiFi | 建立SDK通信 |
| 加载地图 | `map_mgr.load_map(map_id)` | 选择地图 | 单台最多5张 |
| 标记充电桩 | `map_mgr.mark_charge_station()` | 地图编辑→充电桩标记 | 需停在正前方110cm |
| 定位健康检查 | `map_mgr.check_localization_health()` | - | 校验2m/±15°/特征点 |
| 触发自动回充 | `charger.auto_charge(block=True)` | 巡航结束→返回充电 | 阻塞等待充电成功 |
| 查询充电状态 | `charger.get_status()` | - | 返回ChargeStatus枚举 |
| 查询电池 | `charger.get_battery()` | - | 电量/电压/电流 |
| 自动出桩 | `charger.auto_undock()` | 遥控页→出桩 | 恢复运动控制 |
| 无图直充 | `charger.dock_without_map()` | 遥控页→回充 | 需在充电桩前≤1.1m |
| 故障诊断 | `charger.diagnose_dock_failure()` | - | 综合排查+修复建议 |
| 紧急停止 | `client.emergency_stop()` | 红色急停按钮 | 全模块急停 |
| 重启算力板 | `client.restart_nx()` | - | Orin NX重启 |

## 充电状态流转

```
IDLE ──auto_charge()──→ NAV_TO_CHARGE ──到达──→ DOCKING ──对接成功──→ CHARGING
                          │                        │
                          │                        └─对接失败─→ DOCK_FAIL ──重试──→ NAV_TO_CHARGE
                          └─超时/异常──→ ERROR (自动estop)

CHARGING ──充满/手动──→ UNDOCK_READY ──auto_undock()──→ UNDOCKING ──→ IDLE
```

## 关键约束（严格对齐说明书）

1. **标记距离**：机器狗必须在充电桩正前方 **110cm**，偏离会导致对接失败
2. **定位要求**：开机点在建图轨迹 **2m内**，航向偏差 **<±15°**
3. **安全区**：充电桩前方 **1.5m** 内无障碍物
4. **充电锁定**：`CHARGING` 状态下所有运动控制接口被锁定，必须先出桩
5. **环境限制**：弱光、高反光地面、草地、积雪>5mm、玻璃墙场景回充不可靠
6. **雷达盲区**：前方30cm为感知盲区，障碍物需人工确认
7. **地图独立**：每张地图需单独标记充电桩，切换地图后重新设置

## 异常处理策略

代码内置三级容错：

1. **自动重试**：对接失败自动重试最多3次，间隔5秒
2. **超时保护**：回充导航默认300秒超时，超时自动急停
3. **故障诊断**：失败后调用 `diagnose_dock_failure()` 输出定位/雷达/电池/标记综合报告

常见问题处理：

| 现象 | 原因 | 处理 |
|------|------|------|
| 回充路径乱飘 | 定位漂移 | `map_mgr.reset_localization()` 重置定位 |
| 到充电桩前停下不对接 | 1.5m内有障碍物 | 清理障碍物后重试 |
| 提示充电桩未标记 | 地图切换/标记丢失 | 重新调用 `mark_charge_station()` |
| 所有接口无响应 | 算力板死机 | `client.restart_nx()` 重启Orin NX |
| 充电中无法控制 | 正常锁定状态 | 调用 `auto_undock()` 出桩后恢复 |

## 集成到现有业务

```python
from sdk_client import ZSL1SDKClient
from map_manager import MapManager
from charge_controller import ChargeController

# 初始化
client = ZSL1SDKClient(ip="192.168.1.100")
client.connect()
map_mgr = MapManager(client)
map_mgr.load_map("your_map_id")
charger = ChargeController(client, map_mgr)

# 巡检完成后自动回充
status = charger.auto_charge(block=True)
if status.value == "CHARGING":
    print("充电成功")

# 下次作业前出桩
charger.auto_undock()
client.disconnect()
```

## 重要说明

1. **官方SDK获取**：本代码基于说明书功能逻辑设计的标准化封装，实际API路径、消息格式、鉴权方式需以智身科技技术支持提供的官方SDK包为准。获取后只需调整 `sdk_client.py` 中的接口路径和请求格式即可。
2. **ROS开发**：Jetson Orin NX原生支持ROS2，`ros2_auto_charge_node.py` 提供了节点框架，需替换为官方提供的 `.srv`/`.msg` 消息定义。
3. **安全第一**：自动回充过程中务必保持人工肉眼监控，动态障碍物需及时干预（说明书强制要求）。
