#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
钢镚L1智航Pro - ROS2自动充电节点示例
====================================
基于Jetson Orin NX原生ROS2环境，通过话题/服务实现自动充电。
需官方提供ROS接口定义(.srv/.msg)后替换实际消息类型。

话题/服务约定（以官方ROS Demo为准）：
  服务: /nav/auto_charge        -> 触发自动回充
  服务: /map/set_charge_point   -> 标记充电桩
  服务: /charge/undock          -> 自动出桩
  话题: /charge/status          -> 充电状态 (std_msgs/String)
  话题: /battery_state          -> 电池信息
"""

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from std_msgs.msg import String
from geometry_msgs.msg import Pose2D
import time


# 伪代码占位：实际需替换为官方ROS包中的消息类型
# from zsl1_interfaces.srv import AutoCharge, SetChargePoint, Undock
# from zsl1_interfaces.msg import ChargeStatus


class AutoChargeNode(Node):
    """ROS2自动充电节点"""

    def __init__(self):
        super().__init__("zsl1_auto_charge")

        # 状态订阅
        self.status_sub = self.create_subscription(
            String, "/charge/status", self._on_status, 10
        )
        self.current_status = "IDLE"

        # 服务客户端（实际类型替换）
        # self.auto_charge_cli = self.create_client(AutoCharge, "/nav/auto_charge")
        # self.set_point_cli = self.create_client(SetChargePoint, "/map/set_charge_point")
        # self.undock_cli = self.create_client(Undock, "/charge/undock")

        self.get_logger().info("自动充电节点已启动")

    def _on_status(self, msg: String):
        if msg.data != self.current_status:
            self.get_logger().info(f"充电状态: {self.current_status} -> {msg.data}")
            self.current_status = msg.data

    def mark_charge_station(self, map_id: str):
        """标记充电桩：需先遥控到正前方110cm"""
        self.get_logger().info("标记充电桩...")
        # req = SetChargePoint.Request()
        # req.map_id = map_id
        # req.pose = self._get_current_pose()
        # future = self.set_point_cli.call_async(req)
        # rclpy.spin_until_future_complete(self, future)
        # return future.result().success
        self.get_logger().warn("请替换为官方SetChargePoint服务类型")
        return True

    def auto_charge(self, map_id: str, timeout=300) -> bool:
        """触发自动回充，阻塞等待"""
        self.get_logger().info(f"触发自动回充, map={map_id}")
        # req = AutoCharge.Request()
        # req.map_id = map_id
        # future = self.auto_charge_cli.call_async(req)
        # rclpy.spin_until_future_complete(self, future)

        start = time.time()
        while time.time() - start < timeout:
            rclpy.spin_once(self, timeout_sec=0.5)
            if self.current_status == "CHARGING":
                self.get_logger().info("充电成功")
                return True
            if self.current_status == "DOCK_FAIL":
                self.get_logger().error("对接失败")
                return False
        return False

    def auto_undock(self) -> bool:
        """自动出桩"""
        self.get_logger().info("执行出桩...")
        # req = Undock.Request()
        # future = self.undock_cli.call_async(req)
        # rclpy.spin_until_future_complete(self, future)
        return True


def main(args=None):
    rclpy.init(args=args)
    node = AutoChargeNode()
    try:
        # 示例：触发自动回充
        node.auto_charge(map_id="map_01")
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
