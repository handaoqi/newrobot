#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
钢镚L1智航Pro - 自动充电完整使用示例
======================================
场景1：首次部署，标记充电桩（一次性）
场景2：巡检任务结束，触发自动回充
场景3：充电完成，自动出桩继续作业

运行前准备：
1. 联系智身科技技术支持获取官方SDK，确认API路径与本文件对齐
2. 修改 config.py 中 ROBOT_IP 为实际机器狗IP
3. pip install requests
4. 机器狗与充电桩已完成APP配对绑定
"""

import logging
import sys
import time
from sdk_client import ZSL1SDKClient, SDKError
from map_manager import MapManager
from charge_controller import ChargeController, ChargeStatus
from config import LOG_LEVEL, LOG_FILE

# ========== 日志配置 ==========
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("AutoChargeDemo")


# ========== 状态回调示例 ==========
def on_status_change(status: ChargeStatus):
    """充电状态变化时触发，可接入业务告警/UI"""
    messages = {
        ChargeStatus.NAV_TO_CHARGE: "→ 正在导航前往充电桩",
        ChargeStatus.DOCKING: "→ 到达充电桩，执行精准对接",
        ChargeStatus.CHARGING: "✓ 对接成功，开始充电",
        ChargeStatus.DOCK_FAIL: "✗ 对接失败",
        ChargeStatus.UNDOCKING: "→ 正在出桩",
        ChargeStatus.IDLE: "✓ 已恢复空闲状态",
        ChargeStatus.ERROR: "✗ 系统异常",
    }
    logger.info("状态通知: %s", messages.get(status, status.value))


# ========== 场景1：首次部署标记充电桩 ==========
def setup_charge_station(map_id: str):
    """
    首次部署流程：
    1. 连接机器狗
    2. 加载目标地图
    3. 【人工操作】遥控机器狗至充电桩正前方110cm，正对充电桩
    4. 调用标记接口，自动采集位姿并写入地图
    """
    logger.info("========== 场景1：充电桩首次部署 ==========")
    client = ZSL1SDKClient()
    client.connect()
    map_mgr = MapManager(client)

    # 加载地图
    map_mgr.load_map(map_id)

    # 等待人工就位
    logger.info("请手动遥控机器狗至充电桩【正前方110cm】，正对充电桩二维码")
    logger.info("就位后按回车键开始标记...")
    input()

    # 标记充电桩
    station = map_mgr.mark_charge_station(map_id)
    logger.info("充电桩标记完成:")
    logger.info("  标记点(机器狗位姿): x=%.3f y=%.3f yaw=%.1f°",
                station.pose.x, station.pose.y, station.pose.yaw)
    logger.info("  充电桩本体坐标:   x=%.3f y=%.3f",
                station.dock_pose.x, station.dock_pose.y)

    client.disconnect()
    logger.info("部署完成，充电桩坐标已持久化保存")


# ========== 场景2：巡检结束自动回充 ==========
def run_auto_charge(map_id: str):
    """
    常规业务流程：
    1. 连接设备，加载地图
    2. 执行巡检任务（此处省略巡检逻辑）
    3. 巡检完成，触发自动回充
    4. 阻塞等待充电完成状态
    5. 失败自动重试+诊断
    """
    logger.info("========== 场景2：巡检结束自动回充 ==========")
    client = ZSL1SDKClient()
    client.connect()

    map_mgr = MapManager(client)
    map_mgr.load_map(map_id)

    charger = ChargeController(client, map_mgr)
    charger.on_status_change(on_status_change)

    # --- 此处可插入自定义巡检逻辑 ---
    logger.info("模拟巡检任务执行中...")
    time.sleep(2)
    logger.info("巡检任务完成，准备自动回充")
    # --------------------------------

    # 触发自动回充（阻塞模式）
    try:
        final_status = charger.auto_charge(block=True, timeout=300)

        if final_status == ChargeStatus.CHARGING:
            bat = charger.get_battery()
            logger.info("=" * 50)
            logger.info("自动充电成功！当前电量: %d%%  电压: %.2fV",
                        bat["percent"], bat["voltage"])
            logger.info("=" * 50)
        else:
            logger.error("自动回充未成功，最终状态: %s", final_status.value)
            report = charger.diagnose_dock_failure()
            logger.error("故障诊断: %s", report["suggestion"])

    except SDKError as e:
        logger.error("回充异常: %s", e)
        client.emergency_stop()
    finally:
        client.disconnect()


# ========== 场景3：充电完成出桩继续作业 ==========
def undock_and_continue(map_id: str):
    """
    充电完成后：
    1. 查询充电状态
    2. 调用自动出桩
    3. 恢复运动控制，继续下一轮作业
    """
    logger.info("========== 场景3：充电完成出桩 ==========")
    client = ZSL1SDKClient()
    client.connect()

    map_mgr = MapManager(client)
    map_mgr.load_map(map_id)
    charger = ChargeController(client, map_mgr)

    # 查询当前状态
    status = charger.get_status()
    bat = charger.get_battery()
    logger.info("当前状态: %s  电量: %d%%", status.value, bat["percent"])

    if status == ChargeStatus.CHARGING and bat["percent"] < 95:
        logger.warning("设备正在充电且未充满，确认要中断充电出桩吗？(y/n)")
        if input().strip().lower() != "y":
            logger.info("取消出桩")
            client.disconnect()
            return

    # 执行出桩
    if charger.auto_undock():
        logger.info("出桩成功，设备已恢复可操控状态，可继续执行巡检任务")
    else:
        logger.error("出桩失败")

    client.disconnect()


# ========== 一键全自动流程 ==========
def full_auto_cycle(map_id: str):
    """
    完整闭环：连接→加载地图→自动回充→等待充满→自动出桩
    适合无人值守场景。
    """
    logger.info("========== 全自动充电闭环 ==========")
    client = ZSL1SDKClient()
    client.connect()
    map_mgr = MapManager(client)
    map_mgr.load_map(map_id)
    charger = ChargeController(client, map_mgr)
    charger.on_status_change(on_status_change)

    try:
        # 1. 自动回充
        status = charger.auto_charge(block=True)
        if status != ChargeStatus.CHARGING:
            logger.error("回充失败，终止闭环")
            return

        # 2. 等待充满（轮询电量）
        logger.info("等待电池充满...")
        while True:
            bat = charger.get_battery()
            logger.info("充电中: %d%%", bat["percent"])
            if bat["percent"] >= 98:
                logger.info("电池已充满")
                break
            time.sleep(30)

        # 3. 自动出桩
        charger.auto_undock()
        logger.info("全自动充电闭环完成")

    except KeyboardInterrupt:
        logger.info("用户中断")
    finally:
        client.disconnect()


# ========== 主入口 ==========
if __name__ == "__main__":
    TARGET_MAP_ID = "map_office_01"  # 替换为实际地图ID

    if len(sys.argv) < 2:
        print("用法:")
        print("  python example_auto_charge.py setup    # 首次部署标记充电桩")
        print("  python example_auto_charge.py charge   # 触发自动回充")
        print("  python example_auto_charge.py undock   # 充电完成出桩")
        print("  python example_auto_charge.py cycle    # 全自动充电闭环")
        sys.exit(0)

    cmd = sys.argv[1].lower()
    if cmd == "setup":
        setup_charge_station(TARGET_MAP_ID)
    elif cmd == "charge":
        run_auto_charge(TARGET_MAP_ID)
    elif cmd == "undock":
        undock_and_continue(TARGET_MAP_ID)
    elif cmd == "cycle":
        full_auto_cycle(TARGET_MAP_ID)
    else:
        print(f"未知命令: {cmd}")
