#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
钢镚L1智航Pro - 自动充电极简版（单文件，快速集成）
适合直接嵌入现有业务代码，无需拆分模块。
依赖: pip install requests
"""

import requests
import time
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
log = logging.getLogger("SimpleCharge")

# ====== 配置（按实际修改）======
ROBOT_IP = "192.168.1.100"
ROBOT_PORT = 8080
MAP_ID = "map_01"
MAX_RETRY = 3
BASE = f"http://{ROBOT_IP}:{ROBOT_PORT}/api/v1"


def api_get(path, params=None):
    r = requests.get(f"{BASE}{path}", params=params, timeout=5)
    r.raise_for_status()
    d = r.json()
    if d.get("code") != 0:
        raise RuntimeError(f"API错误: {d.get('msg')}")
    return d.get("data", {})


def api_post(path, data=None):
    r = requests.post(f"{BASE}{path}", json=data or {}, timeout=5)
    r.raise_for_status()
    d = r.json()
    if d.get("code") != 0:
        raise RuntimeError(f"API错误: {d.get('msg')}")
    return d.get("data", {})


def mark_charge_station():
    """
    标记充电桩（首次部署调用一次）。
    调用前：手动把机器狗开到充电桩正前方110cm，正对充电桩。
    """
    pose = api_get("/localization/pose")
    log.info("当前位姿: x=%.3f y=%.3f yaw=%.1f", pose["x"], pose["y"], pose["yaw"])
    api_post("/map/load", {"map_id": MAP_ID})
    api_post("/map/set_charge_station", {
        "map_id": MAP_ID,
        "mark_pose": pose,
        "safe_distance": 1.10,
    })
    api_post("/map/save", {"map_id": MAP_ID})
    log.info("充电桩标记完成并保存")


def auto_charge(timeout=300):
    """
    触发自动回充，阻塞等待充电成功。
    返回: True=成功, False=失败
    """
    # 前置检查
    health = api_get("/localization/health")
    if health.get("distance_to_track", 999) > 2.0:
        log.error("定位偏离建图轨迹超过2m，请先重置定位")
        return False

    # 下发回充
    api_post("/navigation/auto_charge", {"map_id": MAP_ID})
    log.info("回充指令已下发，导航前往充电桩...")

    start = time.time()
    retry = 0
    while time.time() - start < timeout:
        status = api_get("/charge/status").get("status", "IDLE")
        log.info("状态: %s", status)

        if status == "CHARGING":
            bat = api_get("/power/battery")
            log.info("✓ 充电成功！当前电量: %d%%", bat["percent"])
            return True

        if status == "DOCK_FAIL":
            retry += 1
            log.warning("对接失败(%d/%d)，5秒后重试", retry, MAX_RETRY)
            if retry >= MAX_RETRY:
                api_post("/control/estop")
                log.error("重试耗尽，回充失败")
                return False
            time.sleep(5)
            api_post("/navigation/auto_charge", {"retry": True})
            continue

        time.sleep(0.5)

    log.error("回充超时")
    api_post("/control/estop")
    return False


def auto_undock():
    """自动出桩，恢复运动控制"""
    api_post("/charge/undock")
    log.info("出桩指令已下发")
    for _ in range(30):
        time.sleep(0.5)
        if api_get("/charge/status").get("status") == "IDLE":
            log.info("✓ 出桩成功，设备恢复可控")
            return True
    log.error("出桩超时")
    return False


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "charge"

    if cmd == "mark":
        mark_charge_station()
    elif cmd == "charge":
        auto_charge()
    elif cmd == "undock":
        auto_undock()
    else:
        print("用法: python simple_auto_charge.py [mark|charge|undock]")
