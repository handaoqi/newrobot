"""
钢镚L1智航Pro - 自动充电SDK配置文件
对应硬件：ZSL-1 Roamer X Pro / Jetson Orin NX 16G
"""

# ========== 通信配置 ==========
ROBOT_IP = "192.168.1.100"          # 机器狗Orin NX算力板IP（WiFi热点默认网段）
ROBOT_PORT = 8080                    # SDK服务端口（以官方协议为准）
COMM_TIMEOUT = 5.0                   # 通信超时时间(秒)
HEARTBEAT_INTERVAL = 1.0             # 心跳间隔(秒)

# ========== 充电桩参数（严格对齐说明书规范）==========
DOCK_DISTANCE_M = 1.10               # 标记/对接标准距离：充电桩正前方110cm
DOCK_SAFE_ZONE_M = 1.5               # 对接安全区：充电桩前方1.5m无障碍物
DOCK_APPROACH_SPEED = 0.3            # 接近充电桩速度(m/s)，低于巡航0.6m/s

# ========== 导航参数 ==========
CRUISE_SPEED = 0.6                   # 巡航速度(m/s)，说明书固定值
LOCALIZATION_TOLERANCE_M = 2.0       # 开机定位允许偏差：建图轨迹2m内
HEADING_TOLERANCE_DEG = 15.0         # 航向偏差容忍：±15°

# ========== 重试策略 ==========
MAX_DOCK_RETRY = 3                   # 对接失败最大重试次数
RETRY_INTERVAL_SEC = 5.0             # 重试间隔(秒)
STATUS_POLL_INTERVAL = 0.5           # 状态轮询间隔(秒)
NAV_TIMEOUT_SEC = 300.0              # 回充导航最大超时(秒)，按场地调整

# ========== 日志 ==========
LOG_LEVEL = "INFO"
LOG_FILE = "auto_charge.log"
