#include "serial.hpp"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdexcept>
#include <iostream>

static void serial_set_param(int fd, int baudrate)
{
    struct termios param;
    tcgetattr(fd, &param); // Get terminal properties

    cfsetospeed(&param, baudrate);
    cfsetispeed(&param, baudrate);

    param.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    param.c_oflag &= ~OPOST;
    param.c_cflag |= (CLOCAL | CREAD | CS8);
    param.c_cflag &= ~(PARENB | CSTOPB | CRTSCTS);
    param.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

    param.c_cc[VMIN] = 1;
    param.c_cc[VTIME] = 255;

    tcsetattr(fd, TCSANOW, &param);
}

int serial::set_baudrate(int baudrate)
{
    struct termios param;
    if (tcgetattr(fd, &param) < 0)
    {
        std::cerr << "Failed to get terminal attributes" << std::endl;
        return -1;
    }
    if (cfsetispeed(&param, baudrate) < 0 || cfsetospeed(&param, baudrate) < 0)
    {
        std::cerr << "Failed to set baud rate" << std::endl;
        return -1;
    }
    if (tcsetattr(fd, TCSANOW, &param) < 0)
    {
        std::cerr << "Failed to set terminal attributes" << std::endl;
        return -1;
    }
    if (tcflush(fd, TCIOFLUSH) < 0)
    {
        std::cerr << "Failed to flush terminal" << std::endl;
        return -1;
    }
    return 0;
}

serial::serial(const std::string &port, const int baudrate)
{
    fd = open(port.c_str(), O_RDWR | O_NOCTTY);
    if (fd < 0)
    {
        throw std::runtime_error("Failed to open serial port: " + port);
    }
    serial_set_param(fd, baudrate);
    tcflush(fd, TCIOFLUSH);
}

serial::~serial()
{
    close(fd);
}

int serial::write_data(const uint8_t *data, const size_t size)
{
    return write(fd, data, size);
}

int serial::read_data(uint8_t *data, const size_t size)
{
    return read(fd, data, size);
}

int serial::flush_data(void)
{
    return tcflush(fd, TCIOFLUSH);
}
