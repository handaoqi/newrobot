#include "mavlink_wrapp.hpp"
#include "serial.hpp"
#include <iostream>

using namespace std;

MavlinkWrapper::MavlinkWrapper()
    : port(nullptr),
      rx_status({0}), rx_msg({0})
{
}

void MavlinkWrapper::setup(serial *_port)
{
    port = _port;
    read_thread = thread(&MavlinkWrapper::read_loop, this);
    write_thread = thread(&MavlinkWrapper::write_loop, this);
}

MavlinkWrapper::~MavlinkWrapper()
{
    should_exit = true;
    write_cv.notify_all();
    pthread_cancel(read_thread.native_handle());
    pthread_cancel(write_thread.native_handle());
    if (read_thread.joinable())
        read_thread.join();
    if (write_thread.joinable())
        write_thread.join();
}

void MavlinkWrapper::send_message(const mavlink_message_t &msg)
{
    lock_guard<mutex> lock(send_message_mtx);
    send_msg_list.emplace_back(make_unique<mavlink_message_t>(msg));
    write_cv.notify_one(); // Notify the write thread that a new message is available
}

void MavlinkWrapper::register_consumer(int msg_id, MavlinkMsgConsumer *consumer)
{
    lock_guard<mutex> lock(consumer_mtx);
    if (consumers.find(msg_id) != consumers.end())
    {
        cerr << "Warning: Consumer for msg_id " << msg_id << " already registered." << endl;
        return;
    }
    consumers[msg_id] = consumer;
}

void MavlinkWrapper::read_loop()
{
    size_t read_size;

    while (true)
    {
        read_size = port->read_data(read_buf, sizeof(read_buf));
        if (read_size > 0)
        {
            for (size_t i = 0; i < read_size; ++i)
            {
                uint8_t byte = read_buf[i];
                if (mavlink_parse_char(MAVLINK_COMM_0, byte, &rx_msg, &rx_status) != MAVLINK_FRAMING_INCOMPLETE)
                {
                    lock_guard<mutex> lock(consumer_mtx);
                    auto it = consumers.find(rx_msg.msgid);
                    if (it != consumers.end())
                    {
                        it->second->consume_message(rx_msg);
                    }
                }
            }
        }
    }
}

void MavlinkWrapper::write_loop()
{
    while (true)
    {
        unique_lock<mutex> lock(send_message_mtx);
        write_cv.wait(lock, [this]
                  { return !send_msg_list.empty() || should_exit; });
        
        if (should_exit) break;

        lock.unlock();
        {
            unique_ptr<mavlink_message_t> msg;
            {
                lock_guard<mutex> lock(send_message_mtx);
                if (!send_msg_list.empty())
                {
                    msg = move(send_msg_list.front());
                    send_msg_list.pop_front();
                }
            }

            if (msg)
            {
                uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
                uint16_t len = mavlink_msg_to_send_buffer(buffer, msg.get());
                port->write_data(buffer, len);
            }
        }
    }
}
