#ifndef _CHARGE_PILE_HPP_
#define _CHARGE_PILE_HPP_

#include <cstdint>

namespace charge_pile
{
    struct charge_pile_status_t
    {
        uint32_t als;          /*<  环境光传感器，数值越低越黑暗 */
        uint8_t led;          /*<  补光灯状态，0：关闭，1：打开 */
        uint8_t charge_pin;   /*<  充电引脚状态，0：未连接，1：已连接 */
        uint32_t cmin_adc;     /*<  负极极片ADC值，0 - 1000, 接入成功 */
        uint32_t cplus_adc;    /*<  正极极片ADC值，1500 - 3000 , 接入成功 */
        uint8_t cmin_status;  /*<  负极极片接触状态，0：未接触，1：已接触 */
        uint8_t cplus_status; /*<  正极极片接触状态，0：未接触，1：已接触 */
        uint16_t tag_id;         /*<  二维码tag id*/        
        uint8_t reserver[8]; /*<  预留*/
    };

    enum dog_status
    {
        DOG_RETURNING = 0,     /*< 狗返航中，桩子开始自动判断补光灯开启和关闭 */
        DOG_LYING_DOWN = 1,    /*< 狗趴下，桩子判断极片连接状态，如果极片连接成功，则自动进入充电。如果没有接触成功，狗将状态置为其他则极片不带电 */
        DOG_STATUS_UNKNOWN = 2 /*< 狗状态未知 */
    };

    class ChargePile
    {
    private:
        ChargePile();
        ~ChargePile();
        ChargePile(const ChargePile &) = delete;
        ChargePile &operator=(const ChargePile &) = delete;

    public:
        static ChargePile &getInstance();

        /**
         * @description: 获取充电桩连接状态
         * @return {*}
         */
        bool isConnected(void) const;

        /**
         * @description: 获取充电桩状态
         * @param {charge_pile_status_t} &status
         * @return {bool，true表示数据有效，false表示数据无效}
         */
        bool getPileStatus(charge_pile_status_t &charge_pile_status);

        void sendDogStatus(dog_status status);
    };

} // namespace charge_pile

#endif // !_CHARGE_PILE_HPP_
