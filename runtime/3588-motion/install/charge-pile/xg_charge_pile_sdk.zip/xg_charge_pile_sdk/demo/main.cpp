#include <iostream>
#include <stdexcept>
#include <string>
#include <cstring>
#include <thread>
#include <chrono>
#include "charge_pile.hpp"

using namespace std;
using namespace charge_pile;



int main(int argc, const char **argv)
{
    ChargePile &charge_pile = ChargePile::getInstance();
    charge_pile_status_t status;
    sample_adc_def sample_adc;
    while (1)
    {

        if (charge_pile.getPileStatus(status))
        {
            cout << endl
                 << "--------------------------------------------------------------------------------" << endl;
            sample_adc.det_c[1].det_c_send = status.cmin_adc;
            sample_adc.det_c[0].det_c_send = status.cplus_adc;            

            printf("als=%d,led=%d,charge pin=%d,c-adc=%f,c+adc=%f,c-status=%d,c+status=%d,tagid=%d\n",
                   status.als, status.led, status.charge_pin, sample_adc.det_c[1].st.f_det_c, sample_adc.det_c[0].st.f_det_c, status.cmin_status, status.cplus_status, status.tag_id);

            cout << "--------------------------------------------------------------------------------" << endl
                 << endl;
        }

        cout << endl
             << "--------------------------------------------------------------------------------" << endl;
        cout << "connected=" << (charge_pile.isConnected() ? "yes" : "no") << endl;
        cout << "--------------------------------------------------------------------------------" << endl
             << endl;

        cout << "Sending DOG_LYING_DOWN status..." << endl;
        charge_pile.sendDogStatus(DOG_LYING_DOWN);
        if (cin.rdbuf()->in_avail() > 0)
        {
            char ch;
            cin.get(ch);
            if (ch == 'r' || ch == 'R')
            {
                cout << "Sending DOG_RETURNING status..." << endl;
                charge_pile.sendDogStatus(DOG_RETURNING);
            }
            else if (ch == 'l' || ch == 'L')
            {
                cout << "Sending DOG_LYING_DOWN status..." << endl;
                charge_pile.sendDogStatus(DOG_LYING_DOWN);
            }
            else if (ch == 'u' || ch == 'U')
            {
                cout << "Sending DOG_STATUS_UNKNOWN status..." << endl;
                charge_pile.sendDogStatus(DOG_STATUS_UNKNOWN);
            }
        }

        this_thread::sleep_for(chrono::seconds(1));
    }

    return 0;
}
