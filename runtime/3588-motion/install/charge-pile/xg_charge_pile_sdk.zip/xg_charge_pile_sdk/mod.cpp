#include <unistd.h>
#include <termios.h>
#include <chrono>
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <array>
#include <poll.h>
#include <signal.h>
#include <iomanip>
#include <cstdio>
#include <sys/stat.h>
#include <sys/types.h>
#include <thread>
#include <fstream>
#include "serial.hpp"
#include "charge_pile.hpp"
#include "mavlink_wrapp.hpp"
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;

static MavlinkWrapper *mavlink_wrapper = &MavlinkWrapper::instance();

constexpr int kGpioPin = 63;
constexpr const char *kDefaultSerialPath = "/dev/ttyUSB0";

class SysfsWriter
{
public:
    static void write_value(const string &path, const string &value)
    {
        std::cerr << "Writing to " << path << ": " << value << std::endl;
        int fd = open(path.c_str(), O_WRONLY);
        if (fd < 0)
        {
            throw runtime_error("Failed to open " + path + ": " + strerror(errno));
        }
        string payload = value;
        if (payload.empty() || payload.back() != '\n')
        {
            payload.push_back('\n');
        }
        ssize_t written = ::write(fd, payload.c_str(), payload.size());
        int saved_errno = errno;
        close(fd);
        if (written < 0)
        {
            throw runtime_error("Failed to write to " + path + ": " + strerror(saved_errno));
        }
    }
};

class GpioPin
{
public:
    explicit GpioPin(int pin) : pin_(pin)
    {
        export_if_needed();
    }

    ~GpioPin()
    {
        try
        {
            if (restore_on_exit_)
            {
                // set_value(restore_value_);
            }
        }
        catch (...)
        {
            // best effort, avoid throwing from destructor
        }
    }

    void set_direction(const string &direction)
    {
        const string path = gpio_base_path() + "/direction";
        SysfsWriter::write_value(path, direction);
    }

    void set_value(int value)
    {
        const string path = gpio_base_path() + "/value";
        SysfsWriter::write_value(path, to_string(value));
    }

    void set_restore_value(int value)
    {
        restore_value_ = value;
    }

    void disable_restore()
    {
        restore_on_exit_ = false;
    }

private:
    void export_if_needed()
    {
        const string base = gpio_base_path();
        if (access(base.c_str(), F_OK) == 0)
        {
            return;
        }

        const string export_path = "/sys/class/gpio/export";
        int fd = open(export_path.c_str(), O_WRONLY);
        if (fd < 0)
        {
            throw runtime_error("Failed to open " + export_path + ": " + strerror(errno));
        }
        string payload = to_string(pin_) + '\n';
        ssize_t written = ::write(fd, payload.c_str(), payload.size());
        int saved_errno = errno;
        close(fd);
        if (written < 0 && saved_errno != EBUSY)
        {
            throw runtime_error("Failed to write to " + export_path + ": " + strerror(saved_errno));
        }

        constexpr int retry_count = 50;
        constexpr auto retry_interval = chrono::milliseconds(10);
        for (int i = 0; i < retry_count; ++i)
        {
            if (access(base.c_str(), F_OK) == 0)
            {
                return;
            }
            this_thread::sleep_for(retry_interval);
        }
        throw runtime_error("GPIO" + to_string(pin_) + " did not appear under sysfs");
    }

    string gpio_base_path() const
    {
        return "/sys/class/gpio/gpio" + to_string(pin_);
    }

    int pin_;
    int restore_value_ = 1;
    bool restore_on_exit_ = true;
};

speed_t to_termios_baud(int baudrate)
{
    switch (baudrate)
    {
    case 9600:
        return B9600;
    case 19200:
        return B19200;
    case 38400:
        return B38400;
    case 57600:
        return B57600;
    case 115200:
        return B115200;
    case 230400:
        return B230400;
    case 460800:
        return B460800;
    default:
        throw runtime_error("Unsupported baudrate: " + to_string(baudrate));
    }
}

struct Command
{
    vector<uint8_t> payload;
    string description;
};

Command make_ascii_command(const string &cmd)
{
    Command command;
    command.description = cmd;
    command.payload.assign(cmd.begin(), cmd.end());
    return command;
}

Command make_bond_command(const string &mac)
{
    constexpr char prefix[] = "AT+PEERMAC=";
    Command command;
    command.description = string(prefix) + mac;
    command.payload.insert(command.payload.end(), prefix, prefix + strlen(prefix));
    // array<uint8_t, 6> mac_bytes = {0xF8, 0x9D, 0x9D, 0x01, 0xB1, 0xE3};
    array<uint8_t, 6> mac_bytes = {0xE3, 0xB1, 0x01, 0x9D, 0x9D, 0xF8};
    command.payload.insert(command.payload.end(), mac_bytes.begin(), mac_bytes.end());
    return command;
}

void send_commands(port &serial_port, const vector<Command> &commands)
{
    for (const auto &cmd : commands)
    {
        int ret = serial_port.write_data(cmd.payload.data(), cmd.payload.size());
        if (ret < 0)
        {
            throw runtime_error("Failed to send command: " + cmd.description);
        }
        cout << "Sent: " << cmd.description << endl;
        this_thread::sleep_for(chrono::milliseconds(300));
    }
}

int send_command_with_ok_response(serial &serial_port, const Command &command, chrono::milliseconds timeout = chrono::seconds(2))
{
    int ret = serial_port.write_data(command.payload.data(), command.payload.size());
    if (ret < 0)
    {
        throw runtime_error("Failed to send command: " + command.description);
    }
    cout << "Sent: " << command.description << endl;

    vector<uint8_t> response;
    auto deadline = chrono::steady_clock::now() + timeout;

    while (chrono::steady_clock::now() < deadline)
    {
        auto now = chrono::steady_clock::now();
        if (now >= deadline)
        {
            break;
        }

        auto remaining = chrono::duration_cast<chrono::milliseconds>(deadline - now);
        pollfd pfd{};
        pfd.fd = serial_port.descriptor();
        pfd.events = POLLIN;

        int poll_ret = poll(&pfd, 1, static_cast<int>(remaining.count()));
        if (poll_ret < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            throw runtime_error(string("Poll failed: ") + strerror(errno));
        }
        if (poll_ret == 0)
        {
            break;
        }

        if (pfd.revents & POLLIN)
        {
            uint8_t buf[64];
            int read_bytes = serial_port.read_data(buf, sizeof(buf));
            if (read_bytes > 0)
            {
                response.insert(response.end(), buf, buf + read_bytes);
                string resp_str(response.begin(), response.end());
                auto pos = resp_str.find("OK=");
                if (pos != string::npos && pos + 3 < resp_str.size())
                {
                    char value = resp_str[pos + 3];
                    if (value == '0' || value == '1')
                    {
                        cout << "Received: " << resp_str << endl;
                        return value - '0';
                    }
                }
            }
        }
    }

    throw runtime_error("Timeout waiting for OK response to command: " + command.description);
}

string send_command_with_str_ok_response(serial &serial_port, const Command &command, chrono::milliseconds timeout = chrono::seconds(2))
{
    int ret = serial_port.write_data(command.payload.data(), command.payload.size());
    if (ret < 0)
    {
        throw runtime_error("Failed to send command: " + command.description);
    }
    cout << "Sent: " << command.description << endl;

    vector<uint8_t> response;
    auto deadline = chrono::steady_clock::now() + timeout;

    while (chrono::steady_clock::now() < deadline)
    {
        auto now = chrono::steady_clock::now();
        if (now >= deadline)
        {
            break;
        }

        auto remaining = chrono::duration_cast<chrono::milliseconds>(deadline - now);
        pollfd pfd{};
        pfd.fd = serial_port.descriptor();
        pfd.events = POLLIN;

        int poll_ret = poll(&pfd, 1, static_cast<int>(remaining.count()));
        if (poll_ret < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }
            throw runtime_error(string("Poll failed: ") + strerror(errno));
        }
        if (poll_ret == 0)
        {
            break;
        }

        if (pfd.revents & POLLIN)
        {
            uint8_t buf[64];
            int read_bytes = serial_port.read_data(buf, sizeof(buf));
            if (read_bytes > 0)
            {
                response.insert(response.end(), buf, buf + read_bytes);
                string resp_str(response.begin(), response.end());
                auto pos = resp_str.find("OK=");
                if (pos != string::npos && pos + 3 < resp_str.size())
                {
                    string value;
                    size_t end_pos = resp_str.find_first_of("\r\n", pos);
                    if (end_pos == string::npos)
                    {
                        value = resp_str.substr(pos + 3);
                    }
                    else
                    {
                        value = resp_str.substr(pos + 3, end_pos - (pos + 3));
                    }
                    cout << "Received: " << resp_str << endl;
                    return value;
                }
            }
        }
    }

    throw runtime_error("Timeout waiting for OK response to command: " + command.description);
}

serial *serial_port;

using namespace charge_pile;

static mutex charge_pile_status_mtx;
static struct charge_pile_status_t charge_pile_status;
static bool charge_pile_status_valid = false;

class charge_pile_status_mavlink_consumer : public MavlinkMsgConsumer
{
public:
    charge_pile_status_mavlink_consumer() : MavlinkMsgConsumer(MAVLINK_MSG_ID_CHARGE_PILE_STATUS) {}
    ~charge_pile_status_mavlink_consumer() {}
    void consume_message(const mavlink_message_t &msg) override
    {
        std::lock_guard<std::mutex> lock(charge_pile_status_mtx);
        mavlink_charge_pile_status_t mav_charge_pile_status;
        mavlink_msg_charge_pile_status_decode(&msg, &mav_charge_pile_status);
        charge_pile_status.als = mav_charge_pile_status.als;
        charge_pile_status.led = mav_charge_pile_status.led;
        charge_pile_status.charge_pin = mav_charge_pile_status.charge_pin;
        charge_pile_status.cmin_adc = mav_charge_pile_status.cmin_adc;
        charge_pile_status.cplus_adc = mav_charge_pile_status.cplus_adc;
        charge_pile_status.cmin_status = mav_charge_pile_status.cmin_status;
        charge_pile_status.cplus_status = mav_charge_pile_status.cplus_status;
        charge_pile_status.tag_id = mav_charge_pile_status.tag_id;
        charge_pile_status_valid = true;
    }
};

static uint64_t last_heartbeat_last;

class charge_pile_heartbeat_mavlink_consumer : public MavlinkMsgConsumer
{
public:
    charge_pile_heartbeat_mavlink_consumer() : MavlinkMsgConsumer(MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE) {}
    ~charge_pile_heartbeat_mavlink_consumer() {}
    void consume_message(const mavlink_message_t &msg) override
    {
        mavlink_heartbeat_charge_pile_t heartbeat;
        mavlink_msg_heartbeat_charge_pile_decode(&msg, &heartbeat);
        // 记录last heartbeat时间戳或其他处理逻辑
        auto now = chrono::steady_clock::now();
        last_heartbeat_last = chrono::duration_cast<chrono::nanoseconds>(now.time_since_epoch()).count();
    }
};

static string get_dog_name(void)
{
    ifstream ifs("/userdata/bak/system/hostapd.conf");
    string line;
    while (getline(ifs, line))
    {
        if (line.find("ssid=") != string::npos)
        {
            return line.substr(line.find("=") + 1);
        }
    }
    return "";
}

void stop_arc_platform(void) 
{
    pid_t pid = fork();
    
    if (pid == 0) 
    {
        execlp("sudo", "sudo", "robot-launch", "stop", "arc_platform", NULL);

        std::cerr << "执行命令失败" << std::endl;
        exit(1);
    } 
    else if (pid > 0) 
    {
        int status;
        waitpid(pid, &status, 0);
        
        if (WIFEXITED(status)) 
        {
            std::cout << "命令执行完成，退出码: " << WEXITSTATUS(status) << std::endl;
        }
    } 
    else 
    {
        std::cerr << "创建子进程失败" << std::endl;
    }
}

ChargePile::ChargePile(void)
{
    stop_arc_platform(); /*stop平台软件进程*/

    GpioPin gpio(kGpioPin);
    gpio.set_restore_value(1);
    gpio.set_direction("out");
    this_thread::sleep_for(chrono::milliseconds(200));

    serial_port = new serial(kDefaultSerialPath, to_termios_baud(115200));
    serial_port->flush_data();

    vector<Command> commands;

    gpio.set_value(0);
    this_thread::sleep_for(chrono::milliseconds(200));

    Command role_query = make_ascii_command("AT+ROLE?");
    int role_value = send_command_with_ok_response(*serial_port, role_query);
    cout << "AT+ROLE? returned OK=" << role_value << endl;
    if (role_value != 0)
    {
        commands.push_back(make_ascii_command("AT+ROLE=0"));
    }

    Command name_query = make_ascii_command("AT+NAME?");
    string name_value = send_command_with_str_ok_response(*serial_port, name_query);
    cout << "AT+NAME? returned OK=" << name_value << endl;
    // string desired_name = get_dog_name();
    // if (desired_name.empty())
    // {
    //     desired_name = "TEST_DOG";
    // }
    // if (name_value != desired_name)
    // {
    //     commands.push_back(make_ascii_command("AT+NAME=" + desired_name));
    // }
    
    Command mac_query = make_ascii_command("AT+MAC?");
    string mac_value = send_command_with_str_ok_response(*serial_port, mac_query);
    cout << "AT+MAC? returned OK=" << mac_value << endl;

    send_commands(*serial_port, commands);
    gpio.set_value(1);
    this_thread::sleep_for(chrono::milliseconds(200));

    mavlink_wrapper->setup(serial_port);
    static charge_pile_status_mavlink_consumer consumer;
    (void)consumer;

    static charge_pile_heartbeat_mavlink_consumer heartbeat_consumer;
    (void)heartbeat_consumer;
}

bool ChargePile::isConnected(void) const
{
    auto now = chrono::steady_clock::now();
    uint64_t now_ns = chrono::duration_cast<chrono::nanoseconds>(now.time_since_epoch()).count();
    constexpr uint64_t timeout_ns = 10ULL * 1000000000;
    return (now_ns - last_heartbeat_last) < timeout_ns;
}

ChargePile::~ChargePile()
{
    delete mavlink_wrapper;
    delete serial_port;
}

ChargePile &ChargePile::getInstance()
{
    static ChargePile instance;
    return instance;
}

bool ChargePile::getPileStatus(charge_pile_status_t &status)
{
    std::lock_guard<std::mutex> lock(charge_pile_status_mtx);
    if (charge_pile_status_valid)
    {
        status = charge_pile_status;
        charge_pile_status_valid = false;
        return true;
    }
    return false;
}

void ChargePile::sendDogStatus(dog_status status)
{
    mavlink_message_t msg;
    mavlink_msg_charge_dog_status_pack(0, 0, &msg, static_cast<uint32_t>(status), 0);
    mavlink_wrapper->send_message(msg);
}
