#ifndef _SERIAL_H_
#define _SERIAL_H_

#include <termios.h>
#include <string>
#include "port.hpp"

class serial : public port
{
private:
    int fd;

public:
    serial(const std::string &port, const int baudrate = B460800);
    ~serial();
    int write_data(const uint8_t *data, const size_t size) override;
    int read_data(uint8_t *data, const size_t size) override;
    int flush_data(void) override;
    int set_baudrate(int baudrate);
    int descriptor() const { return fd; }
};

#endif // !_SERIAL_H_
