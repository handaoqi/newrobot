#ifndef _MAVLINK_WRAPP_HPP_
#define _MAVLINK_WRAPP_HPP_

#include "mavlink.h"
#include <mutex>
#include <thread>
#include <string>
#include <map>
#include <list>
#include <memory>
#include <condition_variable>

class serial;

class MavlinkMsgConsumer;

class MavlinkWrapper
{
public:
    static MavlinkWrapper &instance()
    {
        static MavlinkWrapper instance;
        return instance;
    }

    // Delete copy and move constructors and assignment operators
    MavlinkWrapper(const MavlinkWrapper &) = delete;
    MavlinkWrapper &operator=(const MavlinkWrapper &) = delete;
    MavlinkWrapper(MavlinkWrapper &&) = delete;
    MavlinkWrapper &operator=(MavlinkWrapper &&) = delete;

    void send_message(const mavlink_message_t &msg);
    void register_consumer(int msg_id, MavlinkMsgConsumer *consumer);
    void unregister_consumer(int msg_id)
    {
        std::lock_guard<std::mutex> lock(consumer_mtx);
        consumers.erase(msg_id);
    }

    void setup(serial *_port);
    ~MavlinkWrapper();

private:
    const int MAVLINK_COMM_0 = 0;

    MavlinkWrapper();

    bool should_exit = false;

    mavlink_status_t rx_status;
    mavlink_message_t rx_msg;
    serial *port;
    uint8_t read_buf[1024];

    std::thread read_thread;
    std::thread write_thread;

    std::mutex consumer_mtx;
    std::map<int, MavlinkMsgConsumer *> consumers;

    std::mutex send_message_mtx;
    std::list<std::unique_ptr<mavlink_message_t>> send_msg_list;
    std::condition_variable write_cv;

    void read_loop();
    void write_loop();
};

class MavlinkMsgConsumer
{
private:
    int msg_id;

public:
    virtual void consume_message(const mavlink_message_t &msg) = 0;
    MavlinkMsgConsumer(int id) : msg_id(id)
    {
        MavlinkWrapper::instance().register_consumer(msg_id, this);
    }
    ~MavlinkMsgConsumer()
    {
        MavlinkWrapper::instance().unregister_consumer(msg_id);
    }
};

#endif // !_MAVLINK_WRAPP_HPP_
