#ifndef _PORT_HPP_
#define _PORT_HPP_

#include <stdint.h>
#include <stddef.h>

class port
{
public:
    port() {}
    ~port() {}
    virtual int write_data(const uint8_t *data, const size_t size) = 0;
    virtual int read_data(uint8_t *data, const size_t size) = 0;
    virtual int flush_data(void) = 0;
};

#endif // !_PORT_HPP_
