#pragma once
// MESSAGE UPGRADE_FIRMWARE_START PACKING

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START 7


typedef struct __mavlink_upgrade_firmware_start_t {
 uint32_t base_addr; /*<  固件起始地址*/
 uint32_t firmware_size; /*<  固件大小*/
 uint32_t reserver; /*<  保留字*/
} mavlink_upgrade_firmware_start_t;

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN 12
#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN 12
#define MAVLINK_MSG_ID_7_LEN 12
#define MAVLINK_MSG_ID_7_MIN_LEN 12

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC 50
#define MAVLINK_MSG_ID_7_CRC 50



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_START { \
    7, \
    "UPGRADE_FIRMWARE_START", \
    3, \
    {  { "base_addr", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_start_t, base_addr) }, \
         { "firmware_size", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_upgrade_firmware_start_t, firmware_size) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_upgrade_firmware_start_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_START { \
    "UPGRADE_FIRMWARE_START", \
    3, \
    {  { "base_addr", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_start_t, base_addr) }, \
         { "firmware_size", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_upgrade_firmware_start_t, firmware_size) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_upgrade_firmware_start_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a upgrade_firmware_start message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param base_addr  固件起始地址
 * @param firmware_size  固件大小
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t base_addr, uint32_t firmware_size, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN];
    _mav_put_uint32_t(buf, 0, base_addr);
    _mav_put_uint32_t(buf, 4, firmware_size);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#else
    mavlink_upgrade_firmware_start_t packet;
    packet.base_addr = base_addr;
    packet.firmware_size = firmware_size;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
}

/**
 * @brief Pack a upgrade_firmware_start message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param base_addr  固件起始地址
 * @param firmware_size  固件大小
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t base_addr, uint32_t firmware_size, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN];
    _mav_put_uint32_t(buf, 0, base_addr);
    _mav_put_uint32_t(buf, 4, firmware_size);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#else
    mavlink_upgrade_firmware_start_t packet;
    packet.base_addr = base_addr;
    packet.firmware_size = firmware_size;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#endif
}

/**
 * @brief Pack a upgrade_firmware_start message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param base_addr  固件起始地址
 * @param firmware_size  固件大小
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t base_addr,uint32_t firmware_size,uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN];
    _mav_put_uint32_t(buf, 0, base_addr);
    _mav_put_uint32_t(buf, 4, firmware_size);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#else
    mavlink_upgrade_firmware_start_t packet;
    packet.base_addr = base_addr;
    packet.firmware_size = firmware_size;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
}

/**
 * @brief Encode a upgrade_firmware_start struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_upgrade_firmware_start_t* upgrade_firmware_start)
{
    return mavlink_msg_upgrade_firmware_start_pack(system_id, component_id, msg, upgrade_firmware_start->base_addr, upgrade_firmware_start->firmware_size, upgrade_firmware_start->reserver);
}

/**
 * @brief Encode a upgrade_firmware_start struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_upgrade_firmware_start_t* upgrade_firmware_start)
{
    return mavlink_msg_upgrade_firmware_start_pack_chan(system_id, component_id, chan, msg, upgrade_firmware_start->base_addr, upgrade_firmware_start->firmware_size, upgrade_firmware_start->reserver);
}

/**
 * @brief Encode a upgrade_firmware_start struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_start_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_upgrade_firmware_start_t* upgrade_firmware_start)
{
    return mavlink_msg_upgrade_firmware_start_pack_status(system_id, component_id, _status, msg,  upgrade_firmware_start->base_addr, upgrade_firmware_start->firmware_size, upgrade_firmware_start->reserver);
}

/**
 * @brief Send a upgrade_firmware_start message
 * @param chan MAVLink channel to send the message
 *
 * @param base_addr  固件起始地址
 * @param firmware_size  固件大小
 * @param reserver  保留字
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_upgrade_firmware_start_send(mavlink_channel_t chan, uint32_t base_addr, uint32_t firmware_size, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN];
    _mav_put_uint32_t(buf, 0, base_addr);
    _mav_put_uint32_t(buf, 4, firmware_size);
    _mav_put_uint32_t(buf, 8, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#else
    mavlink_upgrade_firmware_start_t packet;
    packet.base_addr = base_addr;
    packet.firmware_size = firmware_size;
    packet.reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START, (const char *)&packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#endif
}

/**
 * @brief Send a upgrade_firmware_start message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_upgrade_firmware_start_send_struct(mavlink_channel_t chan, const mavlink_upgrade_firmware_start_t* upgrade_firmware_start)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_upgrade_firmware_start_send(chan, upgrade_firmware_start->base_addr, upgrade_firmware_start->firmware_size, upgrade_firmware_start->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START, (const char *)upgrade_firmware_start, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#endif
}

#if MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_upgrade_firmware_start_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t base_addr, uint32_t firmware_size, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, base_addr);
    _mav_put_uint32_t(buf, 4, firmware_size);
    _mav_put_uint32_t(buf, 8, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#else
    mavlink_upgrade_firmware_start_t *packet = (mavlink_upgrade_firmware_start_t *)msgbuf;
    packet->base_addr = base_addr;
    packet->firmware_size = firmware_size;
    packet->reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START, (const char *)packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_CRC);
#endif
}
#endif

#endif

// MESSAGE UPGRADE_FIRMWARE_START UNPACKING


/**
 * @brief Get field base_addr from upgrade_firmware_start message
 *
 * @return  固件起始地址
 */
static inline uint32_t mavlink_msg_upgrade_firmware_start_get_base_addr(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field firmware_size from upgrade_firmware_start message
 *
 * @return  固件大小
 */
static inline uint32_t mavlink_msg_upgrade_firmware_start_get_firmware_size(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field reserver from upgrade_firmware_start message
 *
 * @return  保留字
 */
static inline uint32_t mavlink_msg_upgrade_firmware_start_get_reserver(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Decode a upgrade_firmware_start message into a struct
 *
 * @param msg The message to decode
 * @param upgrade_firmware_start C-struct to decode the message contents into
 */
static inline void mavlink_msg_upgrade_firmware_start_decode(const mavlink_message_t* msg, mavlink_upgrade_firmware_start_t* upgrade_firmware_start)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    upgrade_firmware_start->base_addr = mavlink_msg_upgrade_firmware_start_get_base_addr(msg);
    upgrade_firmware_start->firmware_size = mavlink_msg_upgrade_firmware_start_get_firmware_size(msg);
    upgrade_firmware_start->reserver = mavlink_msg_upgrade_firmware_start_get_reserver(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN? msg->len : MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN;
        memset(upgrade_firmware_start, 0, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_START_LEN);
    memcpy(upgrade_firmware_start, _MAV_PAYLOAD(msg), len);
#endif
}
