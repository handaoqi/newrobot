#pragma once
// MESSAGE HEARTBEAT_CHARGE_PILE PACKING

#define MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE 130


typedef struct __mavlink_heartbeat_charge_pile_t {
 uint32_t count; /*<  心跳计数*/
} mavlink_heartbeat_charge_pile_t;

#define MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN 4
#define MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN 4
#define MAVLINK_MSG_ID_130_LEN 4
#define MAVLINK_MSG_ID_130_MIN_LEN 4

#define MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC 47
#define MAVLINK_MSG_ID_130_CRC 47



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_HEARTBEAT_CHARGE_PILE { \
    130, \
    "HEARTBEAT_CHARGE_PILE", \
    1, \
    {  { "count", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_heartbeat_charge_pile_t, count) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_HEARTBEAT_CHARGE_PILE { \
    "HEARTBEAT_CHARGE_PILE", \
    1, \
    {  { "count", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_heartbeat_charge_pile_t, count) }, \
         } \
}
#endif

/**
 * @brief Pack a heartbeat_charge_pile message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param count  心跳计数
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN];
    _mav_put_uint32_t(buf, 0, count);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#else
    mavlink_heartbeat_charge_pile_t packet;
    packet.count = count;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
}

/**
 * @brief Pack a heartbeat_charge_pile message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param count  心跳计数
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN];
    _mav_put_uint32_t(buf, 0, count);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#else
    mavlink_heartbeat_charge_pile_t packet;
    packet.count = count;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#endif
}

/**
 * @brief Pack a heartbeat_charge_pile message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param count  心跳计数
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN];
    _mav_put_uint32_t(buf, 0, count);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#else
    mavlink_heartbeat_charge_pile_t packet;
    packet.count = count;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
}

/**
 * @brief Encode a heartbeat_charge_pile struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param heartbeat_charge_pile C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_heartbeat_charge_pile_t* heartbeat_charge_pile)
{
    return mavlink_msg_heartbeat_charge_pile_pack(system_id, component_id, msg, heartbeat_charge_pile->count);
}

/**
 * @brief Encode a heartbeat_charge_pile struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param heartbeat_charge_pile C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_heartbeat_charge_pile_t* heartbeat_charge_pile)
{
    return mavlink_msg_heartbeat_charge_pile_pack_chan(system_id, component_id, chan, msg, heartbeat_charge_pile->count);
}

/**
 * @brief Encode a heartbeat_charge_pile struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param heartbeat_charge_pile C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_heartbeat_charge_pile_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_heartbeat_charge_pile_t* heartbeat_charge_pile)
{
    return mavlink_msg_heartbeat_charge_pile_pack_status(system_id, component_id, _status, msg,  heartbeat_charge_pile->count);
}

/**
 * @brief Send a heartbeat_charge_pile message
 * @param chan MAVLink channel to send the message
 *
 * @param count  心跳计数
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_heartbeat_charge_pile_send(mavlink_channel_t chan, uint32_t count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN];
    _mav_put_uint32_t(buf, 0, count);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE, buf, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#else
    mavlink_heartbeat_charge_pile_t packet;
    packet.count = count;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE, (const char *)&packet, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#endif
}

/**
 * @brief Send a heartbeat_charge_pile message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_heartbeat_charge_pile_send_struct(mavlink_channel_t chan, const mavlink_heartbeat_charge_pile_t* heartbeat_charge_pile)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_heartbeat_charge_pile_send(chan, heartbeat_charge_pile->count);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE, (const char *)heartbeat_charge_pile, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#endif
}

#if MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_heartbeat_charge_pile_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, count);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE, buf, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#else
    mavlink_heartbeat_charge_pile_t *packet = (mavlink_heartbeat_charge_pile_t *)msgbuf;
    packet->count = count;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE, (const char *)packet, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_MIN_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_CRC);
#endif
}
#endif

#endif

// MESSAGE HEARTBEAT_CHARGE_PILE UNPACKING


/**
 * @brief Get field count from heartbeat_charge_pile message
 *
 * @return  心跳计数
 */
static inline uint32_t mavlink_msg_heartbeat_charge_pile_get_count(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a heartbeat_charge_pile message into a struct
 *
 * @param msg The message to decode
 * @param heartbeat_charge_pile C-struct to decode the message contents into
 */
static inline void mavlink_msg_heartbeat_charge_pile_decode(const mavlink_message_t* msg, mavlink_heartbeat_charge_pile_t* heartbeat_charge_pile)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    heartbeat_charge_pile->count = mavlink_msg_heartbeat_charge_pile_get_count(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN? msg->len : MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN;
        memset(heartbeat_charge_pile, 0, MAVLINK_MSG_ID_HEARTBEAT_CHARGE_PILE_LEN);
    memcpy(heartbeat_charge_pile, _MAV_PAYLOAD(msg), len);
#endif
}
