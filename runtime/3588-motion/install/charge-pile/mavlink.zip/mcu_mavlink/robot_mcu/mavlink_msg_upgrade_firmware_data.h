#pragma once
// MESSAGE UPGRADE_FIRMWARE_DATA PACKING

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA 9


typedef struct __mavlink_upgrade_firmware_data_t {
 uint32_t len; /*<  数据长度*/
 uint8_t data[200]; /*<  固件数据*/
} mavlink_upgrade_firmware_data_t;

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN 204
#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN 204
#define MAVLINK_MSG_ID_9_LEN 204
#define MAVLINK_MSG_ID_9_MIN_LEN 204

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC 205
#define MAVLINK_MSG_ID_9_CRC 205

#define MAVLINK_MSG_UPGRADE_FIRMWARE_DATA_FIELD_DATA_LEN 200

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_DATA { \
    9, \
    "UPGRADE_FIRMWARE_DATA", \
    2, \
    {  { "len", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_data_t, len) }, \
         { "data", NULL, MAVLINK_TYPE_UINT8_T, 200, 4, offsetof(mavlink_upgrade_firmware_data_t, data) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_DATA { \
    "UPGRADE_FIRMWARE_DATA", \
    2, \
    {  { "len", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_data_t, len) }, \
         { "data", NULL, MAVLINK_TYPE_UINT8_T, 200, 4, offsetof(mavlink_upgrade_firmware_data_t, data) }, \
         } \
}
#endif

/**
 * @brief Pack a upgrade_firmware_data message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param len  数据长度
 * @param data  固件数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t len, const uint8_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, len);
    _mav_put_uint8_t_array(buf, 4, data, 200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#else
    mavlink_upgrade_firmware_data_t packet;
    packet.len = len;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
}

/**
 * @brief Pack a upgrade_firmware_data message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param len  数据长度
 * @param data  固件数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t len, const uint8_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, len);
    _mav_put_uint8_t_array(buf, 4, data, 200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#else
    mavlink_upgrade_firmware_data_t packet;
    packet.len = len;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#endif
}

/**
 * @brief Pack a upgrade_firmware_data message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param len  数据长度
 * @param data  固件数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t len,const uint8_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, len);
    _mav_put_uint8_t_array(buf, 4, data, 200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#else
    mavlink_upgrade_firmware_data_t packet;
    packet.len = len;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
}

/**
 * @brief Encode a upgrade_firmware_data struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_upgrade_firmware_data_t* upgrade_firmware_data)
{
    return mavlink_msg_upgrade_firmware_data_pack(system_id, component_id, msg, upgrade_firmware_data->len, upgrade_firmware_data->data);
}

/**
 * @brief Encode a upgrade_firmware_data struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_upgrade_firmware_data_t* upgrade_firmware_data)
{
    return mavlink_msg_upgrade_firmware_data_pack_chan(system_id, component_id, chan, msg, upgrade_firmware_data->len, upgrade_firmware_data->data);
}

/**
 * @brief Encode a upgrade_firmware_data struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_upgrade_firmware_data_t* upgrade_firmware_data)
{
    return mavlink_msg_upgrade_firmware_data_pack_status(system_id, component_id, _status, msg,  upgrade_firmware_data->len, upgrade_firmware_data->data);
}

/**
 * @brief Send a upgrade_firmware_data message
 * @param chan MAVLink channel to send the message
 *
 * @param len  数据长度
 * @param data  固件数据
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_upgrade_firmware_data_send(mavlink_channel_t chan, uint32_t len, const uint8_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, len);
    _mav_put_uint8_t_array(buf, 4, data, 200);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#else
    mavlink_upgrade_firmware_data_t packet;
    packet.len = len;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*200);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA, (const char *)&packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#endif
}

/**
 * @brief Send a upgrade_firmware_data message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_upgrade_firmware_data_send_struct(mavlink_channel_t chan, const mavlink_upgrade_firmware_data_t* upgrade_firmware_data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_upgrade_firmware_data_send(chan, upgrade_firmware_data->len, upgrade_firmware_data->data);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA, (const char *)upgrade_firmware_data, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#endif
}

#if MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_upgrade_firmware_data_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t len, const uint8_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, len);
    _mav_put_uint8_t_array(buf, 4, data, 200);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#else
    mavlink_upgrade_firmware_data_t *packet = (mavlink_upgrade_firmware_data_t *)msgbuf;
    packet->len = len;
    mav_array_memcpy(packet->data, data, sizeof(uint8_t)*200);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA, (const char *)packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_CRC);
#endif
}
#endif

#endif

// MESSAGE UPGRADE_FIRMWARE_DATA UNPACKING


/**
 * @brief Get field len from upgrade_firmware_data message
 *
 * @return  数据长度
 */
static inline uint32_t mavlink_msg_upgrade_firmware_data_get_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field data from upgrade_firmware_data message
 *
 * @return  固件数据
 */
static inline uint16_t mavlink_msg_upgrade_firmware_data_get_data(const mavlink_message_t* msg, uint8_t *data)
{
    return _MAV_RETURN_uint8_t_array(msg, data, 200,  4);
}

/**
 * @brief Decode a upgrade_firmware_data message into a struct
 *
 * @param msg The message to decode
 * @param upgrade_firmware_data C-struct to decode the message contents into
 */
static inline void mavlink_msg_upgrade_firmware_data_decode(const mavlink_message_t* msg, mavlink_upgrade_firmware_data_t* upgrade_firmware_data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    upgrade_firmware_data->len = mavlink_msg_upgrade_firmware_data_get_len(msg);
    mavlink_msg_upgrade_firmware_data_get_data(msg, upgrade_firmware_data->data);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN? msg->len : MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN;
        memset(upgrade_firmware_data, 0, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_DATA_LEN);
    memcpy(upgrade_firmware_data, _MAV_PAYLOAD(msg), len);
#endif
}
