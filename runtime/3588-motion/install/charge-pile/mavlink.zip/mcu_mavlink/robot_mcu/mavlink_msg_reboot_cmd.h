#pragma once
// MESSAGE REBOOT_CMD PACKING

#define MAVLINK_MSG_ID_REBOOT_CMD 13


typedef struct __mavlink_reboot_cmd_t {
 uint32_t reserver; /*<  保留字*/
} mavlink_reboot_cmd_t;

#define MAVLINK_MSG_ID_REBOOT_CMD_LEN 4
#define MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN 4
#define MAVLINK_MSG_ID_13_LEN 4
#define MAVLINK_MSG_ID_13_MIN_LEN 4

#define MAVLINK_MSG_ID_REBOOT_CMD_CRC 165
#define MAVLINK_MSG_ID_13_CRC 165



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_REBOOT_CMD { \
    13, \
    "REBOOT_CMD", \
    1, \
    {  { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_reboot_cmd_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_REBOOT_CMD { \
    "REBOOT_CMD", \
    1, \
    {  { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_reboot_cmd_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a reboot_cmd message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_reboot_cmd_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_REBOOT_CMD_LEN];
    _mav_put_uint32_t(buf, 0, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#else
    mavlink_reboot_cmd_t packet;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_REBOOT_CMD;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
}

/**
 * @brief Pack a reboot_cmd message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_reboot_cmd_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_REBOOT_CMD_LEN];
    _mav_put_uint32_t(buf, 0, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#else
    mavlink_reboot_cmd_t packet;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_REBOOT_CMD;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#endif
}

/**
 * @brief Pack a reboot_cmd message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_reboot_cmd_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_REBOOT_CMD_LEN];
    _mav_put_uint32_t(buf, 0, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#else
    mavlink_reboot_cmd_t packet;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_REBOOT_CMD;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
}

/**
 * @brief Encode a reboot_cmd struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param reboot_cmd C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_reboot_cmd_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_reboot_cmd_t* reboot_cmd)
{
    return mavlink_msg_reboot_cmd_pack(system_id, component_id, msg, reboot_cmd->reserver);
}

/**
 * @brief Encode a reboot_cmd struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param reboot_cmd C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_reboot_cmd_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_reboot_cmd_t* reboot_cmd)
{
    return mavlink_msg_reboot_cmd_pack_chan(system_id, component_id, chan, msg, reboot_cmd->reserver);
}

/**
 * @brief Encode a reboot_cmd struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param reboot_cmd C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_reboot_cmd_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_reboot_cmd_t* reboot_cmd)
{
    return mavlink_msg_reboot_cmd_pack_status(system_id, component_id, _status, msg,  reboot_cmd->reserver);
}

/**
 * @brief Send a reboot_cmd message
 * @param chan MAVLink channel to send the message
 *
 * @param reserver  保留字
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_reboot_cmd_send(mavlink_channel_t chan, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_REBOOT_CMD_LEN];
    _mav_put_uint32_t(buf, 0, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_REBOOT_CMD, buf, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#else
    mavlink_reboot_cmd_t packet;
    packet.reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_REBOOT_CMD, (const char *)&packet, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#endif
}

/**
 * @brief Send a reboot_cmd message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_reboot_cmd_send_struct(mavlink_channel_t chan, const mavlink_reboot_cmd_t* reboot_cmd)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_reboot_cmd_send(chan, reboot_cmd->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_REBOOT_CMD, (const char *)reboot_cmd, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#endif
}

#if MAVLINK_MSG_ID_REBOOT_CMD_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_reboot_cmd_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_REBOOT_CMD, buf, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#else
    mavlink_reboot_cmd_t *packet = (mavlink_reboot_cmd_t *)msgbuf;
    packet->reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_REBOOT_CMD, (const char *)packet, MAVLINK_MSG_ID_REBOOT_CMD_MIN_LEN, MAVLINK_MSG_ID_REBOOT_CMD_LEN, MAVLINK_MSG_ID_REBOOT_CMD_CRC);
#endif
}
#endif

#endif

// MESSAGE REBOOT_CMD UNPACKING


/**
 * @brief Get field reserver from reboot_cmd message
 *
 * @return  保留字
 */
static inline uint32_t mavlink_msg_reboot_cmd_get_reserver(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a reboot_cmd message into a struct
 *
 * @param msg The message to decode
 * @param reboot_cmd C-struct to decode the message contents into
 */
static inline void mavlink_msg_reboot_cmd_decode(const mavlink_message_t* msg, mavlink_reboot_cmd_t* reboot_cmd)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    reboot_cmd->reserver = mavlink_msg_reboot_cmd_get_reserver(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_REBOOT_CMD_LEN? msg->len : MAVLINK_MSG_ID_REBOOT_CMD_LEN;
        memset(reboot_cmd, 0, MAVLINK_MSG_ID_REBOOT_CMD_LEN);
    memcpy(reboot_cmd, _MAV_PAYLOAD(msg), len);
#endif
}
