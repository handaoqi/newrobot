#pragma once
// MESSAGE TAIL_LED_CONTROL PACKING

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL 26


typedef struct __mavlink_tail_led_control_t {
 uint32_t interval; /*<  闪烁频率,0xffffffff代表常亮*/
 uint8_t R; /*<  R*/
 uint8_t G; /*<  G*/
 uint8_t B; /*<  B*/
} mavlink_tail_led_control_t;

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN 7
#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN 7
#define MAVLINK_MSG_ID_26_LEN 7
#define MAVLINK_MSG_ID_26_MIN_LEN 7

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC 9
#define MAVLINK_MSG_ID_26_CRC 9



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_TAIL_LED_CONTROL { \
    26, \
    "TAIL_LED_CONTROL", \
    4, \
    {  { "R", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_tail_led_control_t, R) }, \
         { "G", NULL, MAVLINK_TYPE_UINT8_T, 0, 5, offsetof(mavlink_tail_led_control_t, G) }, \
         { "B", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_tail_led_control_t, B) }, \
         { "interval", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_tail_led_control_t, interval) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_TAIL_LED_CONTROL { \
    "TAIL_LED_CONTROL", \
    4, \
    {  { "R", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_tail_led_control_t, R) }, \
         { "G", NULL, MAVLINK_TYPE_UINT8_T, 0, 5, offsetof(mavlink_tail_led_control_t, G) }, \
         { "B", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_tail_led_control_t, B) }, \
         { "interval", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_tail_led_control_t, interval) }, \
         } \
}
#endif

/**
 * @brief Pack a tail_led_control message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param R  R
 * @param G  G
 * @param B  B
 * @param interval  闪烁频率,0xffffffff代表常亮
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t R, uint8_t G, uint8_t B, uint32_t interval)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN];
    _mav_put_uint32_t(buf, 0, interval);
    _mav_put_uint8_t(buf, 4, R);
    _mav_put_uint8_t(buf, 5, G);
    _mav_put_uint8_t(buf, 6, B);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#else
    mavlink_tail_led_control_t packet;
    packet.interval = interval;
    packet.R = R;
    packet.G = G;
    packet.B = B;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
}

/**
 * @brief Pack a tail_led_control message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param R  R
 * @param G  G
 * @param B  B
 * @param interval  闪烁频率,0xffffffff代表常亮
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t R, uint8_t G, uint8_t B, uint32_t interval)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN];
    _mav_put_uint32_t(buf, 0, interval);
    _mav_put_uint8_t(buf, 4, R);
    _mav_put_uint8_t(buf, 5, G);
    _mav_put_uint8_t(buf, 6, B);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#else
    mavlink_tail_led_control_t packet;
    packet.interval = interval;
    packet.R = R;
    packet.G = G;
    packet.B = B;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#endif
}

/**
 * @brief Pack a tail_led_control message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param R  R
 * @param G  G
 * @param B  B
 * @param interval  闪烁频率,0xffffffff代表常亮
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t R,uint8_t G,uint8_t B,uint32_t interval)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN];
    _mav_put_uint32_t(buf, 0, interval);
    _mav_put_uint8_t(buf, 4, R);
    _mav_put_uint8_t(buf, 5, G);
    _mav_put_uint8_t(buf, 6, B);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#else
    mavlink_tail_led_control_t packet;
    packet.interval = interval;
    packet.R = R;
    packet.G = G;
    packet.B = B;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
}

/**
 * @brief Encode a tail_led_control struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_tail_led_control_t* tail_led_control)
{
    return mavlink_msg_tail_led_control_pack(system_id, component_id, msg, tail_led_control->R, tail_led_control->G, tail_led_control->B, tail_led_control->interval);
}

/**
 * @brief Encode a tail_led_control struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_tail_led_control_t* tail_led_control)
{
    return mavlink_msg_tail_led_control_pack_chan(system_id, component_id, chan, msg, tail_led_control->R, tail_led_control->G, tail_led_control->B, tail_led_control->interval);
}

/**
 * @brief Encode a tail_led_control struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_tail_led_control_t* tail_led_control)
{
    return mavlink_msg_tail_led_control_pack_status(system_id, component_id, _status, msg,  tail_led_control->R, tail_led_control->G, tail_led_control->B, tail_led_control->interval);
}

/**
 * @brief Send a tail_led_control message
 * @param chan MAVLink channel to send the message
 *
 * @param R  R
 * @param G  G
 * @param B  B
 * @param interval  闪烁频率,0xffffffff代表常亮
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_tail_led_control_send(mavlink_channel_t chan, uint8_t R, uint8_t G, uint8_t B, uint32_t interval)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN];
    _mav_put_uint32_t(buf, 0, interval);
    _mav_put_uint8_t(buf, 4, R);
    _mav_put_uint8_t(buf, 5, G);
    _mav_put_uint8_t(buf, 6, B);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL, buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#else
    mavlink_tail_led_control_t packet;
    packet.interval = interval;
    packet.R = R;
    packet.G = G;
    packet.B = B;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL, (const char *)&packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#endif
}

/**
 * @brief Send a tail_led_control message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_tail_led_control_send_struct(mavlink_channel_t chan, const mavlink_tail_led_control_t* tail_led_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_tail_led_control_send(chan, tail_led_control->R, tail_led_control->G, tail_led_control->B, tail_led_control->interval);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL, (const char *)tail_led_control, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#endif
}

#if MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_tail_led_control_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t R, uint8_t G, uint8_t B, uint32_t interval)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, interval);
    _mav_put_uint8_t(buf, 4, R);
    _mav_put_uint8_t(buf, 5, G);
    _mav_put_uint8_t(buf, 6, B);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL, buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#else
    mavlink_tail_led_control_t *packet = (mavlink_tail_led_control_t *)msgbuf;
    packet->interval = interval;
    packet->R = R;
    packet->G = G;
    packet->B = B;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL, (const char *)packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CRC);
#endif
}
#endif

#endif

// MESSAGE TAIL_LED_CONTROL UNPACKING


/**
 * @brief Get field R from tail_led_control message
 *
 * @return  R
 */
static inline uint8_t mavlink_msg_tail_led_control_get_R(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  4);
}

/**
 * @brief Get field G from tail_led_control message
 *
 * @return  G
 */
static inline uint8_t mavlink_msg_tail_led_control_get_G(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  5);
}

/**
 * @brief Get field B from tail_led_control message
 *
 * @return  B
 */
static inline uint8_t mavlink_msg_tail_led_control_get_B(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  6);
}

/**
 * @brief Get field interval from tail_led_control message
 *
 * @return  闪烁频率,0xffffffff代表常亮
 */
static inline uint32_t mavlink_msg_tail_led_control_get_interval(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a tail_led_control message into a struct
 *
 * @param msg The message to decode
 * @param tail_led_control C-struct to decode the message contents into
 */
static inline void mavlink_msg_tail_led_control_decode(const mavlink_message_t* msg, mavlink_tail_led_control_t* tail_led_control)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    tail_led_control->interval = mavlink_msg_tail_led_control_get_interval(msg);
    tail_led_control->R = mavlink_msg_tail_led_control_get_R(msg);
    tail_led_control->G = mavlink_msg_tail_led_control_get_G(msg);
    tail_led_control->B = mavlink_msg_tail_led_control_get_B(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN? msg->len : MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN;
        memset(tail_led_control, 0, MAVLINK_MSG_ID_TAIL_LED_CONTROL_LEN);
    memcpy(tail_led_control, _MAV_PAYLOAD(msg), len);
#endif
}
