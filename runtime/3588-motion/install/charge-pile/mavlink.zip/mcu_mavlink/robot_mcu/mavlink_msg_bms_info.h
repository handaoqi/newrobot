#pragma once
// MESSAGE BMS_INFO PACKING

#define MAVLINK_MSG_ID_BMS_INFO 2


typedef struct __mavlink_bms_info_t {
 uint16_t capacity; /*<  容量*/
 uint16_t volt; /*<  电压*/
 uint16_t current; /*<  电流*/
 uint16_t temp; /*<  温度*/
 uint16_t error; /*<  错误码*/
 uint8_t power; /*<  电量*/
} mavlink_bms_info_t;

#define MAVLINK_MSG_ID_BMS_INFO_LEN 11
#define MAVLINK_MSG_ID_BMS_INFO_MIN_LEN 11
#define MAVLINK_MSG_ID_2_LEN 11
#define MAVLINK_MSG_ID_2_MIN_LEN 11

#define MAVLINK_MSG_ID_BMS_INFO_CRC 119
#define MAVLINK_MSG_ID_2_CRC 119



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_BMS_INFO { \
    2, \
    "BMS_INFO", \
    6, \
    {  { "power", NULL, MAVLINK_TYPE_UINT8_T, 0, 10, offsetof(mavlink_bms_info_t, power) }, \
         { "capacity", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_bms_info_t, capacity) }, \
         { "volt", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_bms_info_t, volt) }, \
         { "current", NULL, MAVLINK_TYPE_UINT16_T, 0, 4, offsetof(mavlink_bms_info_t, current) }, \
         { "temp", NULL, MAVLINK_TYPE_UINT16_T, 0, 6, offsetof(mavlink_bms_info_t, temp) }, \
         { "error", NULL, MAVLINK_TYPE_UINT16_T, 0, 8, offsetof(mavlink_bms_info_t, error) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_BMS_INFO { \
    "BMS_INFO", \
    6, \
    {  { "power", NULL, MAVLINK_TYPE_UINT8_T, 0, 10, offsetof(mavlink_bms_info_t, power) }, \
         { "capacity", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_bms_info_t, capacity) }, \
         { "volt", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_bms_info_t, volt) }, \
         { "current", NULL, MAVLINK_TYPE_UINT16_T, 0, 4, offsetof(mavlink_bms_info_t, current) }, \
         { "temp", NULL, MAVLINK_TYPE_UINT16_T, 0, 6, offsetof(mavlink_bms_info_t, temp) }, \
         { "error", NULL, MAVLINK_TYPE_UINT16_T, 0, 8, offsetof(mavlink_bms_info_t, error) }, \
         } \
}
#endif

/**
 * @brief Pack a bms_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param power  电量
 * @param capacity  容量
 * @param volt  电压
 * @param current  电流
 * @param temp  温度
 * @param error  错误码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bms_info_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t power, uint16_t capacity, uint16_t volt, uint16_t current, uint16_t temp, uint16_t error)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BMS_INFO_LEN];
    _mav_put_uint16_t(buf, 0, capacity);
    _mav_put_uint16_t(buf, 2, volt);
    _mav_put_uint16_t(buf, 4, current);
    _mav_put_uint16_t(buf, 6, temp);
    _mav_put_uint16_t(buf, 8, error);
    _mav_put_uint8_t(buf, 10, power);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BMS_INFO_LEN);
#else
    mavlink_bms_info_t packet;
    packet.capacity = capacity;
    packet.volt = volt;
    packet.current = current;
    packet.temp = temp;
    packet.error = error;
    packet.power = power;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BMS_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_BMS_INFO;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
}

/**
 * @brief Pack a bms_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param power  电量
 * @param capacity  容量
 * @param volt  电压
 * @param current  电流
 * @param temp  温度
 * @param error  错误码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bms_info_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t power, uint16_t capacity, uint16_t volt, uint16_t current, uint16_t temp, uint16_t error)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BMS_INFO_LEN];
    _mav_put_uint16_t(buf, 0, capacity);
    _mav_put_uint16_t(buf, 2, volt);
    _mav_put_uint16_t(buf, 4, current);
    _mav_put_uint16_t(buf, 6, temp);
    _mav_put_uint16_t(buf, 8, error);
    _mav_put_uint8_t(buf, 10, power);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BMS_INFO_LEN);
#else
    mavlink_bms_info_t packet;
    packet.capacity = capacity;
    packet.volt = volt;
    packet.current = current;
    packet.temp = temp;
    packet.error = error;
    packet.power = power;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BMS_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_BMS_INFO;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN);
#endif
}

/**
 * @brief Pack a bms_info message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param power  电量
 * @param capacity  容量
 * @param volt  电压
 * @param current  电流
 * @param temp  温度
 * @param error  错误码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bms_info_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t power,uint16_t capacity,uint16_t volt,uint16_t current,uint16_t temp,uint16_t error)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BMS_INFO_LEN];
    _mav_put_uint16_t(buf, 0, capacity);
    _mav_put_uint16_t(buf, 2, volt);
    _mav_put_uint16_t(buf, 4, current);
    _mav_put_uint16_t(buf, 6, temp);
    _mav_put_uint16_t(buf, 8, error);
    _mav_put_uint8_t(buf, 10, power);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BMS_INFO_LEN);
#else
    mavlink_bms_info_t packet;
    packet.capacity = capacity;
    packet.volt = volt;
    packet.current = current;
    packet.temp = temp;
    packet.error = error;
    packet.power = power;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BMS_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_BMS_INFO;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
}

/**
 * @brief Encode a bms_info struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param bms_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bms_info_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_bms_info_t* bms_info)
{
    return mavlink_msg_bms_info_pack(system_id, component_id, msg, bms_info->power, bms_info->capacity, bms_info->volt, bms_info->current, bms_info->temp, bms_info->error);
}

/**
 * @brief Encode a bms_info struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param bms_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bms_info_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_bms_info_t* bms_info)
{
    return mavlink_msg_bms_info_pack_chan(system_id, component_id, chan, msg, bms_info->power, bms_info->capacity, bms_info->volt, bms_info->current, bms_info->temp, bms_info->error);
}

/**
 * @brief Encode a bms_info struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param bms_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bms_info_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_bms_info_t* bms_info)
{
    return mavlink_msg_bms_info_pack_status(system_id, component_id, _status, msg,  bms_info->power, bms_info->capacity, bms_info->volt, bms_info->current, bms_info->temp, bms_info->error);
}

/**
 * @brief Send a bms_info message
 * @param chan MAVLink channel to send the message
 *
 * @param power  电量
 * @param capacity  容量
 * @param volt  电压
 * @param current  电流
 * @param temp  温度
 * @param error  错误码
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_bms_info_send(mavlink_channel_t chan, uint8_t power, uint16_t capacity, uint16_t volt, uint16_t current, uint16_t temp, uint16_t error)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_BMS_INFO_LEN];
    _mav_put_uint16_t(buf, 0, capacity);
    _mav_put_uint16_t(buf, 2, volt);
    _mav_put_uint16_t(buf, 4, current);
    _mav_put_uint16_t(buf, 6, temp);
    _mav_put_uint16_t(buf, 8, error);
    _mav_put_uint8_t(buf, 10, power);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BMS_INFO, buf, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#else
    mavlink_bms_info_t packet;
    packet.capacity = capacity;
    packet.volt = volt;
    packet.current = current;
    packet.temp = temp;
    packet.error = error;
    packet.power = power;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BMS_INFO, (const char *)&packet, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#endif
}

/**
 * @brief Send a bms_info message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_bms_info_send_struct(mavlink_channel_t chan, const mavlink_bms_info_t* bms_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_bms_info_send(chan, bms_info->power, bms_info->capacity, bms_info->volt, bms_info->current, bms_info->temp, bms_info->error);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BMS_INFO, (const char *)bms_info, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#endif
}

#if MAVLINK_MSG_ID_BMS_INFO_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_bms_info_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t power, uint16_t capacity, uint16_t volt, uint16_t current, uint16_t temp, uint16_t error)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, capacity);
    _mav_put_uint16_t(buf, 2, volt);
    _mav_put_uint16_t(buf, 4, current);
    _mav_put_uint16_t(buf, 6, temp);
    _mav_put_uint16_t(buf, 8, error);
    _mav_put_uint8_t(buf, 10, power);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BMS_INFO, buf, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#else
    mavlink_bms_info_t *packet = (mavlink_bms_info_t *)msgbuf;
    packet->capacity = capacity;
    packet->volt = volt;
    packet->current = current;
    packet->temp = temp;
    packet->error = error;
    packet->power = power;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BMS_INFO, (const char *)packet, MAVLINK_MSG_ID_BMS_INFO_MIN_LEN, MAVLINK_MSG_ID_BMS_INFO_LEN, MAVLINK_MSG_ID_BMS_INFO_CRC);
#endif
}
#endif

#endif

// MESSAGE BMS_INFO UNPACKING


/**
 * @brief Get field power from bms_info message
 *
 * @return  电量
 */
static inline uint8_t mavlink_msg_bms_info_get_power(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  10);
}

/**
 * @brief Get field capacity from bms_info message
 *
 * @return  容量
 */
static inline uint16_t mavlink_msg_bms_info_get_capacity(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Get field volt from bms_info message
 *
 * @return  电压
 */
static inline uint16_t mavlink_msg_bms_info_get_volt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  2);
}

/**
 * @brief Get field current from bms_info message
 *
 * @return  电流
 */
static inline uint16_t mavlink_msg_bms_info_get_current(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  4);
}

/**
 * @brief Get field temp from bms_info message
 *
 * @return  温度
 */
static inline uint16_t mavlink_msg_bms_info_get_temp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  6);
}

/**
 * @brief Get field error from bms_info message
 *
 * @return  错误码
 */
static inline uint16_t mavlink_msg_bms_info_get_error(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  8);
}

/**
 * @brief Decode a bms_info message into a struct
 *
 * @param msg The message to decode
 * @param bms_info C-struct to decode the message contents into
 */
static inline void mavlink_msg_bms_info_decode(const mavlink_message_t* msg, mavlink_bms_info_t* bms_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    bms_info->capacity = mavlink_msg_bms_info_get_capacity(msg);
    bms_info->volt = mavlink_msg_bms_info_get_volt(msg);
    bms_info->current = mavlink_msg_bms_info_get_current(msg);
    bms_info->temp = mavlink_msg_bms_info_get_temp(msg);
    bms_info->error = mavlink_msg_bms_info_get_error(msg);
    bms_info->power = mavlink_msg_bms_info_get_power(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_BMS_INFO_LEN? msg->len : MAVLINK_MSG_ID_BMS_INFO_LEN;
        memset(bms_info, 0, MAVLINK_MSG_ID_BMS_INFO_LEN);
    memcpy(bms_info, _MAV_PAYLOAD(msg), len);
#endif
}
