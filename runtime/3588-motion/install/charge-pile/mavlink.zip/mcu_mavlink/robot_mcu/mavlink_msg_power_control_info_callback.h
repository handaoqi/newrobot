#pragma once
// MESSAGE POWER_CONTROL_INFO_CALLBACK PACKING

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK 4


typedef struct __mavlink_power_control_info_callback_t {
 uint8_t power_id; /*<  电源域ID*/
 uint8_t result; /*<  反馈的控制结果*/
} mavlink_power_control_info_callback_t;

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN 2
#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN 2
#define MAVLINK_MSG_ID_4_LEN 2
#define MAVLINK_MSG_ID_4_MIN_LEN 2

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC 15
#define MAVLINK_MSG_ID_4_CRC 15



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_POWER_CONTROL_INFO_CALLBACK { \
    4, \
    "POWER_CONTROL_INFO_CALLBACK", \
    2, \
    {  { "power_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_power_control_info_callback_t, power_id) }, \
         { "result", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_power_control_info_callback_t, result) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_POWER_CONTROL_INFO_CALLBACK { \
    "POWER_CONTROL_INFO_CALLBACK", \
    2, \
    {  { "power_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_power_control_info_callback_t, power_id) }, \
         { "result", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_power_control_info_callback_t, result) }, \
         } \
}
#endif

/**
 * @brief Pack a power_control_info_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param power_id  电源域ID
 * @param result  反馈的控制结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_callback_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t power_id, uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#else
    mavlink_power_control_info_callback_t packet;
    packet.power_id = power_id;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
}

/**
 * @brief Pack a power_control_info_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param power_id  电源域ID
 * @param result  反馈的控制结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_callback_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t power_id, uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#else
    mavlink_power_control_info_callback_t packet;
    packet.power_id = power_id;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#endif
}

/**
 * @brief Pack a power_control_info_callback message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param power_id  电源域ID
 * @param result  反馈的控制结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_callback_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t power_id,uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#else
    mavlink_power_control_info_callback_t packet;
    packet.power_id = power_id;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
}

/**
 * @brief Encode a power_control_info_callback struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_callback_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_power_control_info_callback_t* power_control_info_callback)
{
    return mavlink_msg_power_control_info_callback_pack(system_id, component_id, msg, power_control_info_callback->power_id, power_control_info_callback->result);
}

/**
 * @brief Encode a power_control_info_callback struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_callback_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_power_control_info_callback_t* power_control_info_callback)
{
    return mavlink_msg_power_control_info_callback_pack_chan(system_id, component_id, chan, msg, power_control_info_callback->power_id, power_control_info_callback->result);
}

/**
 * @brief Encode a power_control_info_callback struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_callback_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_power_control_info_callback_t* power_control_info_callback)
{
    return mavlink_msg_power_control_info_callback_pack_status(system_id, component_id, _status, msg,  power_control_info_callback->power_id, power_control_info_callback->result);
}

/**
 * @brief Send a power_control_info_callback message
 * @param chan MAVLink channel to send the message
 *
 * @param power_id  电源域ID
 * @param result  反馈的控制结果
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_power_control_info_callback_send(mavlink_channel_t chan, uint8_t power_id, uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, result);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK, buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#else
    mavlink_power_control_info_callback_t packet;
    packet.power_id = power_id;
    packet.result = result;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK, (const char *)&packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#endif
}

/**
 * @brief Send a power_control_info_callback message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_power_control_info_callback_send_struct(mavlink_channel_t chan, const mavlink_power_control_info_callback_t* power_control_info_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_power_control_info_callback_send(chan, power_control_info_callback->power_id, power_control_info_callback->result);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK, (const char *)power_control_info_callback, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#endif
}

#if MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_power_control_info_callback_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t power_id, uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, result);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK, buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#else
    mavlink_power_control_info_callback_t *packet = (mavlink_power_control_info_callback_t *)msgbuf;
    packet->power_id = power_id;
    packet->result = result;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK, (const char *)packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_CRC);
#endif
}
#endif

#endif

// MESSAGE POWER_CONTROL_INFO_CALLBACK UNPACKING


/**
 * @brief Get field power_id from power_control_info_callback message
 *
 * @return  电源域ID
 */
static inline uint8_t mavlink_msg_power_control_info_callback_get_power_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field result from power_control_info_callback message
 *
 * @return  反馈的控制结果
 */
static inline uint8_t mavlink_msg_power_control_info_callback_get_result(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Decode a power_control_info_callback message into a struct
 *
 * @param msg The message to decode
 * @param power_control_info_callback C-struct to decode the message contents into
 */
static inline void mavlink_msg_power_control_info_callback_decode(const mavlink_message_t* msg, mavlink_power_control_info_callback_t* power_control_info_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    power_control_info_callback->power_id = mavlink_msg_power_control_info_callback_get_power_id(msg);
    power_control_info_callback->result = mavlink_msg_power_control_info_callback_get_result(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN? msg->len : MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN;
        memset(power_control_info_callback, 0, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CALLBACK_LEN);
    memcpy(power_control_info_callback, _MAV_PAYLOAD(msg), len);
#endif
}
