#pragma once
// MESSAGE JOINT_UPGRADE_DATA PACKING

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA 100


typedef struct __mavlink_joint_upgrade_data_t {
 uint32_t file_size; /*<  文件大小*/
 uint32_t node_mask; /*<  节点掩码*/
 uint32_t leg_mask; /*<  腿掩码*/
 uint16_t frams_max; /*<  总帧数，(file_size / 56)*/
 uint16_t frams_num; /*<  当前帧，(file_size / 56)*/
 uint8_t data[56]; /*<  固件数据*/
} mavlink_joint_upgrade_data_t;

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN 72
#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN 72
#define MAVLINK_MSG_ID_100_LEN 72
#define MAVLINK_MSG_ID_100_MIN_LEN 72

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC 192
#define MAVLINK_MSG_ID_100_CRC 192

#define MAVLINK_MSG_JOINT_UPGRADE_DATA_FIELD_DATA_LEN 56

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_JOINT_UPGRADE_DATA { \
    100, \
    "JOINT_UPGRADE_DATA", \
    6, \
    {  { "file_size", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_upgrade_data_t, file_size) }, \
         { "frams_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_joint_upgrade_data_t, frams_max) }, \
         { "frams_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 14, offsetof(mavlink_joint_upgrade_data_t, frams_num) }, \
         { "data", NULL, MAVLINK_TYPE_UINT8_T, 56, 16, offsetof(mavlink_joint_upgrade_data_t, data) }, \
         { "node_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_upgrade_data_t, node_mask) }, \
         { "leg_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_joint_upgrade_data_t, leg_mask) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_JOINT_UPGRADE_DATA { \
    "JOINT_UPGRADE_DATA", \
    6, \
    {  { "file_size", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_upgrade_data_t, file_size) }, \
         { "frams_max", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_joint_upgrade_data_t, frams_max) }, \
         { "frams_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 14, offsetof(mavlink_joint_upgrade_data_t, frams_num) }, \
         { "data", NULL, MAVLINK_TYPE_UINT8_T, 56, 16, offsetof(mavlink_joint_upgrade_data_t, data) }, \
         { "node_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_upgrade_data_t, node_mask) }, \
         { "leg_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_joint_upgrade_data_t, leg_mask) }, \
         } \
}
#endif

/**
 * @brief Pack a joint_upgrade_data message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param file_size  文件大小
 * @param frams_max  总帧数，(file_size / 56)
 * @param frams_num  当前帧，(file_size / 56)
 * @param data  固件数据
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t file_size, uint16_t frams_max, uint16_t frams_num, const uint8_t *data, uint32_t node_mask, uint32_t leg_mask)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, file_size);
    _mav_put_uint32_t(buf, 4, node_mask);
    _mav_put_uint32_t(buf, 8, leg_mask);
    _mav_put_uint16_t(buf, 12, frams_max);
    _mav_put_uint16_t(buf, 14, frams_num);
    _mav_put_uint8_t_array(buf, 16, data, 56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#else
    mavlink_joint_upgrade_data_t packet;
    packet.file_size = file_size;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.frams_max = frams_max;
    packet.frams_num = frams_num;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
}

/**
 * @brief Pack a joint_upgrade_data message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param file_size  文件大小
 * @param frams_max  总帧数，(file_size / 56)
 * @param frams_num  当前帧，(file_size / 56)
 * @param data  固件数据
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t file_size, uint16_t frams_max, uint16_t frams_num, const uint8_t *data, uint32_t node_mask, uint32_t leg_mask)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, file_size);
    _mav_put_uint32_t(buf, 4, node_mask);
    _mav_put_uint32_t(buf, 8, leg_mask);
    _mav_put_uint16_t(buf, 12, frams_max);
    _mav_put_uint16_t(buf, 14, frams_num);
    _mav_put_uint8_t_array(buf, 16, data, 56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#else
    mavlink_joint_upgrade_data_t packet;
    packet.file_size = file_size;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.frams_max = frams_max;
    packet.frams_num = frams_num;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#endif
}

/**
 * @brief Pack a joint_upgrade_data message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param file_size  文件大小
 * @param frams_max  总帧数，(file_size / 56)
 * @param frams_num  当前帧，(file_size / 56)
 * @param data  固件数据
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t file_size,uint16_t frams_max,uint16_t frams_num,const uint8_t *data,uint32_t node_mask,uint32_t leg_mask)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, file_size);
    _mav_put_uint32_t(buf, 4, node_mask);
    _mav_put_uint32_t(buf, 8, leg_mask);
    _mav_put_uint16_t(buf, 12, frams_max);
    _mav_put_uint16_t(buf, 14, frams_num);
    _mav_put_uint8_t_array(buf, 16, data, 56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#else
    mavlink_joint_upgrade_data_t packet;
    packet.file_size = file_size;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.frams_max = frams_max;
    packet.frams_num = frams_num;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*56);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
}

/**
 * @brief Encode a joint_upgrade_data struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_joint_upgrade_data_t* joint_upgrade_data)
{
    return mavlink_msg_joint_upgrade_data_pack(system_id, component_id, msg, joint_upgrade_data->file_size, joint_upgrade_data->frams_max, joint_upgrade_data->frams_num, joint_upgrade_data->data, joint_upgrade_data->node_mask, joint_upgrade_data->leg_mask);
}

/**
 * @brief Encode a joint_upgrade_data struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_joint_upgrade_data_t* joint_upgrade_data)
{
    return mavlink_msg_joint_upgrade_data_pack_chan(system_id, component_id, chan, msg, joint_upgrade_data->file_size, joint_upgrade_data->frams_max, joint_upgrade_data->frams_num, joint_upgrade_data->data, joint_upgrade_data->node_mask, joint_upgrade_data->leg_mask);
}

/**
 * @brief Encode a joint_upgrade_data struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_joint_upgrade_data_t* joint_upgrade_data)
{
    return mavlink_msg_joint_upgrade_data_pack_status(system_id, component_id, _status, msg,  joint_upgrade_data->file_size, joint_upgrade_data->frams_max, joint_upgrade_data->frams_num, joint_upgrade_data->data, joint_upgrade_data->node_mask, joint_upgrade_data->leg_mask);
}

/**
 * @brief Send a joint_upgrade_data message
 * @param chan MAVLink channel to send the message
 *
 * @param file_size  文件大小
 * @param frams_max  总帧数，(file_size / 56)
 * @param frams_num  当前帧，(file_size / 56)
 * @param data  固件数据
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_joint_upgrade_data_send(mavlink_channel_t chan, uint32_t file_size, uint16_t frams_max, uint16_t frams_num, const uint8_t *data, uint32_t node_mask, uint32_t leg_mask)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN];
    _mav_put_uint32_t(buf, 0, file_size);
    _mav_put_uint32_t(buf, 4, node_mask);
    _mav_put_uint32_t(buf, 8, leg_mask);
    _mav_put_uint16_t(buf, 12, frams_max);
    _mav_put_uint16_t(buf, 14, frams_num);
    _mav_put_uint8_t_array(buf, 16, data, 56);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA, buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#else
    mavlink_joint_upgrade_data_t packet;
    packet.file_size = file_size;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.frams_max = frams_max;
    packet.frams_num = frams_num;
    mav_array_memcpy(packet.data, data, sizeof(uint8_t)*56);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA, (const char *)&packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#endif
}

/**
 * @brief Send a joint_upgrade_data message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_joint_upgrade_data_send_struct(mavlink_channel_t chan, const mavlink_joint_upgrade_data_t* joint_upgrade_data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_joint_upgrade_data_send(chan, joint_upgrade_data->file_size, joint_upgrade_data->frams_max, joint_upgrade_data->frams_num, joint_upgrade_data->data, joint_upgrade_data->node_mask, joint_upgrade_data->leg_mask);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA, (const char *)joint_upgrade_data, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#endif
}

#if MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_joint_upgrade_data_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t file_size, uint16_t frams_max, uint16_t frams_num, const uint8_t *data, uint32_t node_mask, uint32_t leg_mask)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, file_size);
    _mav_put_uint32_t(buf, 4, node_mask);
    _mav_put_uint32_t(buf, 8, leg_mask);
    _mav_put_uint16_t(buf, 12, frams_max);
    _mav_put_uint16_t(buf, 14, frams_num);
    _mav_put_uint8_t_array(buf, 16, data, 56);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA, buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#else
    mavlink_joint_upgrade_data_t *packet = (mavlink_joint_upgrade_data_t *)msgbuf;
    packet->file_size = file_size;
    packet->node_mask = node_mask;
    packet->leg_mask = leg_mask;
    packet->frams_max = frams_max;
    packet->frams_num = frams_num;
    mav_array_memcpy(packet->data, data, sizeof(uint8_t)*56);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA, (const char *)packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_CRC);
#endif
}
#endif

#endif

// MESSAGE JOINT_UPGRADE_DATA UNPACKING


/**
 * @brief Get field file_size from joint_upgrade_data message
 *
 * @return  文件大小
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_get_file_size(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field frams_max from joint_upgrade_data message
 *
 * @return  总帧数，(file_size / 56)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_get_frams_max(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  12);
}

/**
 * @brief Get field frams_num from joint_upgrade_data message
 *
 * @return  当前帧，(file_size / 56)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_get_frams_num(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  14);
}

/**
 * @brief Get field data from joint_upgrade_data message
 *
 * @return  固件数据
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_get_data(const mavlink_message_t* msg, uint8_t *data)
{
    return _MAV_RETURN_uint8_t_array(msg, data, 56,  16);
}

/**
 * @brief Get field node_mask from joint_upgrade_data message
 *
 * @return  节点掩码
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_get_node_mask(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field leg_mask from joint_upgrade_data message
 *
 * @return  腿掩码
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_get_leg_mask(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Decode a joint_upgrade_data message into a struct
 *
 * @param msg The message to decode
 * @param joint_upgrade_data C-struct to decode the message contents into
 */
static inline void mavlink_msg_joint_upgrade_data_decode(const mavlink_message_t* msg, mavlink_joint_upgrade_data_t* joint_upgrade_data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    joint_upgrade_data->file_size = mavlink_msg_joint_upgrade_data_get_file_size(msg);
    joint_upgrade_data->node_mask = mavlink_msg_joint_upgrade_data_get_node_mask(msg);
    joint_upgrade_data->leg_mask = mavlink_msg_joint_upgrade_data_get_leg_mask(msg);
    joint_upgrade_data->frams_max = mavlink_msg_joint_upgrade_data_get_frams_max(msg);
    joint_upgrade_data->frams_num = mavlink_msg_joint_upgrade_data_get_frams_num(msg);
    mavlink_msg_joint_upgrade_data_get_data(msg, joint_upgrade_data->data);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN? msg->len : MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN;
        memset(joint_upgrade_data, 0, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_LEN);
    memcpy(joint_upgrade_data, _MAV_PAYLOAD(msg), len);
#endif
}
