#pragma once
// MESSAGE DOG_WRITE_CHARGE_PILE_TAG_ID PACKING

#define MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID 192


typedef struct __mavlink_dog_write_charge_pile_tag_id_t {
 uint16_t tag_id; /*<  二维码tag id*/
} mavlink_dog_write_charge_pile_tag_id_t;

#define MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN 2
#define MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN 2
#define MAVLINK_MSG_ID_192_LEN 2
#define MAVLINK_MSG_ID_192_MIN_LEN 2

#define MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC 214
#define MAVLINK_MSG_ID_192_CRC 214



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_DOG_WRITE_CHARGE_PILE_TAG_ID { \
    192, \
    "DOG_WRITE_CHARGE_PILE_TAG_ID", \
    1, \
    {  { "tag_id", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dog_write_charge_pile_tag_id_t, tag_id) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_DOG_WRITE_CHARGE_PILE_TAG_ID { \
    "DOG_WRITE_CHARGE_PILE_TAG_ID", \
    1, \
    {  { "tag_id", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_dog_write_charge_pile_tag_id_t, tag_id) }, \
         } \
}
#endif

/**
 * @brief Pack a dog_write_charge_pile_tag_id message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param tag_id  二维码tag id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint16_t tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN];
    _mav_put_uint16_t(buf, 0, tag_id);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#else
    mavlink_dog_write_charge_pile_tag_id_t packet;
    packet.tag_id = tag_id;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
}

/**
 * @brief Pack a dog_write_charge_pile_tag_id message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param tag_id  二维码tag id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint16_t tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN];
    _mav_put_uint16_t(buf, 0, tag_id);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#else
    mavlink_dog_write_charge_pile_tag_id_t packet;
    packet.tag_id = tag_id;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#endif
}

/**
 * @brief Pack a dog_write_charge_pile_tag_id message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param tag_id  二维码tag id
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint16_t tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN];
    _mav_put_uint16_t(buf, 0, tag_id);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#else
    mavlink_dog_write_charge_pile_tag_id_t packet;
    packet.tag_id = tag_id;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
}

/**
 * @brief Encode a dog_write_charge_pile_tag_id struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_charge_pile_tag_id C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dog_write_charge_pile_tag_id_t* dog_write_charge_pile_tag_id)
{
    return mavlink_msg_dog_write_charge_pile_tag_id_pack(system_id, component_id, msg, dog_write_charge_pile_tag_id->tag_id);
}

/**
 * @brief Encode a dog_write_charge_pile_tag_id struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_charge_pile_tag_id C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dog_write_charge_pile_tag_id_t* dog_write_charge_pile_tag_id)
{
    return mavlink_msg_dog_write_charge_pile_tag_id_pack_chan(system_id, component_id, chan, msg, dog_write_charge_pile_tag_id->tag_id);
}

/**
 * @brief Encode a dog_write_charge_pile_tag_id struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_charge_pile_tag_id C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_dog_write_charge_pile_tag_id_t* dog_write_charge_pile_tag_id)
{
    return mavlink_msg_dog_write_charge_pile_tag_id_pack_status(system_id, component_id, _status, msg,  dog_write_charge_pile_tag_id->tag_id);
}

/**
 * @brief Send a dog_write_charge_pile_tag_id message
 * @param chan MAVLink channel to send the message
 *
 * @param tag_id  二维码tag id
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dog_write_charge_pile_tag_id_send(mavlink_channel_t chan, uint16_t tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN];
    _mav_put_uint16_t(buf, 0, tag_id);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID, buf, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#else
    mavlink_dog_write_charge_pile_tag_id_t packet;
    packet.tag_id = tag_id;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID, (const char *)&packet, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#endif
}

/**
 * @brief Send a dog_write_charge_pile_tag_id message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dog_write_charge_pile_tag_id_send_struct(mavlink_channel_t chan, const mavlink_dog_write_charge_pile_tag_id_t* dog_write_charge_pile_tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dog_write_charge_pile_tag_id_send(chan, dog_write_charge_pile_tag_id->tag_id);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID, (const char *)dog_write_charge_pile_tag_id, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#endif
}

#if MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dog_write_charge_pile_tag_id_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint16_t(buf, 0, tag_id);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID, buf, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#else
    mavlink_dog_write_charge_pile_tag_id_t *packet = (mavlink_dog_write_charge_pile_tag_id_t *)msgbuf;
    packet->tag_id = tag_id;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID, (const char *)packet, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_CRC);
#endif
}
#endif

#endif

// MESSAGE DOG_WRITE_CHARGE_PILE_TAG_ID UNPACKING


/**
 * @brief Get field tag_id from dog_write_charge_pile_tag_id message
 *
 * @return  二维码tag id
 */
static inline uint16_t mavlink_msg_dog_write_charge_pile_tag_id_get_tag_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  0);
}

/**
 * @brief Decode a dog_write_charge_pile_tag_id message into a struct
 *
 * @param msg The message to decode
 * @param dog_write_charge_pile_tag_id C-struct to decode the message contents into
 */
static inline void mavlink_msg_dog_write_charge_pile_tag_id_decode(const mavlink_message_t* msg, mavlink_dog_write_charge_pile_tag_id_t* dog_write_charge_pile_tag_id)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dog_write_charge_pile_tag_id->tag_id = mavlink_msg_dog_write_charge_pile_tag_id_get_tag_id(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN? msg->len : MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN;
        memset(dog_write_charge_pile_tag_id, 0, MAVLINK_MSG_ID_DOG_WRITE_CHARGE_PILE_TAG_ID_LEN);
    memcpy(dog_write_charge_pile_tag_id, _MAV_PAYLOAD(msg), len);
#endif
}
