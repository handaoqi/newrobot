#pragma once
// MESSAGE CHARGE_PILE_STATUS PACKING

#define MAVLINK_MSG_ID_CHARGE_PILE_STATUS 131


typedef struct __mavlink_charge_pile_status_t {
 uint32_t als; /*<  环境光传感器*/
 uint32_t cmin_adc; /*<  负极极片ADC值*/
 uint32_t cplus_adc; /*<  正极极片ADC值*/
 uint16_t tag_id; /*<  二维码tag id*/
 uint8_t led; /*<  补光灯状态*/
 uint8_t charge_pin; /*<  充电引脚状态*/
 uint8_t cmin_status; /*<  负极极片接触状态*/
 uint8_t cplus_status; /*<  正极极片接触状态*/
 uint8_t reserver[8]; /*<  预留*/
} mavlink_charge_pile_status_t;

#define MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN 26
#define MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN 26
#define MAVLINK_MSG_ID_131_LEN 26
#define MAVLINK_MSG_ID_131_MIN_LEN 26

#define MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC 77
#define MAVLINK_MSG_ID_131_CRC 77

#define MAVLINK_MSG_CHARGE_PILE_STATUS_FIELD_RESERVER_LEN 8

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_CHARGE_PILE_STATUS { \
    131, \
    "CHARGE_PILE_STATUS", \
    9, \
    {  { "als", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_charge_pile_status_t, als) }, \
         { "led", NULL, MAVLINK_TYPE_UINT8_T, 0, 14, offsetof(mavlink_charge_pile_status_t, led) }, \
         { "charge_pin", NULL, MAVLINK_TYPE_UINT8_T, 0, 15, offsetof(mavlink_charge_pile_status_t, charge_pin) }, \
         { "cmin_adc", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_charge_pile_status_t, cmin_adc) }, \
         { "cplus_adc", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_charge_pile_status_t, cplus_adc) }, \
         { "cmin_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 16, offsetof(mavlink_charge_pile_status_t, cmin_status) }, \
         { "cplus_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 17, offsetof(mavlink_charge_pile_status_t, cplus_status) }, \
         { "tag_id", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_charge_pile_status_t, tag_id) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 18, offsetof(mavlink_charge_pile_status_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_CHARGE_PILE_STATUS { \
    "CHARGE_PILE_STATUS", \
    9, \
    {  { "als", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_charge_pile_status_t, als) }, \
         { "led", NULL, MAVLINK_TYPE_UINT8_T, 0, 14, offsetof(mavlink_charge_pile_status_t, led) }, \
         { "charge_pin", NULL, MAVLINK_TYPE_UINT8_T, 0, 15, offsetof(mavlink_charge_pile_status_t, charge_pin) }, \
         { "cmin_adc", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_charge_pile_status_t, cmin_adc) }, \
         { "cplus_adc", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_charge_pile_status_t, cplus_adc) }, \
         { "cmin_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 16, offsetof(mavlink_charge_pile_status_t, cmin_status) }, \
         { "cplus_status", NULL, MAVLINK_TYPE_UINT8_T, 0, 17, offsetof(mavlink_charge_pile_status_t, cplus_status) }, \
         { "tag_id", NULL, MAVLINK_TYPE_UINT16_T, 0, 12, offsetof(mavlink_charge_pile_status_t, tag_id) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 18, offsetof(mavlink_charge_pile_status_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a charge_pile_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param als  环境光传感器
 * @param led  补光灯状态
 * @param charge_pin  充电引脚状态
 * @param cmin_adc  负极极片ADC值
 * @param cplus_adc  正极极片ADC值
 * @param cmin_status  负极极片接触状态
 * @param cplus_status  正极极片接触状态
 * @param tag_id  二维码tag id
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_pile_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t als, uint8_t led, uint8_t charge_pin, uint32_t cmin_adc, uint32_t cplus_adc, uint8_t cmin_status, uint8_t cplus_status, uint16_t tag_id, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, als);
    _mav_put_uint32_t(buf, 4, cmin_adc);
    _mav_put_uint32_t(buf, 8, cplus_adc);
    _mav_put_uint16_t(buf, 12, tag_id);
    _mav_put_uint8_t(buf, 14, led);
    _mav_put_uint8_t(buf, 15, charge_pin);
    _mav_put_uint8_t(buf, 16, cmin_status);
    _mav_put_uint8_t(buf, 17, cplus_status);
    _mav_put_uint8_t_array(buf, 18, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#else
    mavlink_charge_pile_status_t packet;
    packet.als = als;
    packet.cmin_adc = cmin_adc;
    packet.cplus_adc = cplus_adc;
    packet.tag_id = tag_id;
    packet.led = led;
    packet.charge_pin = charge_pin;
    packet.cmin_status = cmin_status;
    packet.cplus_status = cplus_status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PILE_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
}

/**
 * @brief Pack a charge_pile_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param als  环境光传感器
 * @param led  补光灯状态
 * @param charge_pin  充电引脚状态
 * @param cmin_adc  负极极片ADC值
 * @param cplus_adc  正极极片ADC值
 * @param cmin_status  负极极片接触状态
 * @param cplus_status  正极极片接触状态
 * @param tag_id  二维码tag id
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_pile_status_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t als, uint8_t led, uint8_t charge_pin, uint32_t cmin_adc, uint32_t cplus_adc, uint8_t cmin_status, uint8_t cplus_status, uint16_t tag_id, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, als);
    _mav_put_uint32_t(buf, 4, cmin_adc);
    _mav_put_uint32_t(buf, 8, cplus_adc);
    _mav_put_uint16_t(buf, 12, tag_id);
    _mav_put_uint8_t(buf, 14, led);
    _mav_put_uint8_t(buf, 15, charge_pin);
    _mav_put_uint8_t(buf, 16, cmin_status);
    _mav_put_uint8_t(buf, 17, cplus_status);
    _mav_put_uint8_t_array(buf, 18, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#else
    mavlink_charge_pile_status_t packet;
    packet.als = als;
    packet.cmin_adc = cmin_adc;
    packet.cplus_adc = cplus_adc;
    packet.tag_id = tag_id;
    packet.led = led;
    packet.charge_pin = charge_pin;
    packet.cmin_status = cmin_status;
    packet.cplus_status = cplus_status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PILE_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#endif
}

/**
 * @brief Pack a charge_pile_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param als  环境光传感器
 * @param led  补光灯状态
 * @param charge_pin  充电引脚状态
 * @param cmin_adc  负极极片ADC值
 * @param cplus_adc  正极极片ADC值
 * @param cmin_status  负极极片接触状态
 * @param cplus_status  正极极片接触状态
 * @param tag_id  二维码tag id
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_pile_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t als,uint8_t led,uint8_t charge_pin,uint32_t cmin_adc,uint32_t cplus_adc,uint8_t cmin_status,uint8_t cplus_status,uint16_t tag_id,const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, als);
    _mav_put_uint32_t(buf, 4, cmin_adc);
    _mav_put_uint32_t(buf, 8, cplus_adc);
    _mav_put_uint16_t(buf, 12, tag_id);
    _mav_put_uint8_t(buf, 14, led);
    _mav_put_uint8_t(buf, 15, charge_pin);
    _mav_put_uint8_t(buf, 16, cmin_status);
    _mav_put_uint8_t(buf, 17, cplus_status);
    _mav_put_uint8_t_array(buf, 18, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#else
    mavlink_charge_pile_status_t packet;
    packet.als = als;
    packet.cmin_adc = cmin_adc;
    packet.cplus_adc = cplus_adc;
    packet.tag_id = tag_id;
    packet.led = led;
    packet.charge_pin = charge_pin;
    packet.cmin_status = cmin_status;
    packet.cplus_status = cplus_status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PILE_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
}

/**
 * @brief Encode a charge_pile_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param charge_pile_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_pile_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_charge_pile_status_t* charge_pile_status)
{
    return mavlink_msg_charge_pile_status_pack(system_id, component_id, msg, charge_pile_status->als, charge_pile_status->led, charge_pile_status->charge_pin, charge_pile_status->cmin_adc, charge_pile_status->cplus_adc, charge_pile_status->cmin_status, charge_pile_status->cplus_status, charge_pile_status->tag_id, charge_pile_status->reserver);
}

/**
 * @brief Encode a charge_pile_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param charge_pile_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_pile_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_charge_pile_status_t* charge_pile_status)
{
    return mavlink_msg_charge_pile_status_pack_chan(system_id, component_id, chan, msg, charge_pile_status->als, charge_pile_status->led, charge_pile_status->charge_pin, charge_pile_status->cmin_adc, charge_pile_status->cplus_adc, charge_pile_status->cmin_status, charge_pile_status->cplus_status, charge_pile_status->tag_id, charge_pile_status->reserver);
}

/**
 * @brief Encode a charge_pile_status struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param charge_pile_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_pile_status_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_charge_pile_status_t* charge_pile_status)
{
    return mavlink_msg_charge_pile_status_pack_status(system_id, component_id, _status, msg,  charge_pile_status->als, charge_pile_status->led, charge_pile_status->charge_pin, charge_pile_status->cmin_adc, charge_pile_status->cplus_adc, charge_pile_status->cmin_status, charge_pile_status->cplus_status, charge_pile_status->tag_id, charge_pile_status->reserver);
}

/**
 * @brief Send a charge_pile_status message
 * @param chan MAVLink channel to send the message
 *
 * @param als  环境光传感器
 * @param led  补光灯状态
 * @param charge_pin  充电引脚状态
 * @param cmin_adc  负极极片ADC值
 * @param cplus_adc  正极极片ADC值
 * @param cmin_status  负极极片接触状态
 * @param cplus_status  正极极片接触状态
 * @param tag_id  二维码tag id
 * @param reserver  预留
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_charge_pile_status_send(mavlink_channel_t chan, uint32_t als, uint8_t led, uint8_t charge_pin, uint32_t cmin_adc, uint32_t cplus_adc, uint8_t cmin_status, uint8_t cplus_status, uint16_t tag_id, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN];
    _mav_put_uint32_t(buf, 0, als);
    _mav_put_uint32_t(buf, 4, cmin_adc);
    _mav_put_uint32_t(buf, 8, cplus_adc);
    _mav_put_uint16_t(buf, 12, tag_id);
    _mav_put_uint8_t(buf, 14, led);
    _mav_put_uint8_t(buf, 15, charge_pin);
    _mav_put_uint8_t(buf, 16, cmin_status);
    _mav_put_uint8_t(buf, 17, cplus_status);
    _mav_put_uint8_t_array(buf, 18, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS, buf, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#else
    mavlink_charge_pile_status_t packet;
    packet.als = als;
    packet.cmin_adc = cmin_adc;
    packet.cplus_adc = cplus_adc;
    packet.tag_id = tag_id;
    packet.led = led;
    packet.charge_pin = charge_pin;
    packet.cmin_status = cmin_status;
    packet.cplus_status = cplus_status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS, (const char *)&packet, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#endif
}

/**
 * @brief Send a charge_pile_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_charge_pile_status_send_struct(mavlink_channel_t chan, const mavlink_charge_pile_status_t* charge_pile_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_charge_pile_status_send(chan, charge_pile_status->als, charge_pile_status->led, charge_pile_status->charge_pin, charge_pile_status->cmin_adc, charge_pile_status->cplus_adc, charge_pile_status->cmin_status, charge_pile_status->cplus_status, charge_pile_status->tag_id, charge_pile_status->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS, (const char *)charge_pile_status, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_charge_pile_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t als, uint8_t led, uint8_t charge_pin, uint32_t cmin_adc, uint32_t cplus_adc, uint8_t cmin_status, uint8_t cplus_status, uint16_t tag_id, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, als);
    _mav_put_uint32_t(buf, 4, cmin_adc);
    _mav_put_uint32_t(buf, 8, cplus_adc);
    _mav_put_uint16_t(buf, 12, tag_id);
    _mav_put_uint8_t(buf, 14, led);
    _mav_put_uint8_t(buf, 15, charge_pin);
    _mav_put_uint8_t(buf, 16, cmin_status);
    _mav_put_uint8_t(buf, 17, cplus_status);
    _mav_put_uint8_t_array(buf, 18, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS, buf, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#else
    mavlink_charge_pile_status_t *packet = (mavlink_charge_pile_status_t *)msgbuf;
    packet->als = als;
    packet->cmin_adc = cmin_adc;
    packet->cplus_adc = cplus_adc;
    packet->tag_id = tag_id;
    packet->led = led;
    packet->charge_pin = charge_pin;
    packet->cmin_status = cmin_status;
    packet->cplus_status = cplus_status;
    mav_array_memcpy(packet->reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PILE_STATUS, (const char *)packet, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE CHARGE_PILE_STATUS UNPACKING


/**
 * @brief Get field als from charge_pile_status message
 *
 * @return  环境光传感器
 */
static inline uint32_t mavlink_msg_charge_pile_status_get_als(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field led from charge_pile_status message
 *
 * @return  补光灯状态
 */
static inline uint8_t mavlink_msg_charge_pile_status_get_led(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  14);
}

/**
 * @brief Get field charge_pin from charge_pile_status message
 *
 * @return  充电引脚状态
 */
static inline uint8_t mavlink_msg_charge_pile_status_get_charge_pin(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  15);
}

/**
 * @brief Get field cmin_adc from charge_pile_status message
 *
 * @return  负极极片ADC值
 */
static inline uint32_t mavlink_msg_charge_pile_status_get_cmin_adc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field cplus_adc from charge_pile_status message
 *
 * @return  正极极片ADC值
 */
static inline uint32_t mavlink_msg_charge_pile_status_get_cplus_adc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Get field cmin_status from charge_pile_status message
 *
 * @return  负极极片接触状态
 */
static inline uint8_t mavlink_msg_charge_pile_status_get_cmin_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  16);
}

/**
 * @brief Get field cplus_status from charge_pile_status message
 *
 * @return  正极极片接触状态
 */
static inline uint8_t mavlink_msg_charge_pile_status_get_cplus_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  17);
}

/**
 * @brief Get field tag_id from charge_pile_status message
 *
 * @return  二维码tag id
 */
static inline uint16_t mavlink_msg_charge_pile_status_get_tag_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint16_t(msg,  12);
}

/**
 * @brief Get field reserver from charge_pile_status message
 *
 * @return  预留
 */
static inline uint16_t mavlink_msg_charge_pile_status_get_reserver(const mavlink_message_t* msg, uint8_t *reserver)
{
    return _MAV_RETURN_uint8_t_array(msg, reserver, 8,  18);
}

/**
 * @brief Decode a charge_pile_status message into a struct
 *
 * @param msg The message to decode
 * @param charge_pile_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_charge_pile_status_decode(const mavlink_message_t* msg, mavlink_charge_pile_status_t* charge_pile_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    charge_pile_status->als = mavlink_msg_charge_pile_status_get_als(msg);
    charge_pile_status->cmin_adc = mavlink_msg_charge_pile_status_get_cmin_adc(msg);
    charge_pile_status->cplus_adc = mavlink_msg_charge_pile_status_get_cplus_adc(msg);
    charge_pile_status->tag_id = mavlink_msg_charge_pile_status_get_tag_id(msg);
    charge_pile_status->led = mavlink_msg_charge_pile_status_get_led(msg);
    charge_pile_status->charge_pin = mavlink_msg_charge_pile_status_get_charge_pin(msg);
    charge_pile_status->cmin_status = mavlink_msg_charge_pile_status_get_cmin_status(msg);
    charge_pile_status->cplus_status = mavlink_msg_charge_pile_status_get_cplus_status(msg);
    mavlink_msg_charge_pile_status_get_reserver(msg, charge_pile_status->reserver);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN? msg->len : MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN;
        memset(charge_pile_status, 0, MAVLINK_MSG_ID_CHARGE_PILE_STATUS_LEN);
    memcpy(charge_pile_status, _MAV_PAYLOAD(msg), len);
#endif
}
