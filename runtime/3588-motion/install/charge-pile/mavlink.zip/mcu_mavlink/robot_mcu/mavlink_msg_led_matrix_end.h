#pragma once
// MESSAGE LED_MATRIX_END PACKING

#define MAVLINK_MSG_ID_LED_MATRIX_END 111


typedef struct __mavlink_led_matrix_end_t {
 uint32_t crc; /*<  数据CRC*/
} mavlink_led_matrix_end_t;

#define MAVLINK_MSG_ID_LED_MATRIX_END_LEN 4
#define MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN 4
#define MAVLINK_MSG_ID_111_LEN 4
#define MAVLINK_MSG_ID_111_MIN_LEN 4

#define MAVLINK_MSG_ID_LED_MATRIX_END_CRC 55
#define MAVLINK_MSG_ID_111_CRC 55



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_LED_MATRIX_END { \
    111, \
    "LED_MATRIX_END", \
    1, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_led_matrix_end_t, crc) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_LED_MATRIX_END { \
    "LED_MATRIX_END", \
    1, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_led_matrix_end_t, crc) }, \
         } \
}
#endif

/**
 * @brief Pack a led_matrix_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  数据CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_end_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#else
    mavlink_led_matrix_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_END;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
}

/**
 * @brief Pack a led_matrix_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  数据CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_end_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#else
    mavlink_led_matrix_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_END;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#endif
}

/**
 * @brief Pack a led_matrix_end message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param crc  数据CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_end_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#else
    mavlink_led_matrix_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_END;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
}

/**
 * @brief Encode a led_matrix_end struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_end_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_led_matrix_end_t* led_matrix_end)
{
    return mavlink_msg_led_matrix_end_pack(system_id, component_id, msg, led_matrix_end->crc);
}

/**
 * @brief Encode a led_matrix_end struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_end_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_led_matrix_end_t* led_matrix_end)
{
    return mavlink_msg_led_matrix_end_pack_chan(system_id, component_id, chan, msg, led_matrix_end->crc);
}

/**
 * @brief Encode a led_matrix_end struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_end_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_led_matrix_end_t* led_matrix_end)
{
    return mavlink_msg_led_matrix_end_pack_status(system_id, component_id, _status, msg,  led_matrix_end->crc);
}

/**
 * @brief Send a led_matrix_end message
 * @param chan MAVLink channel to send the message
 *
 * @param crc  数据CRC
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_led_matrix_end_send(mavlink_channel_t chan, uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_END, buf, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#else
    mavlink_led_matrix_end_t packet;
    packet.crc = crc;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_END, (const char *)&packet, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#endif
}

/**
 * @brief Send a led_matrix_end message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_led_matrix_end_send_struct(mavlink_channel_t chan, const mavlink_led_matrix_end_t* led_matrix_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_led_matrix_end_send(chan, led_matrix_end->crc);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_END, (const char *)led_matrix_end, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#endif
}

#if MAVLINK_MSG_ID_LED_MATRIX_END_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_led_matrix_end_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, crc);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_END, buf, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#else
    mavlink_led_matrix_end_t *packet = (mavlink_led_matrix_end_t *)msgbuf;
    packet->crc = crc;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_END, (const char *)packet, MAVLINK_MSG_ID_LED_MATRIX_END_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_LEN, MAVLINK_MSG_ID_LED_MATRIX_END_CRC);
#endif
}
#endif

#endif

// MESSAGE LED_MATRIX_END UNPACKING


/**
 * @brief Get field crc from led_matrix_end message
 *
 * @return  数据CRC
 */
static inline uint32_t mavlink_msg_led_matrix_end_get_crc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a led_matrix_end message into a struct
 *
 * @param msg The message to decode
 * @param led_matrix_end C-struct to decode the message contents into
 */
static inline void mavlink_msg_led_matrix_end_decode(const mavlink_message_t* msg, mavlink_led_matrix_end_t* led_matrix_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    led_matrix_end->crc = mavlink_msg_led_matrix_end_get_crc(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_LED_MATRIX_END_LEN? msg->len : MAVLINK_MSG_ID_LED_MATRIX_END_LEN;
        memset(led_matrix_end, 0, MAVLINK_MSG_ID_LED_MATRIX_END_LEN);
    memcpy(led_matrix_end, _MAV_PAYLOAD(msg), len);
#endif
}
