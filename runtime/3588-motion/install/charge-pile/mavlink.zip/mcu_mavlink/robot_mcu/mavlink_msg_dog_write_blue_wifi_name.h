#pragma once
// MESSAGE DOG_WRITE_BLUE_WIFI_NAME PACKING

#define MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME 190


typedef struct __mavlink_dog_write_blue_wifi_name_t {
 uint8_t cmd_type; /*<  命令类型*/
 uint8_t cmd_data_len; /*<  命令数据有效长度*/
 uint8_t frame_info[25]; /*<  帧数据 最大长度25,不足,后面补0*/
} mavlink_dog_write_blue_wifi_name_t;

#define MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN 27
#define MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN 27
#define MAVLINK_MSG_ID_190_LEN 27
#define MAVLINK_MSG_ID_190_MIN_LEN 27

#define MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC 162
#define MAVLINK_MSG_ID_190_CRC 162

#define MAVLINK_MSG_DOG_WRITE_BLUE_WIFI_NAME_FIELD_FRAME_INFO_LEN 25

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_DOG_WRITE_BLUE_WIFI_NAME { \
    190, \
    "DOG_WRITE_BLUE_WIFI_NAME", \
    3, \
    {  { "cmd_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_dog_write_blue_wifi_name_t, cmd_type) }, \
         { "cmd_data_len", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_dog_write_blue_wifi_name_t, cmd_data_len) }, \
         { "frame_info", NULL, MAVLINK_TYPE_UINT8_T, 25, 2, offsetof(mavlink_dog_write_blue_wifi_name_t, frame_info) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_DOG_WRITE_BLUE_WIFI_NAME { \
    "DOG_WRITE_BLUE_WIFI_NAME", \
    3, \
    {  { "cmd_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_dog_write_blue_wifi_name_t, cmd_type) }, \
         { "cmd_data_len", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_dog_write_blue_wifi_name_t, cmd_data_len) }, \
         { "frame_info", NULL, MAVLINK_TYPE_UINT8_T, 25, 2, offsetof(mavlink_dog_write_blue_wifi_name_t, frame_info) }, \
         } \
}
#endif

/**
 * @brief Pack a dog_write_blue_wifi_name message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param cmd_type  命令类型
 * @param cmd_data_len  命令数据有效长度
 * @param frame_info  帧数据 最大长度25,不足,后面补0
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t cmd_type, uint8_t cmd_data_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN];
    _mav_put_uint8_t(buf, 0, cmd_type);
    _mav_put_uint8_t(buf, 1, cmd_data_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#else
    mavlink_dog_write_blue_wifi_name_t packet;
    packet.cmd_type = cmd_type;
    packet.cmd_data_len = cmd_data_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
}

/**
 * @brief Pack a dog_write_blue_wifi_name message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param cmd_type  命令类型
 * @param cmd_data_len  命令数据有效长度
 * @param frame_info  帧数据 最大长度25,不足,后面补0
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t cmd_type, uint8_t cmd_data_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN];
    _mav_put_uint8_t(buf, 0, cmd_type);
    _mav_put_uint8_t(buf, 1, cmd_data_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#else
    mavlink_dog_write_blue_wifi_name_t packet;
    packet.cmd_type = cmd_type;
    packet.cmd_data_len = cmd_data_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#endif
}

/**
 * @brief Pack a dog_write_blue_wifi_name message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param cmd_type  命令类型
 * @param cmd_data_len  命令数据有效长度
 * @param frame_info  帧数据 最大长度25,不足,后面补0
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t cmd_type,uint8_t cmd_data_len,const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN];
    _mav_put_uint8_t(buf, 0, cmd_type);
    _mav_put_uint8_t(buf, 1, cmd_data_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#else
    mavlink_dog_write_blue_wifi_name_t packet;
    packet.cmd_type = cmd_type;
    packet.cmd_data_len = cmd_data_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*25);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
}

/**
 * @brief Encode a dog_write_blue_wifi_name struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_blue_wifi_name C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_dog_write_blue_wifi_name_t* dog_write_blue_wifi_name)
{
    return mavlink_msg_dog_write_blue_wifi_name_pack(system_id, component_id, msg, dog_write_blue_wifi_name->cmd_type, dog_write_blue_wifi_name->cmd_data_len, dog_write_blue_wifi_name->frame_info);
}

/**
 * @brief Encode a dog_write_blue_wifi_name struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_blue_wifi_name C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_dog_write_blue_wifi_name_t* dog_write_blue_wifi_name)
{
    return mavlink_msg_dog_write_blue_wifi_name_pack_chan(system_id, component_id, chan, msg, dog_write_blue_wifi_name->cmd_type, dog_write_blue_wifi_name->cmd_data_len, dog_write_blue_wifi_name->frame_info);
}

/**
 * @brief Encode a dog_write_blue_wifi_name struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param dog_write_blue_wifi_name C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_dog_write_blue_wifi_name_t* dog_write_blue_wifi_name)
{
    return mavlink_msg_dog_write_blue_wifi_name_pack_status(system_id, component_id, _status, msg,  dog_write_blue_wifi_name->cmd_type, dog_write_blue_wifi_name->cmd_data_len, dog_write_blue_wifi_name->frame_info);
}

/**
 * @brief Send a dog_write_blue_wifi_name message
 * @param chan MAVLink channel to send the message
 *
 * @param cmd_type  命令类型
 * @param cmd_data_len  命令数据有效长度
 * @param frame_info  帧数据 最大长度25,不足,后面补0
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_dog_write_blue_wifi_name_send(mavlink_channel_t chan, uint8_t cmd_type, uint8_t cmd_data_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN];
    _mav_put_uint8_t(buf, 0, cmd_type);
    _mav_put_uint8_t(buf, 1, cmd_data_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 25);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME, buf, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#else
    mavlink_dog_write_blue_wifi_name_t packet;
    packet.cmd_type = cmd_type;
    packet.cmd_data_len = cmd_data_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*25);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME, (const char *)&packet, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#endif
}

/**
 * @brief Send a dog_write_blue_wifi_name message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_dog_write_blue_wifi_name_send_struct(mavlink_channel_t chan, const mavlink_dog_write_blue_wifi_name_t* dog_write_blue_wifi_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_dog_write_blue_wifi_name_send(chan, dog_write_blue_wifi_name->cmd_type, dog_write_blue_wifi_name->cmd_data_len, dog_write_blue_wifi_name->frame_info);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME, (const char *)dog_write_blue_wifi_name, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#endif
}

#if MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_dog_write_blue_wifi_name_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t cmd_type, uint8_t cmd_data_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, cmd_type);
    _mav_put_uint8_t(buf, 1, cmd_data_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 25);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME, buf, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#else
    mavlink_dog_write_blue_wifi_name_t *packet = (mavlink_dog_write_blue_wifi_name_t *)msgbuf;
    packet->cmd_type = cmd_type;
    packet->cmd_data_len = cmd_data_len;
    mav_array_memcpy(packet->frame_info, frame_info, sizeof(uint8_t)*25);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME, (const char *)packet, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_MIN_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_CRC);
#endif
}
#endif

#endif

// MESSAGE DOG_WRITE_BLUE_WIFI_NAME UNPACKING


/**
 * @brief Get field cmd_type from dog_write_blue_wifi_name message
 *
 * @return  命令类型
 */
static inline uint8_t mavlink_msg_dog_write_blue_wifi_name_get_cmd_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field cmd_data_len from dog_write_blue_wifi_name message
 *
 * @return  命令数据有效长度
 */
static inline uint8_t mavlink_msg_dog_write_blue_wifi_name_get_cmd_data_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field frame_info from dog_write_blue_wifi_name message
 *
 * @return  帧数据 最大长度25,不足,后面补0
 */
static inline uint16_t mavlink_msg_dog_write_blue_wifi_name_get_frame_info(const mavlink_message_t* msg, uint8_t *frame_info)
{
    return _MAV_RETURN_uint8_t_array(msg, frame_info, 25,  2);
}

/**
 * @brief Decode a dog_write_blue_wifi_name message into a struct
 *
 * @param msg The message to decode
 * @param dog_write_blue_wifi_name C-struct to decode the message contents into
 */
static inline void mavlink_msg_dog_write_blue_wifi_name_decode(const mavlink_message_t* msg, mavlink_dog_write_blue_wifi_name_t* dog_write_blue_wifi_name)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    dog_write_blue_wifi_name->cmd_type = mavlink_msg_dog_write_blue_wifi_name_get_cmd_type(msg);
    dog_write_blue_wifi_name->cmd_data_len = mavlink_msg_dog_write_blue_wifi_name_get_cmd_data_len(msg);
    mavlink_msg_dog_write_blue_wifi_name_get_frame_info(msg, dog_write_blue_wifi_name->frame_info);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN? msg->len : MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN;
        memset(dog_write_blue_wifi_name, 0, MAVLINK_MSG_ID_DOG_WRITE_BLUE_WIFI_NAME_LEN);
    memcpy(dog_write_blue_wifi_name, _MAV_PAYLOAD(msg), len);
#endif
}
