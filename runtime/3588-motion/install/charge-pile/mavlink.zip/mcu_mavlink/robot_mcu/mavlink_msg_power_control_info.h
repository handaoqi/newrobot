#pragma once
// MESSAGE POWER_CONTROL_INFO PACKING

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO 3


typedef struct __mavlink_power_control_info_t {
 uint8_t power_id; /*<  电源域ID*/
 uint8_t boot_cmd; /*<  命令*/
 uint8_t delay; /*<  重启延迟时间*/
} mavlink_power_control_info_t;

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN 3
#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN 3
#define MAVLINK_MSG_ID_3_LEN 3
#define MAVLINK_MSG_ID_3_MIN_LEN 3

#define MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC 41
#define MAVLINK_MSG_ID_3_CRC 41



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_POWER_CONTROL_INFO { \
    3, \
    "POWER_CONTROL_INFO", \
    3, \
    {  { "power_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_power_control_info_t, power_id) }, \
         { "boot_cmd", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_power_control_info_t, boot_cmd) }, \
         { "delay", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_power_control_info_t, delay) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_POWER_CONTROL_INFO { \
    "POWER_CONTROL_INFO", \
    3, \
    {  { "power_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_power_control_info_t, power_id) }, \
         { "boot_cmd", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_power_control_info_t, boot_cmd) }, \
         { "delay", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_power_control_info_t, delay) }, \
         } \
}
#endif

/**
 * @brief Pack a power_control_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param power_id  电源域ID
 * @param boot_cmd  命令
 * @param delay  重启延迟时间
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t power_id, uint8_t boot_cmd, uint8_t delay)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, boot_cmd);
    _mav_put_uint8_t(buf, 2, delay);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#else
    mavlink_power_control_info_t packet;
    packet.power_id = power_id;
    packet.boot_cmd = boot_cmd;
    packet.delay = delay;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
}

/**
 * @brief Pack a power_control_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param power_id  电源域ID
 * @param boot_cmd  命令
 * @param delay  重启延迟时间
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t power_id, uint8_t boot_cmd, uint8_t delay)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, boot_cmd);
    _mav_put_uint8_t(buf, 2, delay);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#else
    mavlink_power_control_info_t packet;
    packet.power_id = power_id;
    packet.boot_cmd = boot_cmd;
    packet.delay = delay;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#endif
}

/**
 * @brief Pack a power_control_info message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param power_id  电源域ID
 * @param boot_cmd  命令
 * @param delay  重启延迟时间
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_power_control_info_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t power_id,uint8_t boot_cmd,uint8_t delay)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, boot_cmd);
    _mav_put_uint8_t(buf, 2, delay);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#else
    mavlink_power_control_info_t packet;
    packet.power_id = power_id;
    packet.boot_cmd = boot_cmd;
    packet.delay = delay;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_POWER_CONTROL_INFO;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
}

/**
 * @brief Encode a power_control_info struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_power_control_info_t* power_control_info)
{
    return mavlink_msg_power_control_info_pack(system_id, component_id, msg, power_control_info->power_id, power_control_info->boot_cmd, power_control_info->delay);
}

/**
 * @brief Encode a power_control_info struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_power_control_info_t* power_control_info)
{
    return mavlink_msg_power_control_info_pack_chan(system_id, component_id, chan, msg, power_control_info->power_id, power_control_info->boot_cmd, power_control_info->delay);
}

/**
 * @brief Encode a power_control_info struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param power_control_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_power_control_info_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_power_control_info_t* power_control_info)
{
    return mavlink_msg_power_control_info_pack_status(system_id, component_id, _status, msg,  power_control_info->power_id, power_control_info->boot_cmd, power_control_info->delay);
}

/**
 * @brief Send a power_control_info message
 * @param chan MAVLink channel to send the message
 *
 * @param power_id  电源域ID
 * @param boot_cmd  命令
 * @param delay  重启延迟时间
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_power_control_info_send(mavlink_channel_t chan, uint8_t power_id, uint8_t boot_cmd, uint8_t delay)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN];
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, boot_cmd);
    _mav_put_uint8_t(buf, 2, delay);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO, buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#else
    mavlink_power_control_info_t packet;
    packet.power_id = power_id;
    packet.boot_cmd = boot_cmd;
    packet.delay = delay;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO, (const char *)&packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#endif
}

/**
 * @brief Send a power_control_info message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_power_control_info_send_struct(mavlink_channel_t chan, const mavlink_power_control_info_t* power_control_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_power_control_info_send(chan, power_control_info->power_id, power_control_info->boot_cmd, power_control_info->delay);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO, (const char *)power_control_info, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#endif
}

#if MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_power_control_info_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t power_id, uint8_t boot_cmd, uint8_t delay)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, power_id);
    _mav_put_uint8_t(buf, 1, boot_cmd);
    _mav_put_uint8_t(buf, 2, delay);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO, buf, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#else
    mavlink_power_control_info_t *packet = (mavlink_power_control_info_t *)msgbuf;
    packet->power_id = power_id;
    packet->boot_cmd = boot_cmd;
    packet->delay = delay;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_POWER_CONTROL_INFO, (const char *)packet, MAVLINK_MSG_ID_POWER_CONTROL_INFO_MIN_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN, MAVLINK_MSG_ID_POWER_CONTROL_INFO_CRC);
#endif
}
#endif

#endif

// MESSAGE POWER_CONTROL_INFO UNPACKING


/**
 * @brief Get field power_id from power_control_info message
 *
 * @return  电源域ID
 */
static inline uint8_t mavlink_msg_power_control_info_get_power_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field boot_cmd from power_control_info message
 *
 * @return  命令
 */
static inline uint8_t mavlink_msg_power_control_info_get_boot_cmd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field delay from power_control_info message
 *
 * @return  重启延迟时间
 */
static inline uint8_t mavlink_msg_power_control_info_get_delay(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Decode a power_control_info message into a struct
 *
 * @param msg The message to decode
 * @param power_control_info C-struct to decode the message contents into
 */
static inline void mavlink_msg_power_control_info_decode(const mavlink_message_t* msg, mavlink_power_control_info_t* power_control_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    power_control_info->power_id = mavlink_msg_power_control_info_get_power_id(msg);
    power_control_info->boot_cmd = mavlink_msg_power_control_info_get_boot_cmd(msg);
    power_control_info->delay = mavlink_msg_power_control_info_get_delay(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN? msg->len : MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN;
        memset(power_control_info, 0, MAVLINK_MSG_ID_POWER_CONTROL_INFO_LEN);
    memcpy(power_control_info, _MAV_PAYLOAD(msg), len);
#endif
}
