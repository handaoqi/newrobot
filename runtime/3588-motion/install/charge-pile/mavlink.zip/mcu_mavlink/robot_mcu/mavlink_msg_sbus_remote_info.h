#pragma once
// MESSAGE SBUS_REMOTE_INFO PACKING

#define MAVLINK_MSG_ID_SBUS_REMOTE_INFO 1


typedef struct __mavlink_sbus_remote_info_t {
 uint16_t data[16]; /*<  RX*/
 uint8_t flags; /*<  RX*/
} mavlink_sbus_remote_info_t;

#define MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN 33
#define MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN 33
#define MAVLINK_MSG_ID_1_LEN 33
#define MAVLINK_MSG_ID_1_MIN_LEN 33

#define MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC 245
#define MAVLINK_MSG_ID_1_CRC 245

#define MAVLINK_MSG_SBUS_REMOTE_INFO_FIELD_DATA_LEN 16

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_SBUS_REMOTE_INFO { \
    1, \
    "SBUS_REMOTE_INFO", \
    2, \
    {  { "data", NULL, MAVLINK_TYPE_UINT16_T, 16, 0, offsetof(mavlink_sbus_remote_info_t, data) }, \
         { "flags", NULL, MAVLINK_TYPE_UINT8_T, 0, 32, offsetof(mavlink_sbus_remote_info_t, flags) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_SBUS_REMOTE_INFO { \
    "SBUS_REMOTE_INFO", \
    2, \
    {  { "data", NULL, MAVLINK_TYPE_UINT16_T, 16, 0, offsetof(mavlink_sbus_remote_info_t, data) }, \
         { "flags", NULL, MAVLINK_TYPE_UINT8_T, 0, 32, offsetof(mavlink_sbus_remote_info_t, flags) }, \
         } \
}
#endif

/**
 * @brief Pack a sbus_remote_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param data  RX
 * @param flags  RX
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_sbus_remote_info_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const uint16_t *data, uint8_t flags)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN];
    _mav_put_uint8_t(buf, 32, flags);
    _mav_put_uint16_t_array(buf, 0, data, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#else
    mavlink_sbus_remote_info_t packet;
    packet.flags = flags;
    mav_array_memcpy(packet.data, data, sizeof(uint16_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_SBUS_REMOTE_INFO;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
}

/**
 * @brief Pack a sbus_remote_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param data  RX
 * @param flags  RX
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_sbus_remote_info_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               const uint16_t *data, uint8_t flags)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN];
    _mav_put_uint8_t(buf, 32, flags);
    _mav_put_uint16_t_array(buf, 0, data, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#else
    mavlink_sbus_remote_info_t packet;
    packet.flags = flags;
    mav_array_memcpy(packet.data, data, sizeof(uint16_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_SBUS_REMOTE_INFO;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#endif
}

/**
 * @brief Pack a sbus_remote_info message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param data  RX
 * @param flags  RX
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_sbus_remote_info_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const uint16_t *data,uint8_t flags)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN];
    _mav_put_uint8_t(buf, 32, flags);
    _mav_put_uint16_t_array(buf, 0, data, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#else
    mavlink_sbus_remote_info_t packet;
    packet.flags = flags;
    mav_array_memcpy(packet.data, data, sizeof(uint16_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_SBUS_REMOTE_INFO;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
}

/**
 * @brief Encode a sbus_remote_info struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param sbus_remote_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_sbus_remote_info_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_sbus_remote_info_t* sbus_remote_info)
{
    return mavlink_msg_sbus_remote_info_pack(system_id, component_id, msg, sbus_remote_info->data, sbus_remote_info->flags);
}

/**
 * @brief Encode a sbus_remote_info struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param sbus_remote_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_sbus_remote_info_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_sbus_remote_info_t* sbus_remote_info)
{
    return mavlink_msg_sbus_remote_info_pack_chan(system_id, component_id, chan, msg, sbus_remote_info->data, sbus_remote_info->flags);
}

/**
 * @brief Encode a sbus_remote_info struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param sbus_remote_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_sbus_remote_info_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_sbus_remote_info_t* sbus_remote_info)
{
    return mavlink_msg_sbus_remote_info_pack_status(system_id, component_id, _status, msg,  sbus_remote_info->data, sbus_remote_info->flags);
}

/**
 * @brief Send a sbus_remote_info message
 * @param chan MAVLink channel to send the message
 *
 * @param data  RX
 * @param flags  RX
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_sbus_remote_info_send(mavlink_channel_t chan, const uint16_t *data, uint8_t flags)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN];
    _mav_put_uint8_t(buf, 32, flags);
    _mav_put_uint16_t_array(buf, 0, data, 16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO, buf, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#else
    mavlink_sbus_remote_info_t packet;
    packet.flags = flags;
    mav_array_memcpy(packet.data, data, sizeof(uint16_t)*16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO, (const char *)&packet, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#endif
}

/**
 * @brief Send a sbus_remote_info message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_sbus_remote_info_send_struct(mavlink_channel_t chan, const mavlink_sbus_remote_info_t* sbus_remote_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_sbus_remote_info_send(chan, sbus_remote_info->data, sbus_remote_info->flags);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO, (const char *)sbus_remote_info, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#endif
}

#if MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_sbus_remote_info_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const uint16_t *data, uint8_t flags)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 32, flags);
    _mav_put_uint16_t_array(buf, 0, data, 16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO, buf, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#else
    mavlink_sbus_remote_info_t *packet = (mavlink_sbus_remote_info_t *)msgbuf;
    packet->flags = flags;
    mav_array_memcpy(packet->data, data, sizeof(uint16_t)*16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_SBUS_REMOTE_INFO, (const char *)packet, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_MIN_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_CRC);
#endif
}
#endif

#endif

// MESSAGE SBUS_REMOTE_INFO UNPACKING


/**
 * @brief Get field data from sbus_remote_info message
 *
 * @return  RX
 */
static inline uint16_t mavlink_msg_sbus_remote_info_get_data(const mavlink_message_t* msg, uint16_t *data)
{
    return _MAV_RETURN_uint16_t_array(msg, data, 16,  0);
}

/**
 * @brief Get field flags from sbus_remote_info message
 *
 * @return  RX
 */
static inline uint8_t mavlink_msg_sbus_remote_info_get_flags(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  32);
}

/**
 * @brief Decode a sbus_remote_info message into a struct
 *
 * @param msg The message to decode
 * @param sbus_remote_info C-struct to decode the message contents into
 */
static inline void mavlink_msg_sbus_remote_info_decode(const mavlink_message_t* msg, mavlink_sbus_remote_info_t* sbus_remote_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_sbus_remote_info_get_data(msg, sbus_remote_info->data);
    sbus_remote_info->flags = mavlink_msg_sbus_remote_info_get_flags(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN? msg->len : MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN;
        memset(sbus_remote_info, 0, MAVLINK_MSG_ID_SBUS_REMOTE_INFO_LEN);
    memcpy(sbus_remote_info, _MAV_PAYLOAD(msg), len);
#endif
}
