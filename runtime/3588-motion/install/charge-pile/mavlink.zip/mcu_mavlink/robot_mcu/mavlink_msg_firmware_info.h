#pragma once
// MESSAGE FIRMWARE_INFO PACKING

#define MAVLINK_MSG_ID_FIRMWARE_INFO 6


typedef struct __mavlink_firmware_info_t {
 uint32_t crc; /*<  固件CRC*/
 uint32_t len; /*<  固件大小*/
 uint32_t version; /*<  固件版本*/
 uint32_t date; /*<  编译时间*/
 uint32_t commit_id; /*<  commit_id*/
 uint32_t ab; /*<  bootloader使用，APP不使用*/
} mavlink_firmware_info_t;

#define MAVLINK_MSG_ID_FIRMWARE_INFO_LEN 24
#define MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN 24
#define MAVLINK_MSG_ID_6_LEN 24
#define MAVLINK_MSG_ID_6_MIN_LEN 24

#define MAVLINK_MSG_ID_FIRMWARE_INFO_CRC 199
#define MAVLINK_MSG_ID_6_CRC 199



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FIRMWARE_INFO { \
    6, \
    "FIRMWARE_INFO", \
    6, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_firmware_info_t, crc) }, \
         { "len", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_firmware_info_t, len) }, \
         { "version", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_firmware_info_t, version) }, \
         { "date", NULL, MAVLINK_TYPE_UINT32_T, 0, 12, offsetof(mavlink_firmware_info_t, date) }, \
         { "commit_id", NULL, MAVLINK_TYPE_UINT32_T, 0, 16, offsetof(mavlink_firmware_info_t, commit_id) }, \
         { "ab", NULL, MAVLINK_TYPE_UINT32_T, 0, 20, offsetof(mavlink_firmware_info_t, ab) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FIRMWARE_INFO { \
    "FIRMWARE_INFO", \
    6, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_firmware_info_t, crc) }, \
         { "len", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_firmware_info_t, len) }, \
         { "version", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_firmware_info_t, version) }, \
         { "date", NULL, MAVLINK_TYPE_UINT32_T, 0, 12, offsetof(mavlink_firmware_info_t, date) }, \
         { "commit_id", NULL, MAVLINK_TYPE_UINT32_T, 0, 16, offsetof(mavlink_firmware_info_t, commit_id) }, \
         { "ab", NULL, MAVLINK_TYPE_UINT32_T, 0, 20, offsetof(mavlink_firmware_info_t, ab) }, \
         } \
}
#endif

/**
 * @brief Pack a firmware_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  固件CRC
 * @param len  固件大小
 * @param version  固件版本
 * @param date  编译时间
 * @param commit_id  commit_id
 * @param ab  bootloader使用，APP不使用
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t crc, uint32_t len, uint32_t version, uint32_t date, uint32_t commit_id, uint32_t ab)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_LEN];
    _mav_put_uint32_t(buf, 0, crc);
    _mav_put_uint32_t(buf, 4, len);
    _mav_put_uint32_t(buf, 8, version);
    _mav_put_uint32_t(buf, 12, date);
    _mav_put_uint32_t(buf, 16, commit_id);
    _mav_put_uint32_t(buf, 20, ab);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#else
    mavlink_firmware_info_t packet;
    packet.crc = crc;
    packet.len = len;
    packet.version = version;
    packet.date = date;
    packet.commit_id = commit_id;
    packet.ab = ab;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
}

/**
 * @brief Pack a firmware_info message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  固件CRC
 * @param len  固件大小
 * @param version  固件版本
 * @param date  编译时间
 * @param commit_id  commit_id
 * @param ab  bootloader使用，APP不使用
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t crc, uint32_t len, uint32_t version, uint32_t date, uint32_t commit_id, uint32_t ab)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_LEN];
    _mav_put_uint32_t(buf, 0, crc);
    _mav_put_uint32_t(buf, 4, len);
    _mav_put_uint32_t(buf, 8, version);
    _mav_put_uint32_t(buf, 12, date);
    _mav_put_uint32_t(buf, 16, commit_id);
    _mav_put_uint32_t(buf, 20, ab);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#else
    mavlink_firmware_info_t packet;
    packet.crc = crc;
    packet.len = len;
    packet.version = version;
    packet.date = date;
    packet.commit_id = commit_id;
    packet.ab = ab;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#endif
}

/**
 * @brief Pack a firmware_info message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param crc  固件CRC
 * @param len  固件大小
 * @param version  固件版本
 * @param date  编译时间
 * @param commit_id  commit_id
 * @param ab  bootloader使用，APP不使用
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t crc,uint32_t len,uint32_t version,uint32_t date,uint32_t commit_id,uint32_t ab)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_LEN];
    _mav_put_uint32_t(buf, 0, crc);
    _mav_put_uint32_t(buf, 4, len);
    _mav_put_uint32_t(buf, 8, version);
    _mav_put_uint32_t(buf, 12, date);
    _mav_put_uint32_t(buf, 16, commit_id);
    _mav_put_uint32_t(buf, 20, ab);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#else
    mavlink_firmware_info_t packet;
    packet.crc = crc;
    packet.len = len;
    packet.version = version;
    packet.date = date;
    packet.commit_id = commit_id;
    packet.ab = ab;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
}

/**
 * @brief Encode a firmware_info struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_firmware_info_t* firmware_info)
{
    return mavlink_msg_firmware_info_pack(system_id, component_id, msg, firmware_info->crc, firmware_info->len, firmware_info->version, firmware_info->date, firmware_info->commit_id, firmware_info->ab);
}

/**
 * @brief Encode a firmware_info struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_firmware_info_t* firmware_info)
{
    return mavlink_msg_firmware_info_pack_chan(system_id, component_id, chan, msg, firmware_info->crc, firmware_info->len, firmware_info->version, firmware_info->date, firmware_info->commit_id, firmware_info->ab);
}

/**
 * @brief Encode a firmware_info struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_firmware_info_t* firmware_info)
{
    return mavlink_msg_firmware_info_pack_status(system_id, component_id, _status, msg,  firmware_info->crc, firmware_info->len, firmware_info->version, firmware_info->date, firmware_info->commit_id, firmware_info->ab);
}

/**
 * @brief Send a firmware_info message
 * @param chan MAVLink channel to send the message
 *
 * @param crc  固件CRC
 * @param len  固件大小
 * @param version  固件版本
 * @param date  编译时间
 * @param commit_id  commit_id
 * @param ab  bootloader使用，APP不使用
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_firmware_info_send(mavlink_channel_t chan, uint32_t crc, uint32_t len, uint32_t version, uint32_t date, uint32_t commit_id, uint32_t ab)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_LEN];
    _mav_put_uint32_t(buf, 0, crc);
    _mav_put_uint32_t(buf, 4, len);
    _mav_put_uint32_t(buf, 8, version);
    _mav_put_uint32_t(buf, 12, date);
    _mav_put_uint32_t(buf, 16, commit_id);
    _mav_put_uint32_t(buf, 20, ab);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO, buf, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#else
    mavlink_firmware_info_t packet;
    packet.crc = crc;
    packet.len = len;
    packet.version = version;
    packet.date = date;
    packet.commit_id = commit_id;
    packet.ab = ab;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO, (const char *)&packet, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#endif
}

/**
 * @brief Send a firmware_info message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_firmware_info_send_struct(mavlink_channel_t chan, const mavlink_firmware_info_t* firmware_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_firmware_info_send(chan, firmware_info->crc, firmware_info->len, firmware_info->version, firmware_info->date, firmware_info->commit_id, firmware_info->ab);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO, (const char *)firmware_info, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#endif
}

#if MAVLINK_MSG_ID_FIRMWARE_INFO_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_firmware_info_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t crc, uint32_t len, uint32_t version, uint32_t date, uint32_t commit_id, uint32_t ab)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, crc);
    _mav_put_uint32_t(buf, 4, len);
    _mav_put_uint32_t(buf, 8, version);
    _mav_put_uint32_t(buf, 12, date);
    _mav_put_uint32_t(buf, 16, commit_id);
    _mav_put_uint32_t(buf, 20, ab);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO, buf, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#else
    mavlink_firmware_info_t *packet = (mavlink_firmware_info_t *)msgbuf;
    packet->crc = crc;
    packet->len = len;
    packet->version = version;
    packet->date = date;
    packet->commit_id = commit_id;
    packet->ab = ab;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO, (const char *)packet, MAVLINK_MSG_ID_FIRMWARE_INFO_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_CRC);
#endif
}
#endif

#endif

// MESSAGE FIRMWARE_INFO UNPACKING


/**
 * @brief Get field crc from firmware_info message
 *
 * @return  固件CRC
 */
static inline uint32_t mavlink_msg_firmware_info_get_crc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field len from firmware_info message
 *
 * @return  固件大小
 */
static inline uint32_t mavlink_msg_firmware_info_get_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field version from firmware_info message
 *
 * @return  固件版本
 */
static inline uint32_t mavlink_msg_firmware_info_get_version(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Get field date from firmware_info message
 *
 * @return  编译时间
 */
static inline uint32_t mavlink_msg_firmware_info_get_date(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  12);
}

/**
 * @brief Get field commit_id from firmware_info message
 *
 * @return  commit_id
 */
static inline uint32_t mavlink_msg_firmware_info_get_commit_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  16);
}

/**
 * @brief Get field ab from firmware_info message
 *
 * @return  bootloader使用，APP不使用
 */
static inline uint32_t mavlink_msg_firmware_info_get_ab(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  20);
}

/**
 * @brief Decode a firmware_info message into a struct
 *
 * @param msg The message to decode
 * @param firmware_info C-struct to decode the message contents into
 */
static inline void mavlink_msg_firmware_info_decode(const mavlink_message_t* msg, mavlink_firmware_info_t* firmware_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    firmware_info->crc = mavlink_msg_firmware_info_get_crc(msg);
    firmware_info->len = mavlink_msg_firmware_info_get_len(msg);
    firmware_info->version = mavlink_msg_firmware_info_get_version(msg);
    firmware_info->date = mavlink_msg_firmware_info_get_date(msg);
    firmware_info->commit_id = mavlink_msg_firmware_info_get_commit_id(msg);
    firmware_info->ab = mavlink_msg_firmware_info_get_ab(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FIRMWARE_INFO_LEN? msg->len : MAVLINK_MSG_ID_FIRMWARE_INFO_LEN;
        memset(firmware_info, 0, MAVLINK_MSG_ID_FIRMWARE_INFO_LEN);
    memcpy(firmware_info, _MAV_PAYLOAD(msg), len);
#endif
}
