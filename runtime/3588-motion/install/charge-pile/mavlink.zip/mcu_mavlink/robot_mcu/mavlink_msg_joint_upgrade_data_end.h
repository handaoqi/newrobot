#pragma once
// MESSAGE JOINT_UPGRADE_DATA_END PACKING

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END 102


typedef struct __mavlink_joint_upgrade_data_end_t {
 uint32_t node_mask; /*<  节点掩码*/
 uint32_t leg_mask; /*<  腿掩码*/
 uint32_t reserver; /*<  保留字*/
} mavlink_joint_upgrade_data_end_t;

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN 12
#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN 12
#define MAVLINK_MSG_ID_102_LEN 12
#define MAVLINK_MSG_ID_102_MIN_LEN 12

#define MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC 64
#define MAVLINK_MSG_ID_102_CRC 64



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_JOINT_UPGRADE_DATA_END { \
    102, \
    "JOINT_UPGRADE_DATA_END", \
    3, \
    {  { "node_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_upgrade_data_end_t, node_mask) }, \
         { "leg_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_upgrade_data_end_t, leg_mask) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_joint_upgrade_data_end_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_JOINT_UPGRADE_DATA_END { \
    "JOINT_UPGRADE_DATA_END", \
    3, \
    {  { "node_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_upgrade_data_end_t, node_mask) }, \
         { "leg_mask", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_upgrade_data_end_t, leg_mask) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_joint_upgrade_data_end_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a joint_upgrade_data_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t node_mask, uint32_t leg_mask, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN];
    _mav_put_uint32_t(buf, 0, node_mask);
    _mav_put_uint32_t(buf, 4, leg_mask);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#else
    mavlink_joint_upgrade_data_end_t packet;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
}

/**
 * @brief Pack a joint_upgrade_data_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t node_mask, uint32_t leg_mask, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN];
    _mav_put_uint32_t(buf, 0, node_mask);
    _mav_put_uint32_t(buf, 4, leg_mask);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#else
    mavlink_joint_upgrade_data_end_t packet;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#endif
}

/**
 * @brief Pack a joint_upgrade_data_end message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t node_mask,uint32_t leg_mask,uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN];
    _mav_put_uint32_t(buf, 0, node_mask);
    _mav_put_uint32_t(buf, 4, leg_mask);
    _mav_put_uint32_t(buf, 8, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#else
    mavlink_joint_upgrade_data_end_t packet;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
}

/**
 * @brief Encode a joint_upgrade_data_end struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_joint_upgrade_data_end_t* joint_upgrade_data_end)
{
    return mavlink_msg_joint_upgrade_data_end_pack(system_id, component_id, msg, joint_upgrade_data_end->node_mask, joint_upgrade_data_end->leg_mask, joint_upgrade_data_end->reserver);
}

/**
 * @brief Encode a joint_upgrade_data_end struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_joint_upgrade_data_end_t* joint_upgrade_data_end)
{
    return mavlink_msg_joint_upgrade_data_end_pack_chan(system_id, component_id, chan, msg, joint_upgrade_data_end->node_mask, joint_upgrade_data_end->leg_mask, joint_upgrade_data_end->reserver);
}

/**
 * @brief Encode a joint_upgrade_data_end struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param joint_upgrade_data_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_upgrade_data_end_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_joint_upgrade_data_end_t* joint_upgrade_data_end)
{
    return mavlink_msg_joint_upgrade_data_end_pack_status(system_id, component_id, _status, msg,  joint_upgrade_data_end->node_mask, joint_upgrade_data_end->leg_mask, joint_upgrade_data_end->reserver);
}

/**
 * @brief Send a joint_upgrade_data_end message
 * @param chan MAVLink channel to send the message
 *
 * @param node_mask  节点掩码
 * @param leg_mask  腿掩码
 * @param reserver  保留字
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_joint_upgrade_data_end_send(mavlink_channel_t chan, uint32_t node_mask, uint32_t leg_mask, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN];
    _mav_put_uint32_t(buf, 0, node_mask);
    _mav_put_uint32_t(buf, 4, leg_mask);
    _mav_put_uint32_t(buf, 8, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END, buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#else
    mavlink_joint_upgrade_data_end_t packet;
    packet.node_mask = node_mask;
    packet.leg_mask = leg_mask;
    packet.reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END, (const char *)&packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#endif
}

/**
 * @brief Send a joint_upgrade_data_end message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_joint_upgrade_data_end_send_struct(mavlink_channel_t chan, const mavlink_joint_upgrade_data_end_t* joint_upgrade_data_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_joint_upgrade_data_end_send(chan, joint_upgrade_data_end->node_mask, joint_upgrade_data_end->leg_mask, joint_upgrade_data_end->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END, (const char *)joint_upgrade_data_end, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#endif
}

#if MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_joint_upgrade_data_end_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t node_mask, uint32_t leg_mask, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, node_mask);
    _mav_put_uint32_t(buf, 4, leg_mask);
    _mav_put_uint32_t(buf, 8, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END, buf, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#else
    mavlink_joint_upgrade_data_end_t *packet = (mavlink_joint_upgrade_data_end_t *)msgbuf;
    packet->node_mask = node_mask;
    packet->leg_mask = leg_mask;
    packet->reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END, (const char *)packet, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_MIN_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_CRC);
#endif
}
#endif

#endif

// MESSAGE JOINT_UPGRADE_DATA_END UNPACKING


/**
 * @brief Get field node_mask from joint_upgrade_data_end message
 *
 * @return  节点掩码
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_end_get_node_mask(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field leg_mask from joint_upgrade_data_end message
 *
 * @return  腿掩码
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_end_get_leg_mask(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Get field reserver from joint_upgrade_data_end message
 *
 * @return  保留字
 */
static inline uint32_t mavlink_msg_joint_upgrade_data_end_get_reserver(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  8);
}

/**
 * @brief Decode a joint_upgrade_data_end message into a struct
 *
 * @param msg The message to decode
 * @param joint_upgrade_data_end C-struct to decode the message contents into
 */
static inline void mavlink_msg_joint_upgrade_data_end_decode(const mavlink_message_t* msg, mavlink_joint_upgrade_data_end_t* joint_upgrade_data_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    joint_upgrade_data_end->node_mask = mavlink_msg_joint_upgrade_data_end_get_node_mask(msg);
    joint_upgrade_data_end->leg_mask = mavlink_msg_joint_upgrade_data_end_get_leg_mask(msg);
    joint_upgrade_data_end->reserver = mavlink_msg_joint_upgrade_data_end_get_reserver(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN? msg->len : MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN;
        memset(joint_upgrade_data_end, 0, MAVLINK_MSG_ID_JOINT_UPGRADE_DATA_END_LEN);
    memcpy(joint_upgrade_data_end, _MAV_PAYLOAD(msg), len);
#endif
}
