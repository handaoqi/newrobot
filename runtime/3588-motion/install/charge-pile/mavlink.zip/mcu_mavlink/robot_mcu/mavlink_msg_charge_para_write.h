#pragma once
// MESSAGE CHARGE_PARA_WRITE PACKING

#define MAVLINK_MSG_ID_CHARGE_PARA_WRITE 133


typedef struct __mavlink_charge_para_write_t {
 uint8_t cmd; /*<  1,tag_id;*/
 uint8_t reserver[8]; /*<  预留*/
} mavlink_charge_para_write_t;

#define MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN 9
#define MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN 9
#define MAVLINK_MSG_ID_133_LEN 9
#define MAVLINK_MSG_ID_133_MIN_LEN 9

#define MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC 79
#define MAVLINK_MSG_ID_133_CRC 79

#define MAVLINK_MSG_CHARGE_PARA_WRITE_FIELD_RESERVER_LEN 8

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_CHARGE_PARA_WRITE { \
    133, \
    "CHARGE_PARA_WRITE", \
    2, \
    {  { "cmd", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_charge_para_write_t, cmd) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 1, offsetof(mavlink_charge_para_write_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_CHARGE_PARA_WRITE { \
    "CHARGE_PARA_WRITE", \
    2, \
    {  { "cmd", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_charge_para_write_t, cmd) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 1, offsetof(mavlink_charge_para_write_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a charge_para_write message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param cmd  1,tag_id;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_para_write_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t cmd, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN];
    _mav_put_uint8_t(buf, 0, cmd);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#else
    mavlink_charge_para_write_t packet;
    packet.cmd = cmd;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PARA_WRITE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
}

/**
 * @brief Pack a charge_para_write message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param cmd  1,tag_id;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_para_write_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t cmd, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN];
    _mav_put_uint8_t(buf, 0, cmd);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#else
    mavlink_charge_para_write_t packet;
    packet.cmd = cmd;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PARA_WRITE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#endif
}

/**
 * @brief Pack a charge_para_write message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param cmd  1,tag_id;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_para_write_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t cmd,const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN];
    _mav_put_uint8_t(buf, 0, cmd);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#else
    mavlink_charge_para_write_t packet;
    packet.cmd = cmd;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_PARA_WRITE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
}

/**
 * @brief Encode a charge_para_write struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param charge_para_write C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_para_write_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_charge_para_write_t* charge_para_write)
{
    return mavlink_msg_charge_para_write_pack(system_id, component_id, msg, charge_para_write->cmd, charge_para_write->reserver);
}

/**
 * @brief Encode a charge_para_write struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param charge_para_write C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_para_write_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_charge_para_write_t* charge_para_write)
{
    return mavlink_msg_charge_para_write_pack_chan(system_id, component_id, chan, msg, charge_para_write->cmd, charge_para_write->reserver);
}

/**
 * @brief Encode a charge_para_write struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param charge_para_write C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_para_write_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_charge_para_write_t* charge_para_write)
{
    return mavlink_msg_charge_para_write_pack_status(system_id, component_id, _status, msg,  charge_para_write->cmd, charge_para_write->reserver);
}

/**
 * @brief Send a charge_para_write message
 * @param chan MAVLink channel to send the message
 *
 * @param cmd  1,tag_id;
 * @param reserver  预留
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_charge_para_write_send(mavlink_channel_t chan, uint8_t cmd, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN];
    _mav_put_uint8_t(buf, 0, cmd);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE, buf, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#else
    mavlink_charge_para_write_t packet;
    packet.cmd = cmd;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE, (const char *)&packet, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#endif
}

/**
 * @brief Send a charge_para_write message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_charge_para_write_send_struct(mavlink_channel_t chan, const mavlink_charge_para_write_t* charge_para_write)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_charge_para_write_send(chan, charge_para_write->cmd, charge_para_write->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE, (const char *)charge_para_write, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#endif
}

#if MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_charge_para_write_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t cmd, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, cmd);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE, buf, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#else
    mavlink_charge_para_write_t *packet = (mavlink_charge_para_write_t *)msgbuf;
    packet->cmd = cmd;
    mav_array_memcpy(packet->reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_PARA_WRITE, (const char *)packet, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_MIN_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_CRC);
#endif
}
#endif

#endif

// MESSAGE CHARGE_PARA_WRITE UNPACKING


/**
 * @brief Get field cmd from charge_para_write message
 *
 * @return  1,tag_id;
 */
static inline uint8_t mavlink_msg_charge_para_write_get_cmd(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field reserver from charge_para_write message
 *
 * @return  预留
 */
static inline uint16_t mavlink_msg_charge_para_write_get_reserver(const mavlink_message_t* msg, uint8_t *reserver)
{
    return _MAV_RETURN_uint8_t_array(msg, reserver, 8,  1);
}

/**
 * @brief Decode a charge_para_write message into a struct
 *
 * @param msg The message to decode
 * @param charge_para_write C-struct to decode the message contents into
 */
static inline void mavlink_msg_charge_para_write_decode(const mavlink_message_t* msg, mavlink_charge_para_write_t* charge_para_write)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    charge_para_write->cmd = mavlink_msg_charge_para_write_get_cmd(msg);
    mavlink_msg_charge_para_write_get_reserver(msg, charge_para_write->reserver);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN? msg->len : MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN;
        memset(charge_para_write, 0, MAVLINK_MSG_ID_CHARGE_PARA_WRITE_LEN);
    memcpy(charge_para_write, _MAV_PAYLOAD(msg), len);
#endif
}
