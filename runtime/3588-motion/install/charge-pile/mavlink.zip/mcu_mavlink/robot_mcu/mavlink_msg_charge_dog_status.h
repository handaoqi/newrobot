#pragma once
// MESSAGE CHARGE_DOG_STATUS PACKING

#define MAVLINK_MSG_ID_CHARGE_DOG_STATUS 132


typedef struct __mavlink_charge_dog_status_t {
 uint8_t status; /*<  0,狗返航中; 1,狗趴下; 2,狗状态未知;*/
 uint8_t reserver[8]; /*<  预留*/
} mavlink_charge_dog_status_t;

#define MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN 9
#define MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN 9
#define MAVLINK_MSG_ID_132_LEN 9
#define MAVLINK_MSG_ID_132_MIN_LEN 9

#define MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC 209
#define MAVLINK_MSG_ID_132_CRC 209

#define MAVLINK_MSG_CHARGE_DOG_STATUS_FIELD_RESERVER_LEN 8

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_CHARGE_DOG_STATUS { \
    132, \
    "CHARGE_DOG_STATUS", \
    2, \
    {  { "status", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_charge_dog_status_t, status) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 1, offsetof(mavlink_charge_dog_status_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_CHARGE_DOG_STATUS { \
    "CHARGE_DOG_STATUS", \
    2, \
    {  { "status", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_charge_dog_status_t, status) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT8_T, 8, 1, offsetof(mavlink_charge_dog_status_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a charge_dog_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param status  0,狗返航中; 1,狗趴下; 2,狗状态未知;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_dog_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t status, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN];
    _mav_put_uint8_t(buf, 0, status);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#else
    mavlink_charge_dog_status_t packet;
    packet.status = status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_DOG_STATUS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
}

/**
 * @brief Pack a charge_dog_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param status  0,狗返航中; 1,狗趴下; 2,狗状态未知;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_dog_status_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t status, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN];
    _mav_put_uint8_t(buf, 0, status);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#else
    mavlink_charge_dog_status_t packet;
    packet.status = status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_DOG_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#endif
}

/**
 * @brief Pack a charge_dog_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param status  0,狗返航中; 1,狗趴下; 2,狗状态未知;
 * @param reserver  预留
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_charge_dog_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t status,const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN];
    _mav_put_uint8_t(buf, 0, status);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#else
    mavlink_charge_dog_status_t packet;
    packet.status = status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_CHARGE_DOG_STATUS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
}

/**
 * @brief Encode a charge_dog_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param charge_dog_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_dog_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_charge_dog_status_t* charge_dog_status)
{
    return mavlink_msg_charge_dog_status_pack(system_id, component_id, msg, charge_dog_status->status, charge_dog_status->reserver);
}

/**
 * @brief Encode a charge_dog_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param charge_dog_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_dog_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_charge_dog_status_t* charge_dog_status)
{
    return mavlink_msg_charge_dog_status_pack_chan(system_id, component_id, chan, msg, charge_dog_status->status, charge_dog_status->reserver);
}

/**
 * @brief Encode a charge_dog_status struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param charge_dog_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_charge_dog_status_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_charge_dog_status_t* charge_dog_status)
{
    return mavlink_msg_charge_dog_status_pack_status(system_id, component_id, _status, msg,  charge_dog_status->status, charge_dog_status->reserver);
}

/**
 * @brief Send a charge_dog_status message
 * @param chan MAVLink channel to send the message
 *
 * @param status  0,狗返航中; 1,狗趴下; 2,狗状态未知;
 * @param reserver  预留
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_charge_dog_status_send(mavlink_channel_t chan, uint8_t status, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN];
    _mav_put_uint8_t(buf, 0, status);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS, buf, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#else
    mavlink_charge_dog_status_t packet;
    packet.status = status;
    mav_array_memcpy(packet.reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS, (const char *)&packet, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#endif
}

/**
 * @brief Send a charge_dog_status message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_charge_dog_status_send_struct(mavlink_channel_t chan, const mavlink_charge_dog_status_t* charge_dog_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_charge_dog_status_send(chan, charge_dog_status->status, charge_dog_status->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS, (const char *)charge_dog_status, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#endif
}

#if MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_charge_dog_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t status, const uint8_t *reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, status);
    _mav_put_uint8_t_array(buf, 1, reserver, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS, buf, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#else
    mavlink_charge_dog_status_t *packet = (mavlink_charge_dog_status_t *)msgbuf;
    packet->status = status;
    mav_array_memcpy(packet->reserver, reserver, sizeof(uint8_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_CHARGE_DOG_STATUS, (const char *)packet, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_MIN_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_CRC);
#endif
}
#endif

#endif

// MESSAGE CHARGE_DOG_STATUS UNPACKING


/**
 * @brief Get field status from charge_dog_status message
 *
 * @return  0,狗返航中; 1,狗趴下; 2,狗状态未知;
 */
static inline uint8_t mavlink_msg_charge_dog_status_get_status(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field reserver from charge_dog_status message
 *
 * @return  预留
 */
static inline uint16_t mavlink_msg_charge_dog_status_get_reserver(const mavlink_message_t* msg, uint8_t *reserver)
{
    return _MAV_RETURN_uint8_t_array(msg, reserver, 8,  1);
}

/**
 * @brief Decode a charge_dog_status message into a struct
 *
 * @param msg The message to decode
 * @param charge_dog_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_charge_dog_status_decode(const mavlink_message_t* msg, mavlink_charge_dog_status_t* charge_dog_status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    charge_dog_status->status = mavlink_msg_charge_dog_status_get_status(msg);
    mavlink_msg_charge_dog_status_get_reserver(msg, charge_dog_status->reserver);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN? msg->len : MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN;
        memset(charge_dog_status, 0, MAVLINK_MSG_ID_CHARGE_DOG_STATUS_LEN);
    memcpy(charge_dog_status, _MAV_PAYLOAD(msg), len);
#endif
}
