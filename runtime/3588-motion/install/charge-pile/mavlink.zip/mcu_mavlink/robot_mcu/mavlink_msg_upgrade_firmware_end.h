#pragma once
// MESSAGE UPGRADE_FIRMWARE_END PACKING

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END 11


typedef struct __mavlink_upgrade_firmware_end_t {
 uint32_t crc; /*<  固件CRC*/
} mavlink_upgrade_firmware_end_t;

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN 4
#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN 4
#define MAVLINK_MSG_ID_11_LEN 4
#define MAVLINK_MSG_ID_11_MIN_LEN 4

#define MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC 223
#define MAVLINK_MSG_ID_11_CRC 223



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_END { \
    11, \
    "UPGRADE_FIRMWARE_END", \
    1, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_end_t, crc) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_UPGRADE_FIRMWARE_END { \
    "UPGRADE_FIRMWARE_END", \
    1, \
    {  { "crc", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_upgrade_firmware_end_t, crc) }, \
         } \
}
#endif

/**
 * @brief Pack a upgrade_firmware_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  固件CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#else
    mavlink_upgrade_firmware_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
}

/**
 * @brief Pack a upgrade_firmware_end message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param crc  固件CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#else
    mavlink_upgrade_firmware_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#endif
}

/**
 * @brief Pack a upgrade_firmware_end message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param crc  固件CRC
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#else
    mavlink_upgrade_firmware_end_t packet;
    packet.crc = crc;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
}

/**
 * @brief Encode a upgrade_firmware_end struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_upgrade_firmware_end_t* upgrade_firmware_end)
{
    return mavlink_msg_upgrade_firmware_end_pack(system_id, component_id, msg, upgrade_firmware_end->crc);
}

/**
 * @brief Encode a upgrade_firmware_end struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_upgrade_firmware_end_t* upgrade_firmware_end)
{
    return mavlink_msg_upgrade_firmware_end_pack_chan(system_id, component_id, chan, msg, upgrade_firmware_end->crc);
}

/**
 * @brief Encode a upgrade_firmware_end struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param upgrade_firmware_end C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_upgrade_firmware_end_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_upgrade_firmware_end_t* upgrade_firmware_end)
{
    return mavlink_msg_upgrade_firmware_end_pack_status(system_id, component_id, _status, msg,  upgrade_firmware_end->crc);
}

/**
 * @brief Send a upgrade_firmware_end message
 * @param chan MAVLink channel to send the message
 *
 * @param crc  固件CRC
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_upgrade_firmware_end_send(mavlink_channel_t chan, uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN];
    _mav_put_uint32_t(buf, 0, crc);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#else
    mavlink_upgrade_firmware_end_t packet;
    packet.crc = crc;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END, (const char *)&packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#endif
}

/**
 * @brief Send a upgrade_firmware_end message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_upgrade_firmware_end_send_struct(mavlink_channel_t chan, const mavlink_upgrade_firmware_end_t* upgrade_firmware_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_upgrade_firmware_end_send(chan, upgrade_firmware_end->crc);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END, (const char *)upgrade_firmware_end, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#endif
}

#if MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_upgrade_firmware_end_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, crc);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END, buf, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#else
    mavlink_upgrade_firmware_end_t *packet = (mavlink_upgrade_firmware_end_t *)msgbuf;
    packet->crc = crc;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END, (const char *)packet, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_MIN_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_CRC);
#endif
}
#endif

#endif

// MESSAGE UPGRADE_FIRMWARE_END UNPACKING


/**
 * @brief Get field crc from upgrade_firmware_end message
 *
 * @return  固件CRC
 */
static inline uint32_t mavlink_msg_upgrade_firmware_end_get_crc(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a upgrade_firmware_end message into a struct
 *
 * @param msg The message to decode
 * @param upgrade_firmware_end C-struct to decode the message contents into
 */
static inline void mavlink_msg_upgrade_firmware_end_decode(const mavlink_message_t* msg, mavlink_upgrade_firmware_end_t* upgrade_firmware_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    upgrade_firmware_end->crc = mavlink_msg_upgrade_firmware_end_get_crc(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN? msg->len : MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN;
        memset(upgrade_firmware_end, 0, MAVLINK_MSG_ID_UPGRADE_FIRMWARE_END_LEN);
    memcpy(upgrade_firmware_end, _MAV_PAYLOAD(msg), len);
#endif
}
