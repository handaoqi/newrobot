#pragma once
// MESSAGE JOINT_GET_SN_CALLBACK PACKING

#define MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK 104


typedef struct __mavlink_joint_get_sn_callback_t {
 uint32_t leg_idx; /*<  leg_idx*/
 uint16_t leg_joint1_sn[2]; /*<  SN1*/
 uint16_t leg_joint2_sn[2]; /*<  SN2*/
 uint16_t leg_joint3_sn[2]; /*<  SN3*/
 uint16_t leg_joint4_sn[2]; /*<  SN4*/
} mavlink_joint_get_sn_callback_t;

#define MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN 20
#define MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN 20
#define MAVLINK_MSG_ID_104_LEN 20
#define MAVLINK_MSG_ID_104_MIN_LEN 20

#define MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC 213
#define MAVLINK_MSG_ID_104_CRC 213

#define MAVLINK_MSG_JOINT_GET_SN_CALLBACK_FIELD_LEG_JOINT1_SN_LEN 2
#define MAVLINK_MSG_JOINT_GET_SN_CALLBACK_FIELD_LEG_JOINT2_SN_LEN 2
#define MAVLINK_MSG_JOINT_GET_SN_CALLBACK_FIELD_LEG_JOINT3_SN_LEN 2
#define MAVLINK_MSG_JOINT_GET_SN_CALLBACK_FIELD_LEG_JOINT4_SN_LEN 2

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_JOINT_GET_SN_CALLBACK { \
    104, \
    "JOINT_GET_SN_CALLBACK", \
    5, \
    {  { "leg_idx", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_get_sn_callback_t, leg_idx) }, \
         { "leg_joint1_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 4, offsetof(mavlink_joint_get_sn_callback_t, leg_joint1_sn) }, \
         { "leg_joint2_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 8, offsetof(mavlink_joint_get_sn_callback_t, leg_joint2_sn) }, \
         { "leg_joint3_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 12, offsetof(mavlink_joint_get_sn_callback_t, leg_joint3_sn) }, \
         { "leg_joint4_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 16, offsetof(mavlink_joint_get_sn_callback_t, leg_joint4_sn) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_JOINT_GET_SN_CALLBACK { \
    "JOINT_GET_SN_CALLBACK", \
    5, \
    {  { "leg_idx", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_get_sn_callback_t, leg_idx) }, \
         { "leg_joint1_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 4, offsetof(mavlink_joint_get_sn_callback_t, leg_joint1_sn) }, \
         { "leg_joint2_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 8, offsetof(mavlink_joint_get_sn_callback_t, leg_joint2_sn) }, \
         { "leg_joint3_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 12, offsetof(mavlink_joint_get_sn_callback_t, leg_joint3_sn) }, \
         { "leg_joint4_sn", NULL, MAVLINK_TYPE_UINT16_T, 2, 16, offsetof(mavlink_joint_get_sn_callback_t, leg_joint4_sn) }, \
         } \
}
#endif

/**
 * @brief Pack a joint_get_sn_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param leg_idx  leg_idx
 * @param leg_joint1_sn  SN1
 * @param leg_joint2_sn  SN2
 * @param leg_joint3_sn  SN3
 * @param leg_joint4_sn  SN4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t leg_idx, const uint16_t *leg_joint1_sn, const uint16_t *leg_joint2_sn, const uint16_t *leg_joint3_sn, const uint16_t *leg_joint4_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);
    _mav_put_uint16_t_array(buf, 4, leg_joint1_sn, 2);
    _mav_put_uint16_t_array(buf, 8, leg_joint2_sn, 2);
    _mav_put_uint16_t_array(buf, 12, leg_joint3_sn, 2);
    _mav_put_uint16_t_array(buf, 16, leg_joint4_sn, 2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#else
    mavlink_joint_get_sn_callback_t packet;
    packet.leg_idx = leg_idx;
    mav_array_memcpy(packet.leg_joint1_sn, leg_joint1_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint2_sn, leg_joint2_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint3_sn, leg_joint3_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint4_sn, leg_joint4_sn, sizeof(uint16_t)*2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
}

/**
 * @brief Pack a joint_get_sn_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param leg_idx  leg_idx
 * @param leg_joint1_sn  SN1
 * @param leg_joint2_sn  SN2
 * @param leg_joint3_sn  SN3
 * @param leg_joint4_sn  SN4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t leg_idx, const uint16_t *leg_joint1_sn, const uint16_t *leg_joint2_sn, const uint16_t *leg_joint3_sn, const uint16_t *leg_joint4_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);
    _mav_put_uint16_t_array(buf, 4, leg_joint1_sn, 2);
    _mav_put_uint16_t_array(buf, 8, leg_joint2_sn, 2);
    _mav_put_uint16_t_array(buf, 12, leg_joint3_sn, 2);
    _mav_put_uint16_t_array(buf, 16, leg_joint4_sn, 2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#else
    mavlink_joint_get_sn_callback_t packet;
    packet.leg_idx = leg_idx;
    mav_array_memcpy(packet.leg_joint1_sn, leg_joint1_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint2_sn, leg_joint2_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint3_sn, leg_joint3_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint4_sn, leg_joint4_sn, sizeof(uint16_t)*2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#endif
}

/**
 * @brief Pack a joint_get_sn_callback message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param leg_idx  leg_idx
 * @param leg_joint1_sn  SN1
 * @param leg_joint2_sn  SN2
 * @param leg_joint3_sn  SN3
 * @param leg_joint4_sn  SN4
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t leg_idx,const uint16_t *leg_joint1_sn,const uint16_t *leg_joint2_sn,const uint16_t *leg_joint3_sn,const uint16_t *leg_joint4_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);
    _mav_put_uint16_t_array(buf, 4, leg_joint1_sn, 2);
    _mav_put_uint16_t_array(buf, 8, leg_joint2_sn, 2);
    _mav_put_uint16_t_array(buf, 12, leg_joint3_sn, 2);
    _mav_put_uint16_t_array(buf, 16, leg_joint4_sn, 2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#else
    mavlink_joint_get_sn_callback_t packet;
    packet.leg_idx = leg_idx;
    mav_array_memcpy(packet.leg_joint1_sn, leg_joint1_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint2_sn, leg_joint2_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint3_sn, leg_joint3_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint4_sn, leg_joint4_sn, sizeof(uint16_t)*2);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
}

/**
 * @brief Encode a joint_get_sn_callback struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_joint_get_sn_callback_t* joint_get_sn_callback)
{
    return mavlink_msg_joint_get_sn_callback_pack(system_id, component_id, msg, joint_get_sn_callback->leg_idx, joint_get_sn_callback->leg_joint1_sn, joint_get_sn_callback->leg_joint2_sn, joint_get_sn_callback->leg_joint3_sn, joint_get_sn_callback->leg_joint4_sn);
}

/**
 * @brief Encode a joint_get_sn_callback struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_joint_get_sn_callback_t* joint_get_sn_callback)
{
    return mavlink_msg_joint_get_sn_callback_pack_chan(system_id, component_id, chan, msg, joint_get_sn_callback->leg_idx, joint_get_sn_callback->leg_joint1_sn, joint_get_sn_callback->leg_joint2_sn, joint_get_sn_callback->leg_joint3_sn, joint_get_sn_callback->leg_joint4_sn);
}

/**
 * @brief Encode a joint_get_sn_callback struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_joint_get_sn_callback_t* joint_get_sn_callback)
{
    return mavlink_msg_joint_get_sn_callback_pack_status(system_id, component_id, _status, msg,  joint_get_sn_callback->leg_idx, joint_get_sn_callback->leg_joint1_sn, joint_get_sn_callback->leg_joint2_sn, joint_get_sn_callback->leg_joint3_sn, joint_get_sn_callback->leg_joint4_sn);
}

/**
 * @brief Send a joint_get_sn_callback message
 * @param chan MAVLink channel to send the message
 *
 * @param leg_idx  leg_idx
 * @param leg_joint1_sn  SN1
 * @param leg_joint2_sn  SN2
 * @param leg_joint3_sn  SN3
 * @param leg_joint4_sn  SN4
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_joint_get_sn_callback_send(mavlink_channel_t chan, uint32_t leg_idx, const uint16_t *leg_joint1_sn, const uint16_t *leg_joint2_sn, const uint16_t *leg_joint3_sn, const uint16_t *leg_joint4_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);
    _mav_put_uint16_t_array(buf, 4, leg_joint1_sn, 2);
    _mav_put_uint16_t_array(buf, 8, leg_joint2_sn, 2);
    _mav_put_uint16_t_array(buf, 12, leg_joint3_sn, 2);
    _mav_put_uint16_t_array(buf, 16, leg_joint4_sn, 2);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK, buf, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#else
    mavlink_joint_get_sn_callback_t packet;
    packet.leg_idx = leg_idx;
    mav_array_memcpy(packet.leg_joint1_sn, leg_joint1_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint2_sn, leg_joint2_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint3_sn, leg_joint3_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet.leg_joint4_sn, leg_joint4_sn, sizeof(uint16_t)*2);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK, (const char *)&packet, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#endif
}

/**
 * @brief Send a joint_get_sn_callback message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_joint_get_sn_callback_send_struct(mavlink_channel_t chan, const mavlink_joint_get_sn_callback_t* joint_get_sn_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_joint_get_sn_callback_send(chan, joint_get_sn_callback->leg_idx, joint_get_sn_callback->leg_joint1_sn, joint_get_sn_callback->leg_joint2_sn, joint_get_sn_callback->leg_joint3_sn, joint_get_sn_callback->leg_joint4_sn);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK, (const char *)joint_get_sn_callback, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#endif
}

#if MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_joint_get_sn_callback_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t leg_idx, const uint16_t *leg_joint1_sn, const uint16_t *leg_joint2_sn, const uint16_t *leg_joint3_sn, const uint16_t *leg_joint4_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, leg_idx);
    _mav_put_uint16_t_array(buf, 4, leg_joint1_sn, 2);
    _mav_put_uint16_t_array(buf, 8, leg_joint2_sn, 2);
    _mav_put_uint16_t_array(buf, 12, leg_joint3_sn, 2);
    _mav_put_uint16_t_array(buf, 16, leg_joint4_sn, 2);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK, buf, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#else
    mavlink_joint_get_sn_callback_t *packet = (mavlink_joint_get_sn_callback_t *)msgbuf;
    packet->leg_idx = leg_idx;
    mav_array_memcpy(packet->leg_joint1_sn, leg_joint1_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet->leg_joint2_sn, leg_joint2_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet->leg_joint3_sn, leg_joint3_sn, sizeof(uint16_t)*2);
    mav_array_memcpy(packet->leg_joint4_sn, leg_joint4_sn, sizeof(uint16_t)*2);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK, (const char *)packet, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_CRC);
#endif
}
#endif

#endif

// MESSAGE JOINT_GET_SN_CALLBACK UNPACKING


/**
 * @brief Get field leg_idx from joint_get_sn_callback message
 *
 * @return  leg_idx
 */
static inline uint32_t mavlink_msg_joint_get_sn_callback_get_leg_idx(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field leg_joint1_sn from joint_get_sn_callback message
 *
 * @return  SN1
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_get_leg_joint1_sn(const mavlink_message_t* msg, uint16_t *leg_joint1_sn)
{
    return _MAV_RETURN_uint16_t_array(msg, leg_joint1_sn, 2,  4);
}

/**
 * @brief Get field leg_joint2_sn from joint_get_sn_callback message
 *
 * @return  SN2
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_get_leg_joint2_sn(const mavlink_message_t* msg, uint16_t *leg_joint2_sn)
{
    return _MAV_RETURN_uint16_t_array(msg, leg_joint2_sn, 2,  8);
}

/**
 * @brief Get field leg_joint3_sn from joint_get_sn_callback message
 *
 * @return  SN3
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_get_leg_joint3_sn(const mavlink_message_t* msg, uint16_t *leg_joint3_sn)
{
    return _MAV_RETURN_uint16_t_array(msg, leg_joint3_sn, 2,  12);
}

/**
 * @brief Get field leg_joint4_sn from joint_get_sn_callback message
 *
 * @return  SN4
 */
static inline uint16_t mavlink_msg_joint_get_sn_callback_get_leg_joint4_sn(const mavlink_message_t* msg, uint16_t *leg_joint4_sn)
{
    return _MAV_RETURN_uint16_t_array(msg, leg_joint4_sn, 2,  16);
}

/**
 * @brief Decode a joint_get_sn_callback message into a struct
 *
 * @param msg The message to decode
 * @param joint_get_sn_callback C-struct to decode the message contents into
 */
static inline void mavlink_msg_joint_get_sn_callback_decode(const mavlink_message_t* msg, mavlink_joint_get_sn_callback_t* joint_get_sn_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    joint_get_sn_callback->leg_idx = mavlink_msg_joint_get_sn_callback_get_leg_idx(msg);
    mavlink_msg_joint_get_sn_callback_get_leg_joint1_sn(msg, joint_get_sn_callback->leg_joint1_sn);
    mavlink_msg_joint_get_sn_callback_get_leg_joint2_sn(msg, joint_get_sn_callback->leg_joint2_sn);
    mavlink_msg_joint_get_sn_callback_get_leg_joint3_sn(msg, joint_get_sn_callback->leg_joint3_sn);
    mavlink_msg_joint_get_sn_callback_get_leg_joint4_sn(msg, joint_get_sn_callback->leg_joint4_sn);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN? msg->len : MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN;
        memset(joint_get_sn_callback, 0, MAVLINK_MSG_ID_JOINT_GET_SN_CALLBACK_LEN);
    memcpy(joint_get_sn_callback, _MAV_PAYLOAD(msg), len);
#endif
}
