#pragma once
// MESSAGE JOINT_TO_BOOTLOADER_CALLBACK PACKING

#define MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK 15


typedef struct __mavlink_joint_to_bootloader_callback_t {
 uint32_t result; /*<  结果*/
 uint32_t reserver; /*<  保留字*/
} mavlink_joint_to_bootloader_callback_t;

#define MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN 8
#define MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN 8
#define MAVLINK_MSG_ID_15_LEN 8
#define MAVLINK_MSG_ID_15_MIN_LEN 8

#define MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC 72
#define MAVLINK_MSG_ID_15_CRC 72



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_JOINT_TO_BOOTLOADER_CALLBACK { \
    15, \
    "JOINT_TO_BOOTLOADER_CALLBACK", \
    2, \
    {  { "result", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_to_bootloader_callback_t, result) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_to_bootloader_callback_t, reserver) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_JOINT_TO_BOOTLOADER_CALLBACK { \
    "JOINT_TO_BOOTLOADER_CALLBACK", \
    2, \
    {  { "result", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_to_bootloader_callback_t, result) }, \
         { "reserver", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_joint_to_bootloader_callback_t, reserver) }, \
         } \
}
#endif

/**
 * @brief Pack a joint_to_bootloader_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param result  结果
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t result, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, result);
    _mav_put_uint32_t(buf, 4, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#else
    mavlink_joint_to_bootloader_callback_t packet;
    packet.result = result;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
}

/**
 * @brief Pack a joint_to_bootloader_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param result  结果
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t result, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, result);
    _mav_put_uint32_t(buf, 4, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#else
    mavlink_joint_to_bootloader_callback_t packet;
    packet.result = result;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#endif
}

/**
 * @brief Pack a joint_to_bootloader_callback message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param result  结果
 * @param reserver  保留字
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t result,uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, result);
    _mav_put_uint32_t(buf, 4, reserver);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#else
    mavlink_joint_to_bootloader_callback_t packet;
    packet.result = result;
    packet.reserver = reserver;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
}

/**
 * @brief Encode a joint_to_bootloader_callback struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param joint_to_bootloader_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_joint_to_bootloader_callback_t* joint_to_bootloader_callback)
{
    return mavlink_msg_joint_to_bootloader_callback_pack(system_id, component_id, msg, joint_to_bootloader_callback->result, joint_to_bootloader_callback->reserver);
}

/**
 * @brief Encode a joint_to_bootloader_callback struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param joint_to_bootloader_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_joint_to_bootloader_callback_t* joint_to_bootloader_callback)
{
    return mavlink_msg_joint_to_bootloader_callback_pack_chan(system_id, component_id, chan, msg, joint_to_bootloader_callback->result, joint_to_bootloader_callback->reserver);
}

/**
 * @brief Encode a joint_to_bootloader_callback struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param joint_to_bootloader_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_to_bootloader_callback_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_joint_to_bootloader_callback_t* joint_to_bootloader_callback)
{
    return mavlink_msg_joint_to_bootloader_callback_pack_status(system_id, component_id, _status, msg,  joint_to_bootloader_callback->result, joint_to_bootloader_callback->reserver);
}

/**
 * @brief Send a joint_to_bootloader_callback message
 * @param chan MAVLink channel to send the message
 *
 * @param result  结果
 * @param reserver  保留字
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_joint_to_bootloader_callback_send(mavlink_channel_t chan, uint32_t result, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN];
    _mav_put_uint32_t(buf, 0, result);
    _mav_put_uint32_t(buf, 4, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK, buf, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#else
    mavlink_joint_to_bootloader_callback_t packet;
    packet.result = result;
    packet.reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK, (const char *)&packet, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#endif
}

/**
 * @brief Send a joint_to_bootloader_callback message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_joint_to_bootloader_callback_send_struct(mavlink_channel_t chan, const mavlink_joint_to_bootloader_callback_t* joint_to_bootloader_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_joint_to_bootloader_callback_send(chan, joint_to_bootloader_callback->result, joint_to_bootloader_callback->reserver);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK, (const char *)joint_to_bootloader_callback, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#endif
}

#if MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_joint_to_bootloader_callback_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t result, uint32_t reserver)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, result);
    _mav_put_uint32_t(buf, 4, reserver);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK, buf, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#else
    mavlink_joint_to_bootloader_callback_t *packet = (mavlink_joint_to_bootloader_callback_t *)msgbuf;
    packet->result = result;
    packet->reserver = reserver;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK, (const char *)packet, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_CRC);
#endif
}
#endif

#endif

// MESSAGE JOINT_TO_BOOTLOADER_CALLBACK UNPACKING


/**
 * @brief Get field result from joint_to_bootloader_callback message
 *
 * @return  结果
 */
static inline uint32_t mavlink_msg_joint_to_bootloader_callback_get_result(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Get field reserver from joint_to_bootloader_callback message
 *
 * @return  保留字
 */
static inline uint32_t mavlink_msg_joint_to_bootloader_callback_get_reserver(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  4);
}

/**
 * @brief Decode a joint_to_bootloader_callback message into a struct
 *
 * @param msg The message to decode
 * @param joint_to_bootloader_callback C-struct to decode the message contents into
 */
static inline void mavlink_msg_joint_to_bootloader_callback_decode(const mavlink_message_t* msg, mavlink_joint_to_bootloader_callback_t* joint_to_bootloader_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    joint_to_bootloader_callback->result = mavlink_msg_joint_to_bootloader_callback_get_result(msg);
    joint_to_bootloader_callback->reserver = mavlink_msg_joint_to_bootloader_callback_get_reserver(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN? msg->len : MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN;
        memset(joint_to_bootloader_callback, 0, MAVLINK_MSG_ID_JOINT_TO_BOOTLOADER_CALLBACK_LEN);
    memcpy(joint_to_bootloader_callback, _MAV_PAYLOAD(msg), len);
#endif
}
