#pragma once
// MESSAGE JOINT_GET_SN PACKING

#define MAVLINK_MSG_ID_JOINT_GET_SN 103


typedef struct __mavlink_joint_get_sn_t {
 uint32_t leg_idx; /*<  leg_idx*/
} mavlink_joint_get_sn_t;

#define MAVLINK_MSG_ID_JOINT_GET_SN_LEN 4
#define MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN 4
#define MAVLINK_MSG_ID_103_LEN 4
#define MAVLINK_MSG_ID_103_MIN_LEN 4

#define MAVLINK_MSG_ID_JOINT_GET_SN_CRC 17
#define MAVLINK_MSG_ID_103_CRC 17



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_JOINT_GET_SN { \
    103, \
    "JOINT_GET_SN", \
    1, \
    {  { "leg_idx", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_get_sn_t, leg_idx) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_JOINT_GET_SN { \
    "JOINT_GET_SN", \
    1, \
    {  { "leg_idx", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_joint_get_sn_t, leg_idx) }, \
         } \
}
#endif

/**
 * @brief Pack a joint_get_sn message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param leg_idx  leg_idx
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint32_t leg_idx)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#else
    mavlink_joint_get_sn_t packet;
    packet.leg_idx = leg_idx;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
}

/**
 * @brief Pack a joint_get_sn message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param leg_idx  leg_idx
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint32_t leg_idx)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#else
    mavlink_joint_get_sn_t packet;
    packet.leg_idx = leg_idx;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#endif
}

/**
 * @brief Pack a joint_get_sn message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param leg_idx  leg_idx
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_joint_get_sn_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint32_t leg_idx)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#else
    mavlink_joint_get_sn_t packet;
    packet.leg_idx = leg_idx;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_JOINT_GET_SN;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
}

/**
 * @brief Encode a joint_get_sn struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_joint_get_sn_t* joint_get_sn)
{
    return mavlink_msg_joint_get_sn_pack(system_id, component_id, msg, joint_get_sn->leg_idx);
}

/**
 * @brief Encode a joint_get_sn struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_joint_get_sn_t* joint_get_sn)
{
    return mavlink_msg_joint_get_sn_pack_chan(system_id, component_id, chan, msg, joint_get_sn->leg_idx);
}

/**
 * @brief Encode a joint_get_sn struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param joint_get_sn C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_joint_get_sn_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_joint_get_sn_t* joint_get_sn)
{
    return mavlink_msg_joint_get_sn_pack_status(system_id, component_id, _status, msg,  joint_get_sn->leg_idx);
}

/**
 * @brief Send a joint_get_sn message
 * @param chan MAVLink channel to send the message
 *
 * @param leg_idx  leg_idx
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_joint_get_sn_send(mavlink_channel_t chan, uint32_t leg_idx)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_JOINT_GET_SN_LEN];
    _mav_put_uint32_t(buf, 0, leg_idx);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN, buf, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#else
    mavlink_joint_get_sn_t packet;
    packet.leg_idx = leg_idx;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN, (const char *)&packet, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#endif
}

/**
 * @brief Send a joint_get_sn message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_joint_get_sn_send_struct(mavlink_channel_t chan, const mavlink_joint_get_sn_t* joint_get_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_joint_get_sn_send(chan, joint_get_sn->leg_idx);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN, (const char *)joint_get_sn, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#endif
}

#if MAVLINK_MSG_ID_JOINT_GET_SN_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_joint_get_sn_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t leg_idx)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint32_t(buf, 0, leg_idx);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN, buf, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#else
    mavlink_joint_get_sn_t *packet = (mavlink_joint_get_sn_t *)msgbuf;
    packet->leg_idx = leg_idx;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_JOINT_GET_SN, (const char *)packet, MAVLINK_MSG_ID_JOINT_GET_SN_MIN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_LEN, MAVLINK_MSG_ID_JOINT_GET_SN_CRC);
#endif
}
#endif

#endif

// MESSAGE JOINT_GET_SN UNPACKING


/**
 * @brief Get field leg_idx from joint_get_sn message
 *
 * @return  leg_idx
 */
static inline uint32_t mavlink_msg_joint_get_sn_get_leg_idx(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint32_t(msg,  0);
}

/**
 * @brief Decode a joint_get_sn message into a struct
 *
 * @param msg The message to decode
 * @param joint_get_sn C-struct to decode the message contents into
 */
static inline void mavlink_msg_joint_get_sn_decode(const mavlink_message_t* msg, mavlink_joint_get_sn_t* joint_get_sn)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    joint_get_sn->leg_idx = mavlink_msg_joint_get_sn_get_leg_idx(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_JOINT_GET_SN_LEN? msg->len : MAVLINK_MSG_ID_JOINT_GET_SN_LEN;
        memset(joint_get_sn, 0, MAVLINK_MSG_ID_JOINT_GET_SN_LEN);
    memcpy(joint_get_sn, _MAV_PAYLOAD(msg), len);
#endif
}
