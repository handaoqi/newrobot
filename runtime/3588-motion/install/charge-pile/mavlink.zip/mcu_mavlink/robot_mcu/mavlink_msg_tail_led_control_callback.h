#pragma once
// MESSAGE TAIL_LED_CONTROL_CALLBACK PACKING

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK 27


typedef struct __mavlink_tail_led_control_callback_t {
 uint8_t result; /*<  结果*/
} mavlink_tail_led_control_callback_t;

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN 1
#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN 1
#define MAVLINK_MSG_ID_27_LEN 1
#define MAVLINK_MSG_ID_27_MIN_LEN 1

#define MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC 79
#define MAVLINK_MSG_ID_27_CRC 79



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_TAIL_LED_CONTROL_CALLBACK { \
    27, \
    "TAIL_LED_CONTROL_CALLBACK", \
    1, \
    {  { "result", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_tail_led_control_callback_t, result) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_TAIL_LED_CONTROL_CALLBACK { \
    "TAIL_LED_CONTROL_CALLBACK", \
    1, \
    {  { "result", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_tail_led_control_callback_t, result) }, \
         } \
}
#endif

/**
 * @brief Pack a tail_led_control_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param result  结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#else
    mavlink_tail_led_control_callback_t packet;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
}

/**
 * @brief Pack a tail_led_control_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param result  结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#else
    mavlink_tail_led_control_callback_t packet;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#endif
}

/**
 * @brief Pack a tail_led_control_callback message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param result  结果
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, result);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#else
    mavlink_tail_led_control_callback_t packet;
    packet.result = result;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
}

/**
 * @brief Encode a tail_led_control_callback struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_tail_led_control_callback_t* tail_led_control_callback)
{
    return mavlink_msg_tail_led_control_callback_pack(system_id, component_id, msg, tail_led_control_callback->result);
}

/**
 * @brief Encode a tail_led_control_callback struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_tail_led_control_callback_t* tail_led_control_callback)
{
    return mavlink_msg_tail_led_control_callback_pack_chan(system_id, component_id, chan, msg, tail_led_control_callback->result);
}

/**
 * @brief Encode a tail_led_control_callback struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param tail_led_control_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_tail_led_control_callback_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_tail_led_control_callback_t* tail_led_control_callback)
{
    return mavlink_msg_tail_led_control_callback_pack_status(system_id, component_id, _status, msg,  tail_led_control_callback->result);
}

/**
 * @brief Send a tail_led_control_callback message
 * @param chan MAVLink channel to send the message
 *
 * @param result  结果
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_tail_led_control_callback_send(mavlink_channel_t chan, uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, result);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK, buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#else
    mavlink_tail_led_control_callback_t packet;
    packet.result = result;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK, (const char *)&packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#endif
}

/**
 * @brief Send a tail_led_control_callback message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_tail_led_control_callback_send_struct(mavlink_channel_t chan, const mavlink_tail_led_control_callback_t* tail_led_control_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_tail_led_control_callback_send(chan, tail_led_control_callback->result);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK, (const char *)tail_led_control_callback, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#endif
}

#if MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_tail_led_control_callback_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t result)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, result);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK, buf, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#else
    mavlink_tail_led_control_callback_t *packet = (mavlink_tail_led_control_callback_t *)msgbuf;
    packet->result = result;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK, (const char *)packet, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_CRC);
#endif
}
#endif

#endif

// MESSAGE TAIL_LED_CONTROL_CALLBACK UNPACKING


/**
 * @brief Get field result from tail_led_control_callback message
 *
 * @return  结果
 */
static inline uint8_t mavlink_msg_tail_led_control_callback_get_result(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Decode a tail_led_control_callback message into a struct
 *
 * @param msg The message to decode
 * @param tail_led_control_callback C-struct to decode the message contents into
 */
static inline void mavlink_msg_tail_led_control_callback_decode(const mavlink_message_t* msg, mavlink_tail_led_control_callback_t* tail_led_control_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    tail_led_control_callback->result = mavlink_msg_tail_led_control_callback_get_result(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN? msg->len : MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN;
        memset(tail_led_control_callback, 0, MAVLINK_MSG_ID_TAIL_LED_CONTROL_CALLBACK_LEN);
    memcpy(tail_led_control_callback, _MAV_PAYLOAD(msg), len);
#endif
}
