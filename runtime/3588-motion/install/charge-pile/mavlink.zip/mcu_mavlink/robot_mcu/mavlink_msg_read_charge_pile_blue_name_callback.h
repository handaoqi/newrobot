#pragma once
// MESSAGE READ_CHARGE_PILE_BLUE_NAME_CALLBACK PACKING

#define MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK 183


typedef struct __mavlink_read_charge_pile_blue_name_callback_t {
 uint8_t frame_type; /*<  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid*/
 uint8_t frame_len; /*<  帧数据有效长度*/
 uint8_t frame_info[16]; /*<  帧数据*/
} mavlink_read_charge_pile_blue_name_callback_t;

#define MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN 18
#define MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN 18
#define MAVLINK_MSG_ID_183_LEN 18
#define MAVLINK_MSG_ID_183_MIN_LEN 18

#define MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC 153
#define MAVLINK_MSG_ID_183_CRC 153

#define MAVLINK_MSG_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_FIELD_FRAME_INFO_LEN 16

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_READ_CHARGE_PILE_BLUE_NAME_CALLBACK { \
    183, \
    "READ_CHARGE_PILE_BLUE_NAME_CALLBACK", \
    3, \
    {  { "frame_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_type) }, \
         { "frame_len", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_len) }, \
         { "frame_info", NULL, MAVLINK_TYPE_UINT8_T, 16, 2, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_info) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_READ_CHARGE_PILE_BLUE_NAME_CALLBACK { \
    "READ_CHARGE_PILE_BLUE_NAME_CALLBACK", \
    3, \
    {  { "frame_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_type) }, \
         { "frame_len", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_len) }, \
         { "frame_info", NULL, MAVLINK_TYPE_UINT8_T, 16, 2, offsetof(mavlink_read_charge_pile_blue_name_callback_t, frame_info) }, \
         } \
}
#endif

/**
 * @brief Pack a read_charge_pile_blue_name_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param frame_type  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid
 * @param frame_len  帧数据有效长度
 * @param frame_info  帧数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t frame_type, uint8_t frame_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, frame_type);
    _mav_put_uint8_t(buf, 1, frame_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#else
    mavlink_read_charge_pile_blue_name_callback_t packet;
    packet.frame_type = frame_type;
    packet.frame_len = frame_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
}

/**
 * @brief Pack a read_charge_pile_blue_name_callback message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param frame_type  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid
 * @param frame_len  帧数据有效长度
 * @param frame_info  帧数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t frame_type, uint8_t frame_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, frame_type);
    _mav_put_uint8_t(buf, 1, frame_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#else
    mavlink_read_charge_pile_blue_name_callback_t packet;
    packet.frame_type = frame_type;
    packet.frame_len = frame_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#endif
}

/**
 * @brief Pack a read_charge_pile_blue_name_callback message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param frame_type  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid
 * @param frame_len  帧数据有效长度
 * @param frame_info  帧数据
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t frame_type,uint8_t frame_len,const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, frame_type);
    _mav_put_uint8_t(buf, 1, frame_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#else
    mavlink_read_charge_pile_blue_name_callback_t packet;
    packet.frame_type = frame_type;
    packet.frame_len = frame_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*16);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
}

/**
 * @brief Encode a read_charge_pile_blue_name_callback struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param read_charge_pile_blue_name_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_read_charge_pile_blue_name_callback_t* read_charge_pile_blue_name_callback)
{
    return mavlink_msg_read_charge_pile_blue_name_callback_pack(system_id, component_id, msg, read_charge_pile_blue_name_callback->frame_type, read_charge_pile_blue_name_callback->frame_len, read_charge_pile_blue_name_callback->frame_info);
}

/**
 * @brief Encode a read_charge_pile_blue_name_callback struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param read_charge_pile_blue_name_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_read_charge_pile_blue_name_callback_t* read_charge_pile_blue_name_callback)
{
    return mavlink_msg_read_charge_pile_blue_name_callback_pack_chan(system_id, component_id, chan, msg, read_charge_pile_blue_name_callback->frame_type, read_charge_pile_blue_name_callback->frame_len, read_charge_pile_blue_name_callback->frame_info);
}

/**
 * @brief Encode a read_charge_pile_blue_name_callback struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param read_charge_pile_blue_name_callback C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_read_charge_pile_blue_name_callback_t* read_charge_pile_blue_name_callback)
{
    return mavlink_msg_read_charge_pile_blue_name_callback_pack_status(system_id, component_id, _status, msg,  read_charge_pile_blue_name_callback->frame_type, read_charge_pile_blue_name_callback->frame_len, read_charge_pile_blue_name_callback->frame_info);
}

/**
 * @brief Send a read_charge_pile_blue_name_callback message
 * @param chan MAVLink channel to send the message
 *
 * @param frame_type  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid
 * @param frame_len  帧数据有效长度
 * @param frame_info  帧数据
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_read_charge_pile_blue_name_callback_send(mavlink_channel_t chan, uint8_t frame_type, uint8_t frame_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN];
    _mav_put_uint8_t(buf, 0, frame_type);
    _mav_put_uint8_t(buf, 1, frame_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK, buf, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#else
    mavlink_read_charge_pile_blue_name_callback_t packet;
    packet.frame_type = frame_type;
    packet.frame_len = frame_len;
    mav_array_memcpy(packet.frame_info, frame_info, sizeof(uint8_t)*16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK, (const char *)&packet, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#endif
}

/**
 * @brief Send a read_charge_pile_blue_name_callback message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_read_charge_pile_blue_name_callback_send_struct(mavlink_channel_t chan, const mavlink_read_charge_pile_blue_name_callback_t* read_charge_pile_blue_name_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_read_charge_pile_blue_name_callback_send(chan, read_charge_pile_blue_name_callback->frame_type, read_charge_pile_blue_name_callback->frame_len, read_charge_pile_blue_name_callback->frame_info);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK, (const char *)read_charge_pile_blue_name_callback, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#endif
}

#if MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_read_charge_pile_blue_name_callback_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t frame_type, uint8_t frame_len, const uint8_t *frame_info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, frame_type);
    _mav_put_uint8_t(buf, 1, frame_len);
    _mav_put_uint8_t_array(buf, 2, frame_info, 16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK, buf, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#else
    mavlink_read_charge_pile_blue_name_callback_t *packet = (mavlink_read_charge_pile_blue_name_callback_t *)msgbuf;
    packet->frame_type = frame_type;
    packet->frame_len = frame_len;
    mav_array_memcpy(packet->frame_info, frame_info, sizeof(uint8_t)*16);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK, (const char *)packet, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_MIN_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_CRC);
#endif
}
#endif

#endif

// MESSAGE READ_CHARGE_PILE_BLUE_NAME_CALLBACK UNPACKING


/**
 * @brief Get field frame_type from read_charge_pile_blue_name_callback message
 *
 * @return  命令类型 0 蓝牙名称、1 充电桩sn、 2 tagid
 */
static inline uint8_t mavlink_msg_read_charge_pile_blue_name_callback_get_frame_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field frame_len from read_charge_pile_blue_name_callback message
 *
 * @return  帧数据有效长度
 */
static inline uint8_t mavlink_msg_read_charge_pile_blue_name_callback_get_frame_len(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field frame_info from read_charge_pile_blue_name_callback message
 *
 * @return  帧数据
 */
static inline uint16_t mavlink_msg_read_charge_pile_blue_name_callback_get_frame_info(const mavlink_message_t* msg, uint8_t *frame_info)
{
    return _MAV_RETURN_uint8_t_array(msg, frame_info, 16,  2);
}

/**
 * @brief Decode a read_charge_pile_blue_name_callback message into a struct
 *
 * @param msg The message to decode
 * @param read_charge_pile_blue_name_callback C-struct to decode the message contents into
 */
static inline void mavlink_msg_read_charge_pile_blue_name_callback_decode(const mavlink_message_t* msg, mavlink_read_charge_pile_blue_name_callback_t* read_charge_pile_blue_name_callback)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    read_charge_pile_blue_name_callback->frame_type = mavlink_msg_read_charge_pile_blue_name_callback_get_frame_type(msg);
    read_charge_pile_blue_name_callback->frame_len = mavlink_msg_read_charge_pile_blue_name_callback_get_frame_len(msg);
    mavlink_msg_read_charge_pile_blue_name_callback_get_frame_info(msg, read_charge_pile_blue_name_callback->frame_info);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN? msg->len : MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN;
        memset(read_charge_pile_blue_name_callback, 0, MAVLINK_MSG_ID_READ_CHARGE_PILE_BLUE_NAME_CALLBACK_LEN);
    memcpy(read_charge_pile_blue_name_callback, _MAV_PAYLOAD(msg), len);
#endif
}
