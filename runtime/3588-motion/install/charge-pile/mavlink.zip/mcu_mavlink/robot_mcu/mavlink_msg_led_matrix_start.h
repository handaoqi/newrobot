#pragma once
// MESSAGE LED_MATRIX_START PACKING

#define MAVLINK_MSG_ID_LED_MATRIX_START 107


typedef struct __mavlink_led_matrix_start_t {
 uint8_t width; /*<  LED灯板宽度*/
 uint8_t height; /*<  LED灯板高度*/
} mavlink_led_matrix_start_t;

#define MAVLINK_MSG_ID_LED_MATRIX_START_LEN 2
#define MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN 2
#define MAVLINK_MSG_ID_107_LEN 2
#define MAVLINK_MSG_ID_107_MIN_LEN 2

#define MAVLINK_MSG_ID_LED_MATRIX_START_CRC 227
#define MAVLINK_MSG_ID_107_CRC 227



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_LED_MATRIX_START { \
    107, \
    "LED_MATRIX_START", \
    2, \
    {  { "width", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_led_matrix_start_t, width) }, \
         { "height", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_led_matrix_start_t, height) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_LED_MATRIX_START { \
    "LED_MATRIX_START", \
    2, \
    {  { "width", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_led_matrix_start_t, width) }, \
         { "height", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_led_matrix_start_t, height) }, \
         } \
}
#endif

/**
 * @brief Pack a led_matrix_start message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param width  LED灯板宽度
 * @param height  LED灯板高度
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_start_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t width, uint8_t height)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_START_LEN];
    _mav_put_uint8_t(buf, 0, width);
    _mav_put_uint8_t(buf, 1, height);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#else
    mavlink_led_matrix_start_t packet;
    packet.width = width;
    packet.height = height;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_START;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
}

/**
 * @brief Pack a led_matrix_start message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param width  LED灯板宽度
 * @param height  LED灯板高度
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_start_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t width, uint8_t height)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_START_LEN];
    _mav_put_uint8_t(buf, 0, width);
    _mav_put_uint8_t(buf, 1, height);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#else
    mavlink_led_matrix_start_t packet;
    packet.width = width;
    packet.height = height;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_START;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#endif
}

/**
 * @brief Pack a led_matrix_start message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param width  LED灯板宽度
 * @param height  LED灯板高度
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_led_matrix_start_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t width,uint8_t height)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_START_LEN];
    _mav_put_uint8_t(buf, 0, width);
    _mav_put_uint8_t(buf, 1, height);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#else
    mavlink_led_matrix_start_t packet;
    packet.width = width;
    packet.height = height;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LED_MATRIX_START;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
}

/**
 * @brief Encode a led_matrix_start struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_start_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_led_matrix_start_t* led_matrix_start)
{
    return mavlink_msg_led_matrix_start_pack(system_id, component_id, msg, led_matrix_start->width, led_matrix_start->height);
}

/**
 * @brief Encode a led_matrix_start struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_start_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_led_matrix_start_t* led_matrix_start)
{
    return mavlink_msg_led_matrix_start_pack_chan(system_id, component_id, chan, msg, led_matrix_start->width, led_matrix_start->height);
}

/**
 * @brief Encode a led_matrix_start struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param led_matrix_start C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_led_matrix_start_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_led_matrix_start_t* led_matrix_start)
{
    return mavlink_msg_led_matrix_start_pack_status(system_id, component_id, _status, msg,  led_matrix_start->width, led_matrix_start->height);
}

/**
 * @brief Send a led_matrix_start message
 * @param chan MAVLink channel to send the message
 *
 * @param width  LED灯板宽度
 * @param height  LED灯板高度
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_led_matrix_start_send(mavlink_channel_t chan, uint8_t width, uint8_t height)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LED_MATRIX_START_LEN];
    _mav_put_uint8_t(buf, 0, width);
    _mav_put_uint8_t(buf, 1, height);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_START, buf, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#else
    mavlink_led_matrix_start_t packet;
    packet.width = width;
    packet.height = height;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_START, (const char *)&packet, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#endif
}

/**
 * @brief Send a led_matrix_start message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_led_matrix_start_send_struct(mavlink_channel_t chan, const mavlink_led_matrix_start_t* led_matrix_start)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_led_matrix_start_send(chan, led_matrix_start->width, led_matrix_start->height);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_START, (const char *)led_matrix_start, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#endif
}

#if MAVLINK_MSG_ID_LED_MATRIX_START_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_led_matrix_start_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t width, uint8_t height)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, width);
    _mav_put_uint8_t(buf, 1, height);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_START, buf, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#else
    mavlink_led_matrix_start_t *packet = (mavlink_led_matrix_start_t *)msgbuf;
    packet->width = width;
    packet->height = height;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LED_MATRIX_START, (const char *)packet, MAVLINK_MSG_ID_LED_MATRIX_START_MIN_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_LEN, MAVLINK_MSG_ID_LED_MATRIX_START_CRC);
#endif
}
#endif

#endif

// MESSAGE LED_MATRIX_START UNPACKING


/**
 * @brief Get field width from led_matrix_start message
 *
 * @return  LED灯板宽度
 */
static inline uint8_t mavlink_msg_led_matrix_start_get_width(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field height from led_matrix_start message
 *
 * @return  LED灯板高度
 */
static inline uint8_t mavlink_msg_led_matrix_start_get_height(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Decode a led_matrix_start message into a struct
 *
 * @param msg The message to decode
 * @param led_matrix_start C-struct to decode the message contents into
 */
static inline void mavlink_msg_led_matrix_start_decode(const mavlink_message_t* msg, mavlink_led_matrix_start_t* led_matrix_start)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    led_matrix_start->width = mavlink_msg_led_matrix_start_get_width(msg);
    led_matrix_start->height = mavlink_msg_led_matrix_start_get_height(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_LED_MATRIX_START_LEN? msg->len : MAVLINK_MSG_ID_LED_MATRIX_START_LEN;
        memset(led_matrix_start, 0, MAVLINK_MSG_ID_LED_MATRIX_START_LEN);
    memcpy(led_matrix_start, _MAV_PAYLOAD(msg), len);
#endif
}
