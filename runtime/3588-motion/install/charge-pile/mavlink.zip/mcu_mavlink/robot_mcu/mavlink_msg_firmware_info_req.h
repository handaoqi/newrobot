#pragma once
// MESSAGE FIRMWARE_INFO_REQ PACKING

#define MAVLINK_MSG_ID_FIRMWARE_INFO_REQ 5


typedef struct __mavlink_firmware_info_req_t {
 uint8_t type; /*<  0，A分区信息，1，B分区信息，2，BOOT分区信息*/
} mavlink_firmware_info_req_t;

#define MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN 1
#define MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN 1
#define MAVLINK_MSG_ID_5_LEN 1
#define MAVLINK_MSG_ID_5_MIN_LEN 1

#define MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC 219
#define MAVLINK_MSG_ID_5_CRC 219



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FIRMWARE_INFO_REQ { \
    5, \
    "FIRMWARE_INFO_REQ", \
    1, \
    {  { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_firmware_info_req_t, type) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FIRMWARE_INFO_REQ { \
    "FIRMWARE_INFO_REQ", \
    1, \
    {  { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_firmware_info_req_t, type) }, \
         } \
}
#endif

/**
 * @brief Pack a firmware_info_req message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param type  0，A分区信息，1，B分区信息，2，BOOT分区信息
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_req_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN];
    _mav_put_uint8_t(buf, 0, type);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#else
    mavlink_firmware_info_req_t packet;
    packet.type = type;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO_REQ;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
}

/**
 * @brief Pack a firmware_info_req message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 *
 * @param type  0，A分区信息，1，B分区信息，2，BOOT分区信息
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_req_pack_status(uint8_t system_id, uint8_t component_id, mavlink_status_t *_status, mavlink_message_t* msg,
                               uint8_t type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN];
    _mav_put_uint8_t(buf, 0, type);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#else
    mavlink_firmware_info_req_t packet;
    packet.type = type;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO_REQ;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#else
    return mavlink_finalize_message_buffer(msg, system_id, component_id, _status, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#endif
}

/**
 * @brief Pack a firmware_info_req message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param type  0，A分区信息，1，B分区信息，2，BOOT分区信息
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_firmware_info_req_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN];
    _mav_put_uint8_t(buf, 0, type);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#else
    mavlink_firmware_info_req_t packet;
    packet.type = type;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FIRMWARE_INFO_REQ;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
}

/**
 * @brief Encode a firmware_info_req struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info_req C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_req_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_firmware_info_req_t* firmware_info_req)
{
    return mavlink_msg_firmware_info_req_pack(system_id, component_id, msg, firmware_info_req->type);
}

/**
 * @brief Encode a firmware_info_req struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info_req C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_req_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_firmware_info_req_t* firmware_info_req)
{
    return mavlink_msg_firmware_info_req_pack_chan(system_id, component_id, chan, msg, firmware_info_req->type);
}

/**
 * @brief Encode a firmware_info_req struct with provided status structure
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param status MAVLink status structure
 * @param msg The MAVLink message to compress the data into
 * @param firmware_info_req C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_firmware_info_req_encode_status(uint8_t system_id, uint8_t component_id, mavlink_status_t* _status, mavlink_message_t* msg, const mavlink_firmware_info_req_t* firmware_info_req)
{
    return mavlink_msg_firmware_info_req_pack_status(system_id, component_id, _status, msg,  firmware_info_req->type);
}

/**
 * @brief Send a firmware_info_req message
 * @param chan MAVLink channel to send the message
 *
 * @param type  0，A分区信息，1，B分区信息，2，BOOT分区信息
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_firmware_info_req_send(mavlink_channel_t chan, uint8_t type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN];
    _mav_put_uint8_t(buf, 0, type);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ, buf, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#else
    mavlink_firmware_info_req_t packet;
    packet.type = type;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ, (const char *)&packet, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#endif
}

/**
 * @brief Send a firmware_info_req message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_firmware_info_req_send_struct(mavlink_channel_t chan, const mavlink_firmware_info_req_t* firmware_info_req)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_firmware_info_req_send(chan, firmware_info_req->type);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ, (const char *)firmware_info_req, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#endif
}

#if MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This variant of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_firmware_info_req_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, type);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ, buf, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#else
    mavlink_firmware_info_req_t *packet = (mavlink_firmware_info_req_t *)msgbuf;
    packet->type = type;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ, (const char *)packet, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_MIN_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_CRC);
#endif
}
#endif

#endif

// MESSAGE FIRMWARE_INFO_REQ UNPACKING


/**
 * @brief Get field type from firmware_info_req message
 *
 * @return  0，A分区信息，1，B分区信息，2，BOOT分区信息
 */
static inline uint8_t mavlink_msg_firmware_info_req_get_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Decode a firmware_info_req message into a struct
 *
 * @param msg The message to decode
 * @param firmware_info_req C-struct to decode the message contents into
 */
static inline void mavlink_msg_firmware_info_req_decode(const mavlink_message_t* msg, mavlink_firmware_info_req_t* firmware_info_req)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    firmware_info_req->type = mavlink_msg_firmware_info_req_get_type(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN? msg->len : MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN;
        memset(firmware_info_req, 0, MAVLINK_MSG_ID_FIRMWARE_INFO_REQ_LEN);
    memcpy(firmware_info_req, _MAV_PAYLOAD(msg), len);
#endif
}
